<?php

namespace urlshort\acp\page;

use urlshort\data\featuredlink\FeaturedLinkList;
use wcf\page\MultipleLinkPage;
use wcf\system\exception\IllegalLinkException;
use wcf\system\WCF;

/**
 * ACP page for listing featured links for a specific URL.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 *
 * @package    info.benjaro.urlshort.affiliate
 * @subpackage acp.page
 *
 * @property FeaturedLinkList $objectList
 */
class FeaturedLinkListPage extends MultipleLinkPage
{
    /**
     * @inheritDoc
     */
    public $objectListClassName = FeaturedLinkList::class;

    /**
     * @inheritDoc
     */
    public $sortField = 'sortOrder';

    /**
     * @inheritDoc
     */
    public $sortOrder = 'ASC';

    /**
     * @inheritDoc
     */
    public $activeMenuItem = 'urlshort.acp.menu.link.menu';

    /**
     * @inheritDoc
     */
    public $neededPermissions = ['admin.urlshort.canManageFeaturedLinks'];

    /**
     * @inheritDoc
     */
    public $validSortFields = ['linkID', 'url', 'title', 'sortOrder'];

    /**
     * URL ID (required parameter from URL query)
     */
    public int $urlID = 0;

    /**
     * Hash of the short URL.
     */
    public string $urlHash = '';

    /**
     * Destination URL of the short URL.
     */
    public string $urlTarget = '';

    /**
     * Query string for filtering
     */
    public $q;

    /**
     * @inheritDoc
     */
    public function readParameters()
    {
        parent::readParameters();

        // Read sort parameters
        if (isset($_REQUEST['sortField']) && in_array($_REQUEST['sortField'], $this->validSortFields)) {
            $this->sortField = $_REQUEST['sortField'];
        }
        if (isset($_REQUEST['sortOrder']) && in_array($_REQUEST['sortOrder'], ['ASC', 'DESC'])) {
            $this->sortOrder = $_REQUEST['sortOrder'];
        }

        if (isset($_REQUEST['urlID'])) {
            $this->urlID = (int) $_REQUEST['urlID'];
        }

        // URL ID is required
        if ($this->urlID === 0) {
            throw new IllegalLinkException();
        }

        // Load URL metadata
        $sql = "SELECT hash, url FROM urlshort1_url WHERE urlID = ?";
        $statement = WCF::getDB()->prepare($sql);
        $statement->execute([$this->urlID]);
        $row = $statement->fetchArray();
        if (!$row) {
            throw new IllegalLinkException();
        }

        $this->urlHash = $row['hash'] ?? '';
        $this->urlTarget = $row['url'] ?? '';

        // Read query parameter
        if (isset($_REQUEST['q'])) {
            $this->q = $_REQUEST['q'];
        }
    }

    /**
     * @inheritDoc
     */
    protected function initObjectList()
    {
        parent::initObjectList();

        // Apply sorting
        if (in_array($this->sortField, $this->validSortFields)) {
            $this->objectList->sqlOrderBy = $this->sortField . ' ' . $this->sortOrder;
        }

        // Filter by URL ID (required)
        $this->objectList->getConditionBuilder()->add('urlID = ?', [$this->urlID]);

        // Add query parameter filter
        if ($this->q) {
            $this->objectList->getConditionBuilder()->add(
                'url LIKE ? OR title LIKE ?',
                [
                    '%' . $this->q . '%',
                    '%' . $this->q . '%',
                ]
            );
        }
    }

    /**
     * @inheritDoc
     */
    public function assignVariables()
    {
        parent::assignVariables();

        WCF::getTPL()->assign([
            'sortField' => $this->sortField,
            'sortOrder' => $this->sortOrder,
            'urlID' => $this->urlID,
            'q' => $this->q,
            'urlHash' => $this->urlHash,
            'urlTarget' => $this->urlTarget,
        ]);
    }
}
