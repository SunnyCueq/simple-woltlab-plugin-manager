<th class="columnTitle columnCustomButtons text-center{if $sortField == 'customButtons'} active {@$sortOrder}{/if}"><a href="{link application='urlshort' controller='UrlList'}pageNo={@$pageNo}&sortField=customButtons&sortOrder={if $sortField == 'customButtons' && $sortOrder == 'ASC'}DESC{else}ASC{/if}&q={$q}{/link}">{lang}wcf.urlshort.customButton.section{/lang}</a></th>

