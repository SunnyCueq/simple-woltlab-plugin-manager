{include file='header' pageTitle='urlshort.acp.menu.link.special.'|concat:$action}

<header class="contentHeader">
	<div class="contentHeaderTitle">
		<h1 class="contentTitle">{lang}urlshort.acp.menu.link.special.{$action}{/lang}{if $urlHash} ({$urlHash}){/if}</h1>
	</div>

	<nav class="contentHeaderNavigation">
		<ul>
			<li><a href="{link controller='SpecialList' application='urlshort'}{/link}" class="button">{icon size=16 name='list'} <span>{lang}urlshort.acp.menu.link.special.list{/lang}</span></a></li>
			{if $urlID}
				<li><a href="{link controller='UrlEdit' application='urlshort' id=$urlID}{/link}" class="button">{icon size=16 name='pen-to-square'} <span>{lang}wcf.urlshort.special.editUrl{/lang}</span></a></li>
			{/if}
			{event name='contentHeaderNavigation'}
		</ul>
	</nav>
</header>

{@$form->getHtml()}

{* JavaScript to auto-fill colors when theme changes *}
{if $themes|isset && $themes|count}
<script data-relocate="true">
	require(['Dom/Util'], function(DomUtil) {
		var themeSelect = document.getElementById('theme');
		var themes = {@$themes|json};
		
		if (themeSelect && themes) {
			themeSelect.addEventListener('change', function() {
				var selectedTheme = this.value;
				if (themes[selectedTheme]) {
					var theme = themes[selectedTheme];
					
					// Update color fields
					var primaryColor = document.getElementById('primaryColor');
					var secondaryColor = document.getElementById('secondaryColor');
					var primaryTextColor = document.getElementById('primaryTextColor');
					var secondaryTextColor = document.getElementById('secondaryTextColor');
					
					if (primaryColor) primaryColor.value = theme.primaryColor;
					if (secondaryColor) secondaryColor.value = theme.secondaryColor;
					if (primaryTextColor) primaryTextColor.value = theme.primaryTextColor;
					if (secondaryTextColor) secondaryTextColor.value = theme.secondaryTextColor;
					
					// Trigger change event for color pickers
					[primaryColor, secondaryColor, primaryTextColor, secondaryTextColor].forEach(function(field) {
						if (field) {
							var event = new Event('change', { bubbles: true });
							field.dispatchEvent(event);
						}
					});
				}
			});
		}
	});
</script>
{/if}

{include file='footer'}

