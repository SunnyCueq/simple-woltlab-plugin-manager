<th class="columnTitle columnFeaturedLinks{if $sortField == 'featuredLinks'} active {@$sortOrder}{/if}"><a href="{link application='urlshort' controller='UrlList'}pageNo={@$pageNo}&sortField=featuredLinks&sortOrder={if $sortField == 'featuredLinks' && $sortOrder == 'ASC'}DESC{else}ASC{/if}&q={$q}{/link}">{lang}wcf.urlshort.featuredLink.section{/lang}</a></th>

