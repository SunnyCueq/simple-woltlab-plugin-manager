{* 
 * Custom buttons display template
 * 
 * Displays custom buttons directly under the forward button.
 * Smaller than the forward button, dynamically configurable.
 * 
 * Template variables:
 * @var array $customButtons Array: [['title' => string, 'targetUrl' => string, 'customButtonID' => int]]
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 1.0.116
 *}
{if $customButtons|count > 0}
    <div class="customButtonsContainer">
        {event name='customButtonsBefore'}
        <ul class="buttonGroup customButtonsList">
            {foreach from=$customButtons item=buttonData}
                {event name='customButtonItem'}
                <li>
                    <a class="button small customButton" href="{$buttonData.targetUrl}" rel="noopener" aria-label="{$buttonData.title}" data-button-id="{$buttonData.customButtonID}" data-url-id="{if $url|isset && $url->urlID|isset}{$url->urlID}{/if}">
                        <span>{$buttonData.title}</span>
                    </a>
                </li>
                {event name='customButtonItemAfter'}
            {/foreach}
            {event name='customButtonsList'}
        </ul>
        {event name='customButtonsAfter'}
    </div>
    
    {* Track custom button clicks *}
    {if $url|isset && $url->urlID|isset}
    <script data-relocate="true">
    (function() {
        // Track button click function
        function trackButtonClick(urlID, buttonType, linkID) {
            if (!urlID) return;
            
            // Use WoltLab's Legacy AJAX API
            // https://docs.woltlab.com/6.0/javascript/new-api_ajax/
            if (typeof require !== 'undefined') {
                require(['Ajax'], function(Ajax) {
                    Ajax.apiOnce({
                        data: {
                            actionName: 'trackClick',
                            className: 'urlshort\\data\\buttonclick\\ButtonClickAction',
                            parameters: {
                                urlID: urlID,
                                buttonType: buttonType,
                                linkID: linkID || null
                            }
                        },
                        silent: true,
                        ignoreError: true
                    });
                });
            }
        }
        
        // Add click tracking to all custom buttons
        document.addEventListener('DOMContentLoaded', function() {
            const customButtons = document.querySelectorAll('.customButton');
            customButtons.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
                        return;
                    }
                    e.preventDefault();
                    const urlID = parseInt(this.getAttribute('data-url-id')) || 0;
                    const buttonID = parseInt(this.getAttribute('data-button-id')) || null;
                    if (urlID > 0) {
                        trackButtonClick(urlID, 'custom', buttonID);
                    }
                    const targetUrl = this.getAttribute('href') || '#';
                    setTimeout(() => {
                        window.location.href = targetUrl;
                    }, 120);
                });
            });
        });
    })();
    </script>
    {/if}
{/if}

