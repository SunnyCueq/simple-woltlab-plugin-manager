{* 
 * Additional text template
 * 
 * Displays HTML content from discount's additionalText field.
 * 
 * Template variables:
 * @var \urlshort\data\discount\Discount $discount Discount object
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 2.0.0
 *}
{if $discount && $discount->additionalText}
    <div class="additionalTextContainer">
        <div class="htmlContent">
            {@$discount->additionalText}
        </div>
    </div>
{/if}
