{* 
 * Theme effects template
 * 
 * Includes the appropriate effect template based on active theme.
 * Effects: autumnLeaves, snow, ghosts
 * 
 * Template variables:
 * @var array|null $activeThemeEffect Theme effect data: ['identifier' => string, 'settings' => array, 'additionalEffects' => array]
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 2.0.0
 *}
{if $activeThemeEffect|isset && $activeThemeEffect.identifier !== 'none'}
	{if $activeThemeEffect.identifier === 'autumnLeaves'}
		{include file='__effectAutumnLeaves' application='urlshort' effect=$activeThemeEffect.settings}
	{elseif $activeThemeEffect.identifier === 'snow'}
		{include file='__effectSnow' application='urlshort' effect=$activeThemeEffect.settings}
	{elseif $activeThemeEffect.identifier === 'ghosts'}
		{include file='__effectGhosts' application='urlshort' effect=$activeThemeEffect.settings}
	{/if}
	
	{* Load additional effects (e.g. autumn leaves for Halloween) *}
	{if $activeThemeEffect.additionalEffects|isset}
		{foreach from=$activeThemeEffect.additionalEffects item=additionalEffect}
			{if $additionalEffect.identifier === 'autumnLeaves'}
				{include file='__effectAutumnLeaves' application='urlshort' effect=$additionalEffect.settings}
			{elseif $additionalEffect.identifier === 'snow'}
				{include file='__effectSnow' application='urlshort' effect=$additionalEffect.settings}
			{elseif $additionalEffect.identifier === 'ghosts'}
				{include file='__effectGhosts' application='urlshort' effect=$additionalEffect.settings}
			{/if}
		{/foreach}
	{/if}
{/if}

