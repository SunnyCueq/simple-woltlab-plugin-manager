{* 
 * Reaction button and share button template
 * 
 * Displays reaction summary and buttons for logged-in users and guests.
 * Handles guest reactions via GuestReactionAction and custom JavaScript handlers.
 * 
 * Template variables:
 * @var bool MODULE_LIKE Whether like/reaction module is enabled
 * @var bool $enableReactions Whether reactions are enabled for this URL
 * @var int $reactionObjectID Object ID for reactions
 * @var string $reactionObjectType Object type for reactions
 * @var array $reactionData Reaction data indexed by object ID
 * @var int|null $guestReactionTypeID Guest reaction type ID (if guest has reacted)
 * @var bool $enableGuestReactions Whether guest reactions are enabled
 * @var string $shareUrl URL to share
 * @var \urlshort\data\url\Url $url URL object
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 2.0.0
 *}
{* Buttons: Share links, Reaktionen rechts *}
{if MODULE_LIKE && $enableReactions && $reactionObjectID}
	<div class="urlShortBox__footer" data-object-id="{#$reactionObjectID}">
		{* WoltLab-Standard Layout: Wie comment__footer mit Grid *}
		<div class="urlShortBox__reactions">
			{if $__wcf->session->getPermission('user.like.canViewLike')}
				{* Eigenes Template mit guestReactionTypeID Support *}
				{assign var='__reactionSummaryJson' value='[]'}
				{if $reactionData[$reactionObjectID]|isset}
					{assign var='__reactionSummaryJson' value=$reactionData[$reactionObjectID]->getReactionsJson()}
				{/if}
				
				{* Determine selected reaction: For guests use guestReactionTypeID, otherwise use reactionTypeID *}
				{assign var='__selectedReaction' value='0'}
				{if !$__wcf->user->userID && $guestReactionTypeID|isset && $guestReactionTypeID > 0}
					{assign var='__selectedReaction' value=$guestReactionTypeID}
				{elseif $reactionData[$reactionObjectID]|isset && $reactionData[$reactionObjectID]->reactionTypeID}
					{assign var='__selectedReaction' value=$reactionData[$reactionObjectID]->reactionTypeID}
				{/if}
				
				<woltlab-core-reaction-summary
					data="{$__reactionSummaryJson}"
					object-type="{$reactionObjectType}"
					object-id="{#$reactionObjectID}"
					selected-reaction="{#$__selectedReaction}"
				></woltlab-core-reaction-summary>
			{/if}
		</div>

		{* Buttons rechts (wie comment__buttons) *}
		<div class="urlShortBox__buttons">
			{if URLSHORT_FEATUREDLINKS_ENABLESHAREBUTTON}
					<button type="button" class="button small shareButton jsTooltip" title="{lang}wcf.message.share{/lang}" aria-label="{lang}wcf.message.share{/lang}" data-link="{$shareUrl}" data-link-title="{if $url->urlTitle|isset && $url->urlTitle}{$url->urlTitle}{elseif $url->extractedTitle|isset}{$url->extractedTitle}{else}{$url->hash}{/if}">
						{icon name='share-nodes'}
						<span class="invisible">{lang}wcf.message.share{/lang}</span>
					</button>
			{/if}

				{* Reaction button - for logged-in users or guests (if enabled) *}
				{if $__wcf->session->getPermission('user.like.canLike') || ($enableGuestReactions && !$__wcf->user->userID)}
					{if $__wcf->user->userID}
						{* Logged in user *}
					<button type="button" class="button small reactButton jsTooltip{if $reactionData[$reactionObjectID]|isset && $reactionData[$reactionObjectID]->reactionTypeID} active{/if}" title="{lang}wcf.reactions.react{/lang}" aria-label="{lang}wcf.reactions.react{/lang}" data-reaction-type-id="{if $reactionData[$reactionObjectID]|isset && $reactionData[$reactionObjectID]->reactionTypeID}{#$reactionData[$reactionObjectID]->reactionTypeID}{else}0{/if}" data-object-type="{$reactionObjectType}" data-object-id="{#$reactionObjectID}">
							{icon name='face-smile'}
							<span class="invisible">{lang}wcf.reactions.react{/lang}</span>
					</button>
					{else}
						{* Guest *}
					<button type="button" class="button small reactButton jsGuestReactButton jsTooltip{if $guestReactionTypeID|isset && $guestReactionTypeID > 0} active{/if}" title="{lang}wcf.reactions.react{/lang}" aria-label="{lang}wcf.reactions.react{/lang}" data-reaction-type-id="{if $guestReactionTypeID|isset}{#$guestReactionTypeID}{else}0{/if}" data-object-type="{$reactionObjectType}" data-object-id="{#$reactionObjectID}">
							{icon name='face-smile'}
							<span class="invisible">{lang}wcf.reactions.react{/lang}</span>
					</button>
				{/if}
			{/if}
		</div>
	</div>

	{* Initialize reaction handlers via TypeScript module *}
	<script data-relocate="true">
		{if $__wcf->user->userID || $enableGuestReactions}
			require(['Benjaro/Urlshort/Ui/GuestReactionHandler'], function(GuestReactionHandler) {
				{if $__wcf->user->userID}
					{* Logged-in users: Use .reactButton selector *}
					GuestReactionHandler.createHandler({
						objectType: '{$reactionObjectType}',
						containerSelector: '.urlShortBox__footer',
						buttonSelector: '.reactButton'
					});
				{elseif $enableGuestReactions}
					{* Guests: Use .jsGuestReactButton selector *}
					GuestReactionHandler.createHandler({
						objectType: '{$reactionObjectType}',
						containerSelector: '.urlShortBox__footer',
						buttonSelector: '.jsGuestReactButton'
					});
				{/if}
			});
		{/if}

		{* Initialize share dialog if enabled *}
		{if URLSHORT_FEATUREDLINKS_ENABLESHAREBUTTON}
		require(['WoltLabSuite/Core/Ui/Message/Share/Dialog'], function(UiMessageShareDialog) {
			UiMessageShareDialog.setup();
		});
		{/if}
	</script>
{/if}
