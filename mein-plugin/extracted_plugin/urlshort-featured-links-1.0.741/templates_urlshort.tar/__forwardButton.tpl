{* 
 * Enhanced forward button with 3D effect
 * 
 * Replaces the standard forward button with a modern 3D-styled button.
 * Colors mirror the promotional badge (spiegelverkehrt).
 * 
 * Template variables:
 * @var \urlshort\data\discount\Discount|null $discount Discount object (for colors)
 * @var string $redirectUrl The URL to redirect to
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 2.3.6
 *}
{* Find and replace the forward button *}
<script data-relocate="true">
(function() {
    let enhanced = false;

    function enhanceForwardButton() {
        const button = document.getElementById('forwardButton');
        if (!button || enhanced) return;
        
        // Get button text and URL
        const buttonText = button.textContent ? button.textContent.trim() : (button.innerText ? button.innerText.trim() : 'Empfehlung ansehen');
        const buttonUrl = button.href || button.getAttribute('href') || '#';
        
        // Get colors from discount badge (spiegelverkehrt - mirrored)
        // Badge uses: primaryColor (left) -> secondaryColor (right)
        // Button uses: secondaryColor (left) -> primaryColor (right) - spiegelverkehrt
        const discountElement = document.querySelector('.badge-promo');
        let buttonLeft = '#e94057';   // Default: Will be badge's secondaryColor (left)
        let buttonRight = '#f27121';  // Default: Will be badge's primaryColor (right)
        
        if (discountElement) {
            const computedStyle = window.getComputedStyle(discountElement);
            let badgePrimary = computedStyle.getPropertyValue('--badge-primary-bg').trim();
            let badgeSecondary = computedStyle.getPropertyValue('--badge-secondary-bg').trim();
            
            // If CSS variables are not set, try to get them from the inline style attribute
            if (!badgePrimary || badgePrimary === '') {
                const inlineStyle = discountElement.getAttribute('style') || '';
                const primaryMatch = inlineStyle.match(/--badge-primary-bg:\s*([^;]+)/);
                if (primaryMatch) {
                    badgePrimary = primaryMatch[1].trim();
                }
            }
            if (!badgeSecondary || badgeSecondary === '') {
                const inlineStyle = discountElement.getAttribute('style') || '';
                const secondaryMatch = inlineStyle.match(/--badge-secondary-bg:\s*([^;]+)/);
                if (secondaryMatch) {
                    badgeSecondary = secondaryMatch[1].trim();
                }
            }
            
            // Mirror colors: badge's secondary (right) becomes button's left, badge's primary (left) becomes button's right
            // Accept CSS variables (starting with 'var(') or any non-empty value that's not the old default white
            if (badgeSecondary && badgeSecondary !== '') {
                // Always use if it's a CSS variable, or if it's not the old default white
                if (badgeSecondary.startsWith('var(') || badgeSecondary !== 'rgba(255, 255, 255, 1)') {
                    buttonLeft = badgeSecondary; // Badge's right color -> Button's left
                }
            }
            if (badgePrimary && badgePrimary !== '') {
                // Always use if it's a CSS variable, or if it's not the old default white
                if (badgePrimary.startsWith('var(') || badgePrimary !== 'rgba(255, 255, 255, 1)') {
                    buttonRight = badgePrimary; // Badge's left color -> Button's right
                }
            }
        }
        
        // Create new button structure
        const newButton = document.createElement('a');
        newButton.id = 'forwardButton';
        newButton.href = buttonUrl;
        newButton.className = 'forwardButtonEnhanced';
        newButton.style.setProperty('--forward-button-left', buttonLeft);
        newButton.style.setProperty('--forward-button-right', buttonRight);
        
        // Create DOM elements instead of using template strings
        const shadow = document.createElement('span');
        shadow.className = 'forwardButtonEnhanced__shadow';
        
        const content = document.createElement('div');
        content.className = 'forwardButtonEnhanced__content';
        
        const text = document.createElement('span');
        text.className = 'forwardButtonEnhanced__text';
        text.textContent = buttonText;
        
        const icon = document.createElement('fa-icon');
        icon.setAttribute('name', 'arrow-right');
        icon.setAttribute('size', '16');
        icon.className = 'forwardButtonEnhanced__icon';
        
        content.appendChild(text);
        content.appendChild(icon);
        
        newButton.appendChild(shadow);
        newButton.appendChild(content);
        
        // Replace old button
        button.parentNode.replaceChild(newButton, button);

        {if $url|isset && $url->urlID|isset}
        newButton.addEventListener('click', function(event) {
            if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                return;
            }
            event.preventDefault();
            trackButtonClick({$url->urlID}, 'forward');
            setTimeout(function() {
                window.location.href = buttonUrl;
            }, 120);
        }, { once: false });
        {/if}

        enhanced = true;
    }
    
    // Track button click function
    function trackButtonClick(urlID, buttonType, linkID) {
        if (!urlID) return;
        
        // Use WoltLab's Legacy AJAX API
        // https://docs.woltlab.com/6.0/javascript/new-api_ajax/
        if (typeof require !== 'undefined') {
            require(['Ajax'], function(Ajax) {
                Ajax.apiOnce({
                    data: {
                        actionName: 'trackClick',
                        className: 'urlshort\\data\\buttonclick\\ButtonClickAction',
                        parameters: {
                            urlID: urlID,
                            buttonType: buttonType,
                            linkID: linkID || null
                        }
                    },
                    silent: true,
                    ignoreError: true
                });
            });
        }
    }
    
    // Wait for DOM and discount badge to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(enhanceForwardButton, 100);
        });
    } else {
        setTimeout(enhanceForwardButton, 100);
    }
    
    // Also try after a delay (in case discount badge loads later)
    setTimeout(enhanceForwardButton, 500);
})();
</script>

