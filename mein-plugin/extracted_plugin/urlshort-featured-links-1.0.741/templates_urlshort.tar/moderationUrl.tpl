<article class="message messageReduced">
	<section class="messageContent">
		<header class="messageHeader">
			<div class="box32 messageHeaderWrapper">
				{user object=$url->getUserProfile() type='avatar32' ariaHidden='true' tabindex='-1'}
				
				<div class="messageHeaderBox">
					<h2 class="messageTitle">
						<a href="{@$url->getLink()}">{$url->getTitle()}</a>
					</h2>
					
					<ul class="messageHeaderMetaData">
						<li>{user object=$url->getUserProfile() class='username'}</li>
						<li><span class="messagePublicationTime">{@$url->getTime()|time}</span></li>
						
						{event name='messageHeaderMetaData'}
					</ul>
				</div>
			</div>
			
			{event name='messageHeader'}
		</header>
		
		<div class="messageBody">
			{event name='beforeMessageText'}
			
			<div class="messageText">
				<dl class="plain inlineDataList">
					<dt><strong>{lang}wcf.urlshort.url.targetUrl{/lang}:</strong></dt>
					<dd>
					<a href="{$url->url}" target="_blank" rel="noopener noreferrer">{$url->url}</a>
					<a href="{@$url->getLink()}" target="_blank" rel="noopener" class="button small" title="{lang}wcf.urlshort.url.problems.checkLink{/lang}" aria-label="{lang}wcf.urlshort.url.problems.checkLink{/lang}">{icon name='arrow-up-right-from-square' size=16}</a>
					</dd>
				</dl>
			</div>
			
			{event name='afterMessageText'}
		</div>
	</section>
</article>

