{* 
 * Discount codes display template
 * 
 * Displays discount codes with copy functionality.
 * Each code can have a custom label (e.g., "Standard", "Rainbow circle", or "Aktionscode").
 * 
 * Template variables:
 * @var \urlshort\data\discount\Discount $discount Discount object with codes
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 2.0.0
 *}
{if $discount && $discount->hasValidCodes()}
    <div class="discountCodesContainer warning">
        <strong>{#$discount->getCodesCount()} {$discount->getCodesLabel()}</strong>
        {* Loop through all discount codes with their labels *}
        {foreach from=$discount->getCodesList() item=codeData}
                <p>
                <small>{$codeData.label}</small>
                <kbd class="copyableCode" data-code="{$codeData.code}">{$codeData.code}</kbd>
                <button class="copyUrlButton" data-copy-link="{$codeData.code}"
                        data-tooltip="{lang}wcf.urlshort.copySpecialData{/lang}"
                        aria-label="{lang}wcf.urlshort.copySpecialData{/lang}">
                        {icon name='copy'}
                    </button>
                </p>
            {/foreach}
    </div>

    {* Initialize copy functionality for discount codes *}
    <script data-relocate="true">
        require(["JulianPfeil/Urlshort/Ui/CopyLinkButton", "Benjaro/Urlshort/Ui/DiscountCodes", "Language"],
        (CopyLinkButton, DiscountCodes, Language) => {
            Language.addObject({
                'wcf.urlshort.copyUrl.success': '{jslang}wcf.urlshort.copyCode.success{/jslang}',
                'wcf.urlshort.copyUrl.error': '{jslang}wcf.urlshort.copyCode.error{/jslang}'
            });

            CopyLinkButton.setup();
            DiscountCodes.setup();
        });
    </script>
{/if}