{* 
 * Featured links display template
 * 
 * Displays recommended affiliate links with host badges and titles.
 * 
 * Template variables:
 * @var array $featuredLinks Associative array: URL => ['title' => string, 'host' => string]
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 2.0.0
 *}
{if $featuredLinks|count > 0}
    <dl class="featuredLinksContainer">
        {event name='featuredLinksBefore'}
        <dt class="featuredLinksContainer__header">
            <div class="featuredLinksHeadline">
                <span class="featuredLinksHeadline__icon" aria-hidden="true">
                    {icon size=16 name="star"}
                </span>
                <h2 class="featuredLinksHeadline__title">{lang}urlshort.featured.texts.recommended{/lang}</h2>
            </div>
        </dt>
        <dd class="featuredLinksContainer__description small">
            {lang}urlshort.featured.texts.discount{/lang}
        </dd>
        <dd id="sectionResult" class="featuredLinksContainer__content">
            <ul class="containerList featuredLinksList">
                <li class="containerListButtonGroup featuredLinksButtonGroup">
                    <ul class="buttonGroup">
                {* Loop through all featured links *}
                {foreach from=$featuredLinks key=featuredLink item=linkData}
                    {event name='featuredLinkItem'}
                            <li>
                                <a class="button small featuredLinkButton" href="{$featuredLink}" rel="noopener" aria-label="{$linkData.title}" data-link-id="{if $linkData.linkID|isset}{$linkData.linkID}{/if}" data-url-id="{if $url|isset && $url->urlID|isset}{$url->urlID}{/if}">
                        <span class="badge badgeUpdate">{$linkData.host}</span>
                            {icon size=16 name="star"} <span>{$linkData.title}</span>
                        </a>
                            </li>
                    {event name='featuredLinkItemAfter'}
                {/foreach}
                {event name='featuredLinksList'}
                    </ul>
                </li>
            </ul>
        </dd>
        {event name='featuredLinksAfter'}
    </dl>
    
    {* Track featured link clicks *}
    {if $url|isset && $url->urlID|isset}
    <script data-relocate="true">
    (function() {
        // Track button click function
        function trackButtonClick(urlID, buttonType, linkID) {
            if (!urlID) return;
            
            // Use WoltLab's Legacy AJAX API
            // https://docs.woltlab.com/6.0/javascript/new-api_ajax/
            if (typeof require !== 'undefined') {
                require(['Ajax'], function(Ajax) {
                    Ajax.apiOnce({
                        data: {
                            actionName: 'trackClick',
                            className: 'urlshort\\data\\buttonclick\\ButtonClickAction',
                            parameters: {
                                urlID: urlID,
                                buttonType: buttonType,
                                linkID: linkID || null
                            }
                        },
                        silent: true,
                        ignoreError: true
                    });
                });
            }
        }
        
        // Add click tracking to all featured link buttons
        document.addEventListener('DOMContentLoaded', function() {
            const featuredLinkButtons = document.querySelectorAll('.featuredLinkButton');
            featuredLinkButtons.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
                        return;
                    }
                    e.preventDefault();
                    const urlID = parseInt(this.getAttribute('data-url-id')) || 0;
                    const linkID = parseInt(this.getAttribute('data-link-id')) || null;
                    if (urlID > 0) {
                        trackButtonClick(urlID, 'featured_link', linkID);
                    }
                    const targetUrl = this.getAttribute('href') || '#';
                    setTimeout(() => {
                        window.location.href = targetUrl;
                    }, 120);
                });
            });
        });
    })();
    </script>
    {/if}
{/if}
