{* 
 * Forward button click tracking (always loaded, for both 3D and standard button)
 * 
 * This template ensures that button clicks are tracked even when the 3D button is disabled.
 * It attaches a click handler to the standard forward button if the 3D button is not present.
 * 
 * Template variables:
 * @var \urlshort\data\url\Url|null $url URL object (for urlID)
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 1.0.123
 *}
<script data-relocate="true">
(function() {
    // Track button click function (shared with __forwardButton.tpl)
    function trackButtonClick(urlID, buttonType, linkID) {
        if (!urlID) return;
        
        // Use WoltLab's Legacy AJAX API
        // https://docs.woltlab.com/6.0/javascript/new-api_ajax/
        if (typeof require !== 'undefined') {
            require(['Ajax'], function(Ajax) {
                Ajax.apiOnce({
                    data: {
                        actionName: 'trackClick',
                        className: 'urlshort\\data\\buttonclick\\ButtonClickAction',
                        parameters: {
                            urlID: urlID,
                            buttonType: buttonType,
                            linkID: linkID || null
                        }
                    },
                    silent: true,
                    ignoreError: true
                });
            });
        }
    }
    
    function attachStandardButtonTracking() {
        const button = document.getElementById('forwardButton');
        if (!button) return;
        
        // Skip if button was already enhanced (3D button has its own tracking)
        if (button.classList.contains('forwardButtonEnhanced')) {
            return;
        }
        
        // Check if tracking is already attached
        if (button.hasAttribute('data-tracking-attached')) {
            return;
        }
        
        // Mark as tracked
        button.setAttribute('data-tracking-attached', 'true');
        
        // Get button URL
        const buttonUrl = button.href || button.getAttribute('href') || '#';
        
        // Attach click handler
        button.addEventListener('click', function(event) {
            if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
                return;
            }
            
            {if $url|isset && $url->urlID|isset}
            event.preventDefault();
            trackButtonClick({$url->urlID}, 'forward');
            setTimeout(function() {
                window.location.href = buttonUrl;
            }, 120);
            {/if}
        }, { once: false });
    }
    
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(attachStandardButtonTracking, 100);
        });
    } else {
        setTimeout(attachStandardButtonTracking, 100);
    }
    
    // Also try after a delay (in case button loads later)
    setTimeout(attachStandardButtonTracking, 500);
})();
</script>

