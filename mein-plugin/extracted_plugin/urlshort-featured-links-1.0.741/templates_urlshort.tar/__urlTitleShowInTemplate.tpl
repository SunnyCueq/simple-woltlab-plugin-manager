{* Title text with optional glitch effect for blackweek theme *}
{if $activeThemeIdentifier|isset && $activeThemeIdentifier === 'blackweek'}
	{* Black Week Theme: Apply glitch effect *}
	{if $url->urlTitle}
		{assign var="titleText" value=$url->urlTitle}
	{elseif $extractedTitle|isset}
		{assign var="titleText" value=$extractedTitle}
	{else}
		{assign var="titleText" value=""}
	{/if}
	{if $titleText}
		<span class="deal-bw__glitch" data-text="{$titleText}">{$titleText}</span>
	{/if}
{else}
	{* Normal theme: Plain text *}
	{if $url->urlTitle}{@$url->urlTitle}{elseif $extractedTitle|isset}{$extractedTitle}{/if}
{/if}
