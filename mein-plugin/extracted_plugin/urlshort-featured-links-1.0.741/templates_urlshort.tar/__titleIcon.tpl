{*
 * Title icon display template
 *
 * Displays the selected Font Awesome icon before the h1 title.
 * Uses pre-parsed values from RedirectPageEventListener.
 * Icon size automatically matches the h1 title font size via CSS.
 *
 * Template variables:
 * @var string $titleIconName Parsed icon name
 * @var bool $titleIconForceSolid Whether to force solid icon style
 *
 * @author Sunny C. <https://benjaro.info>
 * @since 2.3.7
 *}
{if $titleIconName && $titleIconName|trim && $titleIconName != ';'}
	<span class="titleIcon">
		{if $titleIconForceSolid}
			{icon name=$titleIconName type='solid'}
		{else}
			{icon name=$titleIconName}
		{/if}
	</span>
{/if}

