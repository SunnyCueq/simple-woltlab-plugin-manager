{* 
 * Promotional badge template with discount value and countdown
 * 
 * Displays discount value with dynamic CSS variables from database.
 * Shows countdown timer if active, or "expired" message if countdown ended.
 * 
 * Template variables:
 * @var \urlshort\data\discount\Discount $discount Discount object
 * @var int|null $countdownSeconds Remaining seconds for countdown (null if no countdown)
 * 
 * @author Sunny C. <https://benjaro.info>
 * @since 2.0.0
 *}
{if $discount}
    {* Dynamic CSS variables from database - must remain as inline style *}
    {* Set colors if they exist and are not the old default white (CSS variables always set) *}
    <div class="badge-promo" style="
        {if $discount->primaryColor|isset && ($discount->primaryColor|str_starts_with:'var(' || $discount->primaryColor != 'rgba(255, 255, 255, 1)')}--badge-primary-bg: {$discount->primaryColor};{/if}
        {if $discount->primaryTextColor|isset}--badge-primary-text: {$discount->primaryTextColor};{/if}
        {if $discount->secondaryColor|isset && ($discount->secondaryColor|str_starts_with:'var(' || $discount->secondaryColor != 'rgba(255, 255, 255, 1)')}--badge-secondary-bg: {$discount->secondaryColor};{/if}
        {if $discount->secondaryTextColor|isset}--badge-secondary-text: {$discount->secondaryTextColor};{/if}
    ">
        {* Left: Discount value *}
        <span class="badge-promo-content badge-promo-left" id="rabatt">
            <strong class="rabatt-number">{$discount->getFormattedDiscountValue()}</strong>
        </span>
        
        {* Center: Theme name (NEW) *}
        {if $specialThemeShortName|isset && $specialThemeShortName}
            <span class="badge-promo-content badge-promo-center">
                {$specialThemeShortName|strtoupper}
            </span>
        {/if}
        
        {* Right: Countdown display: active countdown, expired, or nothing *}
        {if $countdownSeconds|isset && $countdownSeconds > 0}
            <span class="badge-promo-content badge-promo-right badge" id="discount-countdown">
                {* Initial value will be set by JavaScript *}
            </span>
            <script data-relocate="true">
                require(["Benjaro/Urlshort/DiscountCountdown"], function(DiscountCountdown) {
                    DiscountCountdown.init("discount-countdown", {@$countdownSeconds});
                });
            </script>
        {elseif $countdownSeconds|isset}
            <span class="badge-promo-content badge-promo-right badge">{lang}wcf.urlshort.countdown.expired{/lang}</span>
        {/if}
    </div>
{/if}
