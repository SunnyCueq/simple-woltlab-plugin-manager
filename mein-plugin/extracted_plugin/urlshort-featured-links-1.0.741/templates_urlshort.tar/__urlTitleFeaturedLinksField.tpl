<dl{if $errorField == 'urlTitle'} class="formError"{/if}>
    <dt><label for="urlTitle">{lang}wcf.urlshort.url.urlTitle{/lang}</label></dt>
    <dd>
        <input type="text" id="urlTitle" name="urlTitle" placeholder="{lang}wcf.urlshort.url.urlTitle.description{/lang}" value="{$urlTitle}" maxlength="255" class="long">
        {if $errorField == 'urlTitle'}
            <small class="innerError">
                {if $errorType == 'empty'}
                    {lang}wcf.global.form.error.empty{/lang}
                {else}
                    {lang}urlshort.acp.url.urlTitle.error.{$errorType}{/lang}
                {/if}
            </small>
        {/if}
    </dd>
</dl>
<dl>
    <dt><label for="lineBreakSeparatedTextOption_featuredLinksUrlShort">{lang}wcf.urlshort.featuredLinks{/lang}</label></dt>
    <dd>
        <ul class="scrollableCheckboxList" {*
            *}id="lineBreakSeparatedTextOption_featuredLinksUrlShort"{*
            *}{if $featuredLinksValues|empty} style="display: none"{/if}{*
        *}>
            {foreach from=$featuredLinksValues item=value}
                <li data-value="{$value}">
                    <span class="jsDeleteItem jsTooltip pointer" title="{lang}wcf.global.button.delete{/lang}">{icon name="times"}</span>
                    <span>{$value}</span>
                </li>
            {/foreach}
        </ul>
        <input type="hidden" name="values[featuredLinksUrlShort]">

    </dd>
</dl>

<script data-relocate="true">
    require(['Language', 'WoltLabSuite/Core/Ui/ItemList/LineBreakSeparatedText'], (Language, { UiItemListLineBreakSeparatedText }) => {
        Language.addObject({
            'wcf.acp.option.type.lineBreakSeparatedText.placeholder': '{jslang}wcf.acp.option.type.lineBreakSeparatedText.placeholder{/jslang}',
            'wcf.acp.option.type.lineBreakSeparatedText.error.duplicate': '{jslang __literal=true}wcf.acp.option.type.lineBreakSeparatedText.error.duplicate{/jslang}',
            'wcf.acp.option.type.lineBreakSeparatedText.clearList.confirmMessage': '{jslang}wcf.acp.option.type.lineBreakSeparatedText.clearList.confirmMessage{/jslang}',
        });
        
        new UiItemListLineBreakSeparatedText(
            document.getElementById("lineBreakSeparatedTextOption_featuredLinksUrlShort")
        );
    });
</script>

<style>
    .itemListFilter, #lineBreakSeparatedTextOption_featuredLinksUrlShort {
        max-width: none !important;
    }
</style>
