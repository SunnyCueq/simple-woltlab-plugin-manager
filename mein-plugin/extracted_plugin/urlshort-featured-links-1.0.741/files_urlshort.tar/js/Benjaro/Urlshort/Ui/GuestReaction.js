/**
 * Intercepts WoltLab reaction AJAX calls for guests and redirects to custom endpoint.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
define(["require", "exports", "WoltLabSuite/Core/Ajax"], function (require, exports, Ajax) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.setup = setup;
    Ajax = __importStar(Ajax);
    let originalApi;
    function setup() {
        // Store original Ajax.api
        originalApi = Ajax.api;
        // Override Ajax.api to intercept reaction calls
        Ajax.api = function (callbackObject, options) {
            // Check if this is a reaction call for guests
            if (options &&
                options.actionName === "react" &&
                options.className === "wcf\\data\\reaction\\ReactionAction" &&
                options.parameters &&
                options.parameters.data &&
                options.parameters.data.objectType ===
                    "info.benjaro.urlshort.affiliate.likeableUrl") {
                // Redirect to guest reaction action
                options.className =
                    "urlshort\\data\\url\\reaction\\GuestUrlReactionAction";
            }
            // Call original Ajax.api
            return originalApi.call(Ajax, callbackObject, options);
        };
    }
    exports.default = { setup };
});
