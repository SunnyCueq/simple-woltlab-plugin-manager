<?php

namespace urlshort\acp\form;

use urlshort\data\discount\DiscountAction;
use wcf\form\AbstractFormBuilderForm;
use wcf\system\form\builder\container\FormContainer;
use wcf\system\form\builder\container\wysiwyg\WysiwygFormContainer;
use wcf\system\form\builder\container\RowFormFieldContainer;
use wcf\system\form\builder\field\dependency\NonEmptyFormFieldDependency;
use wcf\system\form\builder\field\BooleanFormField;
use wcf\system\form\builder\field\UploadFormField;
use wcf\system\form\builder\field\ColorFormField;
use wcf\system\form\builder\field\DateFormField;
use wcf\system\form\builder\field\ItemListFormField;
use wcf\system\form\builder\field\TextFormField;
use wcf\system\WCF;

/**
 * Form for adding a new discount.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 *
 * @package    info.benjaro.urlshort.affiliate
 * @subpackage acp.form
 */

class DiscountAddForm extends AbstractFormBuilderForm
{
    /**
     * @inheritDoc
     */
    public $neededPermissions = ['admin.urlshort.canManageDiscounts'];

    /**
     * @inheritDoc
     */
    public $activeMenuItem = 'urlshort.acp.menu.link.discount.add';

    /**
    * @inheritDoc
    */
    public $objectActionClass = DiscountAction::class;

    /**
     * @inheritDoc
     */
    protected function createForm()
    {
        parent::createForm();

        /* dataContainer */
        $dataContainer = FormContainer::create('data')
            ->label('wcf.global.form.data');

        /* append to dataContainer */
        $dataContainer->appendChildren([
            TextFormField::create('discountValue')
                ->label('wcf.urlshort.discount')
                ->description('wcf.urlshort.discount.description')
                ->placeholder('wcf.urlshort.discount.placeholder')
                ->required()
                ->autoFocus()
                ->maximumLength(255),
                
            UploadFormField::create('favicon')
                ->label('wcf.acp.style.general.favicon')
                ->description('wcf.urlshort.discount.favicon.description')
                ->maximum(1)
                ->imageOnly(true),

            ItemListFormField::create('hosts')
                ->required()
                ->label('wcf.urlshort.hosts')
                ->description('wcf.urlshort.hosts.description'),

            BooleanFormField::create('special')
                ->label('wcf.urlshort.special')
                ->value(false),

            TextFormField::create('specialIdentifier')
                ->label('wcf.urlshort.special.identifier')
                ->description('wcf.urlshort.special.identifier.description')
                ->required()
                ->maximumLength(255)
                ->addDependency(
                    NonEmptyFormFieldDependency::create('special')
                        ->fieldId('special')
                ),

            ItemListFormField::create('codes')
                ->label('wcf.urlshort.codes')
                ->description('wcf.urlshort.codes.description')
                ->value('BENJARO')
                ->required(),
        ]);
        
        // Load default colors from style_variable database table (like WoltLab's StyleAddForm does)
        $sql = "SELECT variableName, defaultValue FROM wcf" . WCF_N . "_style_variable WHERE variableName IN (?, ?, ?)";
        $statement = WCF::getDB()->prepare($sql);
        $statement->execute(['wcfHeaderBackground', 'wcfHeaderMenuBackground', 'wcfHeaderText']);
        $styleVariables = $statement->fetchMap('variableName', 'defaultValue');
        
        // Fallback to WoltLab Corporate Identity if variables not found
        $defaultPrimaryColor = $styleVariables['wcfHeaderBackground'] ?? 'rgba(58, 109, 156, 1)';
        $defaultSecondaryColor = $styleVariables['wcfHeaderMenuBackground'] ?? 'rgba(44, 62, 80, 1)';
        $defaultTextColor = $styleVariables['wcfHeaderText'] ?? 'rgba(255, 255, 255, 1)';
        
        // === COLOR SECTION for Promo Badge ===
        $colorContainer = FormContainer::create('colors')
            ->label('Farben für Promo Badge')
            ->description('Primäre Farben (linke Seite) und Sekundäre Farben (rechte Seite) des Promo Badges')
            ->appendChildren([
                ColorFormField::create('primaryColor')
                    ->label('wcf.urlshort.primaryColor')
                    ->description('wcf.urlshort.primaryColor.description')
                    ->value($defaultPrimaryColor)
                    ->required(),

                ColorFormField::create('primaryTextColor')
                    ->label('wcf.urlshort.primaryTextColor')
                    ->description('wcf.urlshort.primaryTextColor.description')
                    ->value($defaultTextColor)
                    ->required(),

                ColorFormField::create('secondaryColor')
                    ->label('wcf.urlshort.secondaryColor')
                    ->description('wcf.urlshort.secondaryColor.description')
                    ->value($defaultSecondaryColor)
                    ->required(),

                ColorFormField::create('secondaryTextColor')
                    ->label('wcf.urlshort.secondaryTextColor')
                    ->description('wcf.urlshort.secondaryTextColor.description')
                    ->value($defaultTextColor)
                    ->required(),
            ]);
        
        // === COUNTDOWN SECTION ===
        $countdownContainer = FormContainer::create('countdown')
            ->label('Countdown (Optional)')
            ->description('Zeitraum für den Rabatt (optional, für zeitlich begrenzte Aktionen)')
            ->appendChildren([
                DateFormField::create('countdownStart')
                    ->label('wcf.urlshort.countdownStart')
                    ->description('wcf.urlshort.countdownStart.description')
                    ->saveValueFormat('U')
                    ->supportTime(true)
                    ->value(strtotime('today')),

                DateFormField::create('countdownEnd')
                    ->label('wcf.urlshort.countdownEnd')
                    ->description('wcf.urlshort.countdownEnd.description')
                    ->saveValueFormat('U')
                    ->supportTime(true)
                    ->value(strtotime('today 23:59:59')),
            ]);

        // === WYSIWYG Container for additionalText ===
        $wysiwygContainer = WysiwygFormContainer::create('additionalText')
            ->label('Zusätzlicher Text')
            ->description('Zusätzlicher HTML-Text für den Rabatt (wird unter dem Promo Badge angezeigt)')
            ->messageObjectType('info.benjaro.urlshort.affiliate.discount.additionalText');

        // Append all containers to form
        $this->form->appendChild($dataContainer);
        $this->form->appendChild($colorContainer);
        $this->form->appendChild($countdownContainer);
        $this->form->appendChild($wysiwygContainer);
    }
}
