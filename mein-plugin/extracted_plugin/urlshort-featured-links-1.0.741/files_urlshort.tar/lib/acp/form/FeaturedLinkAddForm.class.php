<?php

namespace urlshort\acp\form;

use urlshort\data\featuredlink\FeaturedLinkAction;
use urlshort\data\featuredlink\FeaturedLinkList;
use wcf\form\AbstractFormBuilderForm;
use wcf\system\exception\IllegalLinkException;
use wcf\system\form\builder\container\FormContainer;
use wcf\system\form\builder\field\HiddenFormField;
use wcf\system\form\builder\field\IntegerFormField;
use wcf\system\form\builder\field\TextFormField;
use wcf\system\form\builder\field\UrlFormField;
use wcf\system\request\LinkHandler;
use wcf\system\WCF;
use wcf\util\HeaderUtil;

/**
 * Form for adding a new featured link.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 *
 * @package    info.benjaro.urlshort.affiliate
 * @subpackage acp.form
 */
class FeaturedLinkAddForm extends AbstractFormBuilderForm
{
    /**
     * @inheritDoc
     */
    public $neededPermissions = ['admin.urlshort.canManageFeaturedLinks'];

    /**
     * @inheritDoc
     */
    public $activeMenuItem = 'urlshort.acp.menu.link.menu';

    /**
     * @inheritDoc
     */
    public $objectActionClass = FeaturedLinkAction::class;

    /**
     * URL ID (required parameter from URL query)
     */
    public int $urlID = 0;

    /**
     * URL hash for display
     */
    public string $urlHash = '';

    /**
     * @inheritDoc
     */
    public function readParameters()
    {
        parent::readParameters();

        if (isset($_REQUEST['urlID'])) {
            $this->urlID = (int) $_REQUEST['urlID'];
        }

        // URL ID is required
        if ($this->urlID === 0) {
            throw new IllegalLinkException();
        }

        // Load URL data (hash)
        $sql = "SELECT hash FROM urlshort1_url WHERE urlID = ?";
        $statement = WCF::getDB()->prepare($sql);
        $statement->execute([$this->urlID]);
        $this->urlHash = $statement->fetchSingleColumn();

        if (empty($this->urlHash)) {
            throw new IllegalLinkException();
        }
    }

    /**
     * @inheritDoc
     */
    protected function createForm()
    {
        parent::createForm();

        $dataContainer = FormContainer::create('data')
            ->label('wcf.global.form.data');

        $dataContainer->appendChildren([
            // Hidden field for urlID (submitted with form)
            HiddenFormField::create('urlID')
                ->value($this->urlID),

            UrlFormField::create('url')
                ->label('wcf.urlshort.featuredLink.url')
                ->description('wcf.urlshort.featuredLink.url.description')
                ->required()
                ->autoFocus()
                ->maximumLength(255),

            TextFormField::create('title')
                ->label('wcf.global.title')
                ->description('wcf.urlshort.featuredLink.title.description')
                ->required()
                ->maximumLength(255),

            IntegerFormField::create('sortOrder')
                ->label('wcf.urlshort.featuredLink.sortOrder')
                ->description('wcf.urlshort.featuredLink.sortOrder.description')
                ->value(1)
                ->minimum(1),
        ]);

        $this->form->appendChild($dataContainer);
    }

    /**
     * @inheritDoc
     */
    public function saved()
    {
        parent::saved();

        // Redirect back to add form with same urlID to allow adding another featured link
        $url = LinkHandler::getInstance()->getControllerLink(FeaturedLinkAddForm::class, [
            'application' => 'urlshort',
        ]);
        $url .= '&urlID=' . $this->urlID;
        
        HeaderUtil::redirect($url);
        exit;
    }

    /**
     * @inheritDoc
     */
    public function assignVariables()
    {
        parent::assignVariables();

        // Check if there are existing featured links for this URL
        $featuredLinkList = new FeaturedLinkList();
        $featuredLinkList->getConditionBuilder()->add('urlID = ?', [$this->urlID]);
        $featuredLinkList->readObjects();
        $hasExistingFeaturedLinks = $featuredLinkList->count() > 0;

        WCF::getTPL()->assign([
            'urlID' => $this->urlID,
            'urlHash' => $this->urlHash,
            'hasExistingFeaturedLinks' => $hasExistingFeaturedLinks,
        ]);
    }
}
