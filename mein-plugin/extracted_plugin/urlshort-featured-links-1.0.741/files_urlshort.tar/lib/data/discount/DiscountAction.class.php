<?php

namespace urlshort\data\discount;

use wcf\data\AbstractDatabaseObjectAction;
use wcf\system\exception\UserInputException;
use wcf\system\file\upload\UploadFile;

/**
 * Executes discount-related actions.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 *
 * @package    info.benjaro.urlshort.affiliate
 * @subpackage data.discount
 */
class DiscountAction extends AbstractDatabaseObjectAction
{
    /**
     * @inheritDoc
     */
    protected $permissionsCreate = ['admin.urlshort.canManageDiscounts'];

    /**
     * @inheritDoc
     */
    protected $permissionsUpdate = ['admin.urlshort.canManageDiscounts'];

    /**
     * @inheritDoc
     */
    protected $permissionsDelete = ['admin.urlshort.canManageDiscounts'];

    /**
     * @inheritDoc
     */
    public function create()
    {
        // Validate color values before creating
        $this->validateColors();

        // create discount
        $discount = \call_user_func([$this->className, 'create'], $this->parameters['data']);
        $discountEditor = new DiscountEditor($discount);

        // image
        $updateData = [];
        if (isset($this->parameters['favicon']) && \is_array($this->parameters['favicon']) && \count($this->parameters['favicon'])) {
            $favicon = \reset($this->parameters['favicon']);
            if (!($favicon instanceof UploadFile)) {
                throw new \InvalidArgumentException("The parameter 'image' is no instance of '" . UploadFile::class . "', instance of '" . \get_class($favicon) . "' given.");
            }

            // save new image
            if (!$favicon->isProcessed()) {
                $fileName = $discount->discountID . '-' . $favicon->getFilename();

                \rename($favicon->getLocation(), WCF_DIR . 'images/discount/' . $fileName);
                $favicon->setProcessed(WCF_DIR . 'images/discount/' . $fileName);

                $updateData['favicon'] = $fileName;
            }
        }

        if (!empty($updateData)) {
            $discountEditor->update($updateData);
        }

        return $discount;
    }

    
    /**
     * @inheritDoc
     */
    public function update()
    {
        // Validate color values before updating
        $this->validateColors();

        parent::update();

        foreach ($this->getObjects() as $discount) {
            $updateData = [];

            // image
            if (isset($this->parameters['favicon_removedFiles']) && \is_array($this->parameters['favicon_removedFiles'])) {
                foreach ($this->parameters['favicon_removedFiles'] as $file) {
                    $updateData['favicon'] = null;
                    @\unlink($file->getLocation());
                }
            }

            if (isset($this->parameters['favicon']) && \is_array($this->parameters['favicon']) && \count($this->parameters['favicon'])) {
                $favicon = \reset($this->parameters['favicon']);
                if (!($favicon instanceof UploadFile)) {
                    throw new \InvalidArgumentException("The parameter 'image' is no instance of '" . UploadFile::class . "', instance of '" . \get_class($favicon) . "' given.");
                }

                // save new image
                if (!$favicon->isProcessed()) {
                    $fileName = $discount->discountID . '-' . $favicon->getFilename();

                    \rename($favicon->getLocation(), WCF_DIR . 'images/discount/' . $fileName);
                    $favicon->setProcessed(WCF_DIR . 'images/discount/' . $fileName);

                    $updateData['favicon'] = $fileName;
                }
            }

            if (!empty($updateData)) {
                $discount->update($updateData);
            }
        }
    }

    /**
     * Validates color values in the parameters.
     *
     * @throws UserInputException If any color value is invalid
     */
    protected function validateColors(): void
    {
        if (!isset($this->parameters['data'])) {
            return;
        }

        $colorFields = [
            'primaryColor',
            'secondaryColor',
            'primaryTextColor',
            'secondaryTextColor'
        ];

        foreach ($colorFields as $field) {
            if (isset($this->parameters['data'][$field])) {
                $color = $this->parameters['data'][$field];

                if (!empty($color) && !Discount::isValidColor($color)) {
                    throw new UserInputException($field, 'invalid');
                }
            }
        }
    }
}
