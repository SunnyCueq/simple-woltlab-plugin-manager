<?php

namespace urlshort\data\discount;

use wcf\system\WCF;
use wcf\util\StringUtil;

/**
 * Returns discounts accessible for a specific URL and host.
 * Filters discounts by host matching and URL validation.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 *
 * @package    info.benjaro.urlshort.affiliate
 * @subpackage data.discount
 */
class AccessibleDiscountList extends ViewableDiscountList
{
    /**
     * @inheritDoc
     */
    public function __construct(
        protected string $url,
        protected string $host = '',
    ) {
        parent::__construct();

        // Validate hostname format
        if (!empty($this->host) && !$this->isValidHostname($this->host)) {
            $this->host = '';
        }

        $this->sqlLimit = 1;

        $specialDiscount = $this->getSpecial();
        if ($specialDiscount !== null) {
            $discountIDs = $specialDiscount->getObjectIDs();
            $this->getConditionBuilder()->add('discount.discountID IN (?)', [$discountIDs]);
        } else {
            $this->getConditionBuilder()->add('discount.hosts LIKE ?', ['%' . $this->host . '%']);
        }
    }

    /**
     * Validates if the given hostname is in a valid format.
     */
    private function isValidHostname(string $hostname): bool
    {
        return (bool)preg_match('/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i', $hostname);
    }

    /**
     * Returns discount list for special identifier or null if not found.
     */
    protected function getSpecial(): ?DiscountList
    {
        $parsedUrl = parse_url($this->url);
        if (!isset($parsedUrl['query'])) {
            return null;
        }

        parse_str($parsedUrl['query'], $getParameters);

        if (!isset($getParameters['special']) || !is_string($getParameters['special'])) {
            return null;
        }

        $specialIdentifier = StringUtil::trim($getParameters['special']);
        if (empty($specialIdentifier) || mb_strlen($specialIdentifier) > 255) {
            return null;
        }

        $discountList = new DiscountList();
        $discountList->getConditionBuilder()->add('discount.specialIdentifier = ?', [$specialIdentifier]);
        $discountList->getConditionBuilder()->add('discount.hosts LIKE ?', ['%' . $this->host . '%']);
        $discountList->readObjects();

        return count($discountList) > 0 ? $discountList : null;
    }
}
