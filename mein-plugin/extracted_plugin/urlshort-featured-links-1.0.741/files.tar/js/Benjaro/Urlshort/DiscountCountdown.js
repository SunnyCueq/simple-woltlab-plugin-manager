/**
 * Discount countdown timer - Updates countdown display every second.
 * Handles both single countdown initialization and list-based countdowns.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 * @module      Benjaro/Urlshort/DiscountCountdown
 * @since       6.3.2
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
define(["require", "exports", "WoltLabSuite/Core/Language"], function (require, exports, Language) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.init = init;
    exports.initList = initList;
    Language = __importStar(Language);
    /**
     * Formats seconds into countdown string (DD:HH:MM:SS).
     *
     * @param {number} seconds The number of seconds to format
     * @returns {string} Formatted countdown string
     */
    function formatCountdown(seconds) {
        // Round to integer to avoid decimal places
        const totalSeconds = Math.floor(seconds);
        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const secs = totalSeconds % 60;
        return `${String(days).padStart(2, "0")}:${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    }
    /**
     * Initializes a single countdown timer.
     * Updates the display every second until countdown expires.
     *
     * @param {string} elementId ID of the element to update
     * @param {number} initialSeconds Initial remaining seconds from server
     * @returns {void}
     */
    function init(elementId, initialSeconds) {
        const element = document.getElementById(elementId);
        if (!element) {
            console.error(`DiscountCountdown: Element #${elementId} not found`);
            return;
        }
        let remainingSeconds = initialSeconds;
        // Update immediately
        updateDisplay(element, remainingSeconds);
        // Update every second
        const interval = window.setInterval(() => {
            remainingSeconds--;
            if (remainingSeconds <= 0) {
                // Countdown expired
                element.textContent = Language.get("wcf.urlshort.countdown.expired");
                window.clearInterval(interval);
            }
            else {
                updateDisplay(element, remainingSeconds);
            }
        }, 1000);
    }
    /**
     * Updates the countdown display element with formatted time.
     *
     * @param {HTMLElement} element DOM element to update
     * @param {number} seconds Remaining seconds
     * @returns {void}
     */
    function updateDisplay(element, seconds) {
        element.textContent = formatCountdown(seconds);
    }
    /**
     * Initializes all countdowns in a list (e.g., ACP discount list).
     * Finds all elements with class "discount-countdown" and data-end-time attribute.
     * Calculates remaining time from server timestamp and updates every second.
     *
     * @returns {void}
     */
    function initList() {
        const countdownElements = document.querySelectorAll(".discount-countdown[data-end-time]");
        countdownElements.forEach((element) => {
            const endTimeStr = element.dataset.endTime;
            if (!endTimeStr) {
                return;
            }
            const endTime = parseInt(endTimeStr, 10);
            if (isNaN(endTime) || endTime <= 0) {
                return;
            }
            const displayElement = element.querySelector(".countdown-display");
            if (!displayElement) {
                return;
            }
            // Calculate initial remaining seconds
            const now = Math.floor(Date.now() / 1000);
            let remainingSeconds = endTime - now;
            // Update immediately
            if (remainingSeconds > 0) {
                updateDisplay(displayElement, remainingSeconds);
            }
            else {
                displayElement.textContent = Language.get("wcf.urlshort.countdown.expired");
                element.classList.remove("green");
                element.classList.add("red");
                return;
            }
            // Update every second
            const interval = window.setInterval(() => {
                const currentTime = Math.floor(Date.now() / 1000);
                remainingSeconds = endTime - currentTime;
                if (remainingSeconds <= 0) {
                    displayElement.textContent = Language.get("wcf.urlshort.countdown.expired");
                    element.classList.remove("green");
                    element.classList.add("red");
                    window.clearInterval(interval);
                }
                else {
                    updateDisplay(displayElement, remainingSeconds);
                }
            }, 1000);
        });
    }
});
