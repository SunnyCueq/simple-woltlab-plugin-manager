"use strict";
// Dummy TypeScript file to satisfy tsc
