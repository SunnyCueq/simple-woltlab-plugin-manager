/**
 * Guest reaction handler for URL shortener.
 * 
 * Extends WoltLab's UiReactionHandler to support guest reactions via GuestReactionAction.
 * Handles data conversion and Web Component updates for reaction summaries.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 * @module      Benjaro/Urlshort/Ui/GuestReactionHandler
 * @since       2.3.6
 */

import UiReactionHandler from "WoltLabSuite/Core/Ui/Reaction/Handler";

/**
 * Configuration options for guest reaction handler.
 *
 * @interface GuestReactionHandlerOptions
 * @property {string} objectType - Object type identifier (e.g., "urlshort\\data\\url\\LikeableUrl")
 * @property {string} containerSelector - CSS selector for the container element
 * @property {string} buttonSelector - CSS selector for the reaction button
 */
interface GuestReactionHandlerOptions {
    objectType: string;
    containerSelector: string;
    buttonSelector: string;
}

/**
 * Reaction data structure from server response.
 * Can be either a number (reaction count) or an object with reactionCount property.
 *
 * @interface ReactionDataValue
 * @property {number} [reactionCount] - Reaction count (if value is an object)
 */
interface ReactionDataValue {
    reactionCount?: number;
}

/**
 * Server response structure for reaction actions.
 *
 * @interface ReactionResponse
 * @property {number} objectID - Object ID that was reacted to
 * @property {number} reactionTypeID - Type ID of the reaction
 * @property {Record<string, number | ReactionDataValue>} reactions - Map of reaction type IDs to counts
 */
interface ReactionResponse {
    objectID: number;
    reactionTypeID: number;
    reactions: Record<string, number | ReactionDataValue>;
}

/**
 * Converts reaction data from server format to Map format required by Web Component.
 * Handles both object format ({reactionCount: number}) and direct number format.
 *
 * @param {Record<string, number | ReactionDataValue>} reactions - Reaction data from server
 * @returns {Map<number, number>} Map of reaction type ID to count
 */
function convertReactionsToMap(reactions: Record<string, number | ReactionDataValue>): Map<number, number> {
    const reactionsMap = new Map<number, number>();
    
    Object.entries(reactions).forEach((entry) => {
        const key = entry[0];
        const value = entry[1];
        
        // Extract reactionCount from object (if present), otherwise use value directly
        const reactionCount = (typeof value === 'object' && value !== null && 'reactionCount' in value)
            ? value.reactionCount || 0
            : (typeof value === 'number' ? value : 0);
        
        reactionsMap.set(parseInt(key, 10), reactionCount);
    });
    
    return reactionsMap;
}

/**
 * Updates the Web Component with new reaction data.
 *
 * @param {string} objectType - Object type identifier
 * @param {number} objectId - Object ID
 * @param {Map<number, number>} reactionsMap - Map of reaction type IDs to counts
 * @param {number} reactionTypeID - Selected reaction type ID
 * @returns {void}
 */
function updateReactionComponent(
    objectType: string,
    objectId: number,
    reactionsMap: Map<number, number>,
    reactionTypeID: number
): void {
    const selector = `woltlab-core-reaction-summary[object-type="${objectType}"][object-id="${objectId}"]`;
    const component = document.querySelector(selector) as any;
    
    if (component && typeof component.setData === 'function') {
        component.setData(reactionsMap, reactionTypeID);
    }
}

/**
 * Creates and configures a guest reaction handler.
 * 
 * The handler extends WoltLab's standard UiReactionHandler to:
 * - Use GuestReactionAction instead of standard ReactionAction
 * - Convert reaction data format for Web Component compatibility
 * - Update both Web Component and button state
 *
 * @param {GuestReactionHandlerOptions} options - Configuration options
 * @returns {UiReactionHandler} Configured reaction handler instance
 */
export function createHandler(options: GuestReactionHandlerOptions): UiReactionHandler {
    const handler = new UiReactionHandler(options.objectType, {
        containerSelector: options.containerSelector,
        buttonSelector: options.buttonSelector,
        isSingleItem: false
    });
    
    // Override _ajaxSetup to use GuestReactionAction
    // This ensures guest reactions are included in the response
    handler._ajaxSetup = function(): { data: { actionName: string; className: string } } {
        return {
            data: {
                actionName: 'react',
                className: 'urlshort\\data\\reaction\\GuestReactionAction'
            }
        };
    };
    
    // Override _ajaxSuccess to handle data conversion and component updates
    // The server may return reactions as objects with reactionCount property
    // or as direct numbers, so we need to normalize the format
    const originalAjaxSuccess = handler._ajaxSuccess;
    handler._ajaxSuccess = function(data: { returnValues?: ReactionResponse }): void {
        if (data.returnValues && data.returnValues.reactions) {
            const objectId = ~~data.returnValues.objectID;
            const reactionsMap = convertReactionsToMap(data.returnValues.reactions);
            
            // Update Web Component
            updateReactionComponent(
                options.objectType,
                objectId,
                reactionsMap,
                data.returnValues.reactionTypeID
            );
            
            // Update React button state
            if (typeof this._updateReactButton === 'function') {
                this._updateReactButton(objectId, data.returnValues.reactionTypeID);
            }
        } else {
            // Fallback: Call original function if data format is unexpected
            if (originalAjaxSuccess) {
                return originalAjaxSuccess.call(this, data);
            }
        }
    };
    
    return handler;
}

export default { createHandler };

