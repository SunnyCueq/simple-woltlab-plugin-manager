/**
 * Handles discount code copying functionality.
 * Enables click-to-copy functionality for discount codes on the redirect page.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 * @module      Benjaro/Urlshort/Ui/DiscountCodes
 */

import * as Clipboard from "WoltLabSuite/Core/Clipboard";
import * as UiNotification from "WoltLabSuite/Core/Ui/Notification";
import * as Language from "WoltLabSuite/Core/Language";

/**
 * Copies text to clipboard and shows a success or error notification.
 *
 * @param {string} text The text to copy to clipboard
 * @returns {Promise<void>}
 */
async function copyTextToClipboard(text: string): Promise<void> {
  try {
    await Clipboard.copyTextToClipboard(text);
    UiNotification.show(Language.get("wcf.urlshort.copyUrl.success"), null, "success");
  } catch (error) {
    UiNotification.show(Language.get("wcf.urlshort.copyUrl.error"), null, "error");
    console.log(error?.toString());
  }
}

/**
 * Sets up click-to-copy functionality for discount codes.
 * Finds all elements with class "copyableCode" and adds click handlers.
 *
 * @returns {void}
 */
export function setup(): void {
  // Setup copyableCode elements - click on <kbd class="copyableCode"> to copy
  document.querySelectorAll(".copyableCode").forEach((element) => {
    // Skip if already has event listener
    if ((element as HTMLElement).dataset.hasCopyListener === "true") {
      return;
    }
    
    (element as HTMLElement).dataset.hasCopyListener = "true";
    
    element.addEventListener("click", (event) => {
      event.preventDefault();
      const code = (element as HTMLElement).dataset.code;
      if (code) {
        copyTextToClipboard(code);
      }
    });
  });
}

export default { setup };
