/**
 * Overrides the button text "Weiterleitung bestätigen" to "Empfehlung ansehen".
 * Supports multiple languages via hardcoded fallback texts.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 * @module      Benjaro/Urlshort/Ui/ButtonTextOverride
 * @since       2.2.0
 */

/**
 * Sets up the button text override functionality.
 * Overrides the redirect confirmation button text and patches setInterval
 * to handle dynamically updated button text.
 *
 * @returns {void}
 */
export function setup(): void {
    const buttonId = 'forwardButton';
    /** Old texts in all supported languages */
    const oldTexts = [
        'Weiterleitung bestätigen', // German
        'Confirm redirect' // English
    ];
    
    /**
     * Overrides the button text if it matches old texts.
     * Supports both standard buttons and enhanced 3D buttons.
     *
     * @returns {void}
     */
    function overrideButtonText(): void {
        const button = document.getElementById(buttonId);
        if (!button) {
            return;
        }
        
        // Check if button is enhanced (has new structure)
        const isEnhanced = button.classList.contains('forwardButtonEnhanced');
        let textElement: HTMLElement | null = null;
        let currentText = '';
        
        if (isEnhanced) {
            // Enhanced button: update text in .forwardButtonEnhanced__text
            textElement = button.querySelector('.forwardButtonEnhanced__text') as HTMLElement;
            if (textElement) {
                currentText = textElement.textContent?.trim() || '';
            }
        } else {
            // Standard button: update button directly
            currentText = button.textContent?.trim() || '';
        }
        
        if (oldTexts.includes(currentText) || currentText === 'urlshort.redirect.confirm') {
            // Use hardcoded texts based on current language
            const lang = document.documentElement.lang || 'de';
            const newText = lang.startsWith('de') ? 'Empfehlung ansehen' : 'View recommendation';
            
            if (isEnhanced && textElement) {
                textElement.textContent = newText;
            } else {
                button.textContent = newText;
            }
        }
    }
    
    // Override initial text
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', overrideButtonText);
    } else {
        overrideButtonText();
    }
    
    // Also check after short delay (for dynamically loaded content)
    setTimeout(overrideButtonText, 100);
    setTimeout(overrideButtonText, 500);
    
    // Override countdown interval if present
    if (typeof window.setInterval !== 'undefined' && !(window as any)._setIntervalPatched) {
        (window as any)._setIntervalPatched = true;
        const originalSetInterval = window.setInterval;
        window.setInterval = function(handler: TimerHandler, timeout?: number): number {
            return originalSetInterval(function() {
                if (typeof handler === 'function') {
                    handler();
                }
                // Check and override after each callback
                overrideButtonText();
            }, timeout);
        };
    }
}

export default { setup };

