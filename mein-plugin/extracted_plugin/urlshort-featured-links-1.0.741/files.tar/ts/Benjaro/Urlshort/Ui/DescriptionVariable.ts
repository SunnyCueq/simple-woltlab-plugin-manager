/**
 * Description variable inserter - Makes variables clickable to insert into textarea.
 * Used in ACP forms to easily insert Smarty variables into description text fields.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2022-2025 Benjaro
 * @license     License for Commercial Plugins <https://benjaro.info>
 * @module      Benjaro/Urlshort/Ui/DescriptionVariable
 * @since       6.4.0
 */

// No import needed - using native DOM API

/**
 * Inserts variable at cursor position in textarea.
 * Maintains cursor position and triggers input event for form validation.
 *
 * @param {HTMLTextAreaElement} textarea The textarea element
 * @param {string} variable The variable to insert
 * @returns {void}
 */
function insertVariable(textarea: HTMLTextAreaElement, variable: string): void {
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const before = text.substring(0, start);
    const after = text.substring(end, text.length);

    // Insert variable at cursor position
    textarea.value = before + variable + after;

    // Set cursor position after inserted variable
    const newPosition = start + variable.length;
    textarea.setSelectionRange(newPosition, newPosition);

    // Focus textarea
    textarea.focus();

    // Trigger input event for form validation
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
}

/**
 * Initializes clickable variable elements.
 * Finds the description textarea and all clickable variable badges,
 * then sets up click handlers to insert variables at cursor position.
 *
 * @returns {void}
 */
export function setup(): void {
    // Find the descriptionText textarea (FormBuilder uses prefixed IDs)
    // Try different possible ID formats
    let textarea: HTMLTextAreaElement | null = document.getElementById("descriptionText") as HTMLTextAreaElement | null;
    if (!textarea) {
        textarea = document.querySelector('textarea[name="descriptionText"]') as HTMLTextAreaElement | null;
    }
    if (!textarea) {
        textarea = document.querySelector('textarea[id*="descriptionText"]') as HTMLTextAreaElement | null;
    }
    if (!textarea) {
        return;
    }

    // Find all clickable variable elements
    const elements = document.querySelectorAll<HTMLElement>(".descriptionVariable");

    elements.forEach((element) => {
        const variable = element.dataset.variable;

        if (!variable) {
            console.error("DescriptionVariable: Missing data-variable attribute");
            return;
        }

        // Click event (styling handled by CSS: .descriptionVariable.badge)
        element.addEventListener("click", (event) => {
            event.preventDefault();
            insertVariable(textarea!, variable);
        });
    });
}

