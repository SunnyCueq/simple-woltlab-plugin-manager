// Dummy TypeScript file to satisfy tsc
