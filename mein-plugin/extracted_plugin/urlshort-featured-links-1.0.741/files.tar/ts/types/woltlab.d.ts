/**
 * Type definitions for WoltLab Suite Core modules
 * These are minimal type definitions for the modules we use
 */

declare module 'WoltLabSuite/Core/Language' {
    export function get(key: string, parameters?: Record<string, string | number>): string;
    export function add(key: string, value: string): void;
    export function addObject(data: Record<string, string>): void;
}

declare module 'WoltLabSuite/Core/Clipboard' {
    export function copyTextToClipboard(text: string): Promise<void>;
}

declare module 'WoltLabSuite/Core/Ui/Notification' {
    export function show(message?: string, callback?: (() => void) | null, cssClassName?: string): void;
}

declare module 'WoltLabSuite/Core/Environment' {
    export function platform(): 'desktop' | 'mobile';
    export function browser(): string;
}

declare module 'WoltLabSuite/Core/Ui/Reaction/Handler' {
    export default class UiReactionHandler {
        constructor(objectType: string, options: {
            containerSelector: string;
            buttonSelector: string;
            isSingleItem: boolean;
        });
        _ajaxSetup(): { data: { actionName: string; className: string } };
        _ajaxSuccess(data: any): void;
        _updateReactButton(objectId: number, reactionTypeID: number): void;
    }
}

declare module '3rdParty/three.min' {
    export * from 'three';
}

