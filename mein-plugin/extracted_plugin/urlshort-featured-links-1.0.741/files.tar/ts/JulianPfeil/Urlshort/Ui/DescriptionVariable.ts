/**
 * Description variable inserter - Makes variables clickable to insert into textarea.
 *
 * @author      Sunny C. <https://benjaro.info>
 * @copyright   2025 Sunny C.
 * @license     Commercial License
 * @package     de.julian-pfeil.urlshort.featuredLinks
 * @since       6.4.0
 */

// No import needed - using native DOM API

/**
 * Inserts variable at cursor position in textarea.
 *
 * @param textarea - The textarea element
 * @param variable - The variable to insert
 */
function insertVariable(textarea: HTMLTextAreaElement, variable: string): void {
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const before = text.substring(0, start);
    const after = text.substring(end, text.length);

    // Insert variable at cursor position
    textarea.value = before + variable + after;

    // Set cursor position after inserted variable
    const newPosition = start + variable.length;
    textarea.setSelectionRange(newPosition, newPosition);

    // Focus textarea
    textarea.focus();

    // Trigger input event for form validation
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
}

/**
 * Initializes clickable variable elements.
 */
export function setup(): void {
    // Find the descriptionText textarea (FormBuilder uses prefixed IDs)
    // Try different possible ID formats
    let textarea: HTMLTextAreaElement | null = document.getElementById("descriptionText") as HTMLTextAreaElement | null;
    if (!textarea) {
        textarea = document.querySelector('textarea[name="descriptionText"]') as HTMLTextAreaElement | null;
    }
    if (!textarea) {
        textarea = document.querySelector('textarea[id*="descriptionText"]') as HTMLTextAreaElement | null;
    }
    if (!textarea) {
        return;
    }

    // Find all clickable variable elements
    const elements = document.querySelectorAll<HTMLElement>(".descriptionVariable");

    elements.forEach((element) => {
        const variable = element.dataset.variable;

        if (!variable) {
            console.error("DescriptionVariable: Missing data-variable attribute");
            return;
        }

        // Visual feedback: pointer cursor and hover effect
        element.style.cursor = "pointer";
        element.style.textDecoration = "underline";
        element.style.color = "var(--wcfContentLink)";

        // Click event
        element.addEventListener("click", (event) => {
            event.preventDefault();
            insertVariable(textarea!, variable);
        });
    });
}

