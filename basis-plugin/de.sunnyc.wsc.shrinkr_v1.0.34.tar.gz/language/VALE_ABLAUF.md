# Vale-Prüfung aller Plugin-Texte

Vale kann die XML-Sprachdateien nicht direkt prüfen (XSLT-Fehler). Daher werden die sichtbaren Texte zuerst extrahiert und als Markdown-Dateien mit Vale geprüft.

## Ablauf

1. **Texte extrahieren** (aus dem Verzeichnis `basis-plugin/`):
   ```bash
   python3 temp_edit/language/extract_for_vale.py
   ```
   Erzeugt:
   - `temp_edit/language/de_texte_fuer_vale.md`
   - `temp_edit/language/en_texte_fuer_vale.md`

2. **Vale ausführen** (aus `basis-plugin/`):
   ```bash
   vale --config=.vale.ini temp_edit/language/de_texte_fuer_vale.md
   vale --config=.vale.ini temp_edit/language/en_texte_fuer_vale.md
   ```

3. **Meldungen beheben**: Vale gibt Dateiname + Zeilennummer aus. In der `.md`-Datei steht oberhalb jeder Textpassage der Sprachschlüssel in einem Code-Block (``` key ```). So lässt sich jede Meldung der richtigen Stelle in `de.xml` bzw. `en.xml` zuordnen.

## Bereits umgesetzt

- **z. B.** statt **z.B.** (ein Leerzeichen nach dem Punkt, Duden-konform)
- **Link(s)** / **Button(s)** ersetzt durch „Link bzw. mehreren“ / „Custom Button bzw. mehreren“ (Vale-Regel OptionalPlurals)
- Glossar `.vale/Vocab/Shr1nkr/accept.txt` um DEMO, TOKEN, GANZ, OBEN, z. B. ergänzt

## Hinweis

Vale-Stilregeln (Google) sind für englische Dokumentation ausgelegt. Einige Meldungen (z. B. Doppelpunkt + Großbuchstabe, Klammern) sind für deutsche UI-Texte optional – bei Bedarf in der Redaktion prüfen oder in `.vale.ini` gezielt abschwächen.
