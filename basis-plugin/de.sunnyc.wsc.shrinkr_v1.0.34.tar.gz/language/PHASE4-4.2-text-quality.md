# Phase 4.2 — Text-Qualitätsstandard: Audit-Tabelle

Regeln: 1) Labels kurz (2–4 Wörter), 2) Beschreibungen mit Zweck/Auswirkung, 3) Buttons mit Aktion, 4) Fehlermeldungen: Was passiert + was tun, 5) Einheitliche Begriffe, 6) Kein Fachchinesisch, 7) Kein Fülltext.

| Key | Sprache | Original | Korrigierte Version | Betroffene Regel(n) |
|-----|---------|----------|---------------------|----------------------|
| shrinkr.acp.url.hash.error.tooLong | de | Der Kurz-URL-Teil (Hash) ist zu lang. Bitte kürzen Sie ihn auf höchstens 64 Zeichen. | Der Kurz-URL-Teil ist zu lang. Bitte kürzen Sie ihn auf höchstens 64 Zeichen. | 6 (Fachchinesisch: Hash) |
| wcf.acp.option.category.shrinkr.hash | de | Hash-Konfiguration | Einstellungen für Kurz-URL-Teil | 6 |
| wcf.acp.option.shrinkr_hash_length | de | Hash-Länge | Länge des Kurz-URL-Teils | 6 |
| wcf.acp.option.shrinkr_hash_prefix | de | Hash-Präfix | Präfix für Kurz-URL-Teil | 6 |
| wcf.acp.option.shrinkr_pattern | de | Hash-RegEx-Pattern | Zeichenvorgabe für Kurz-URL-Teil | 6 (RegEx/Pattern) |
| wcf.acp.option.shrinkr_hash_length.description | de | Der Hash ist der kurze Code in jeder Kurz-URL … | Der Kurz-URL-Teil ist der kurze Code in jeder Kurz-URL (z. B. „abc1“ in /r/abc1/). … | 6 |
| wcf.acp.option.shrinkr_hash_prefix.description | de | … vor jedem Hash. … Präfix „link-“ + Hash „abc“ … | … vor jedem Kurz-URL-Teil. … Präfix „link-“ + Kurz-URL-Teil „abc“ … | 6 |
| wcf.shrinkr.url.hash | de | Hash | Kurz-URL-Teil | 6 |
| wcf.shrinkr.url.hash.description | de | Der Hash ist der kurze Teil … | Der Kurz-URL-Teil ist der kurze Teil in der Kurz-URL … | 6 |
| shrinkr.acp.url.hash.error.notMatchesPattern | de | … die vom Administrator erlaubten Zeichen … | … die erlaubten Zeichen (z. B. Zahlen, Kleinbuchstaben, Bindestriche). | 6 („vom Administrator“ redundant) |
| wcf.acp.option.category.shrinkr.hash | en | Hash Configuration | Short URL segment settings | 6 |
| wcf.acp.option.shrinkr_hash_length | en | Hash length | Short URL segment length | 6 |
| wcf.acp.option.shrinkr_hash_prefix | en | Hash prefix | Prefix for short URL segment | 6 |
| wcf.acp.option.shrinkr_pattern | en | Hash RegEx pattern | Character pattern for short URL segment | 6 |
| shrinkr.acp.url.hash.error.tooLong | en | (prüfen ob EN-Text „Hash“ enthält) | Short URL segment is too long. Please shorten it to 64 characters at most. | 6 |

Weitere Stichproben: Fehlermeldungen erfüllen bereits „Was passiert + was tun“. Buttons sind handlungsbezogen. Begriff „Plugin“ einheitlich. Die obigen Anpassungen beseitigen das sichtbare Fachchinesisch „Hash“/„RegEx“ zugunsten von „Kurz-URL-Teil“ bzw. „Zeichenvorgabe“.
