# Checkliste: Plugin-Texte überarbeiten (de.xml / en.xml)

Leitprinzip: **Maximal verständlich für Laien** – kurze Sätze, einheitliche Begriffe (Kurz-URL, Weiterleitungsseite, Featured Link, Custom Button, Einmalnachricht, Gutschein), Querbezüge wo Funktionen voneinander abhängen.

Reihenfolge der Überarbeitung (Plan): **1. Optionen → 2. ACP-Menü & Listen → 3. Statistik → 4. Dashboard → 5. Formulare & Buttons.**

---

## 1. Optionen (wcf.acp.option)

- [ ] **Kategorien:** category.shrinkr, .general, .redirect, .target, .hash, .interaction (+ .description), .design (+ .description), .advanced (+ .description)
- [ ] **Allgemein:** shrinkr_active, shrinkr_counter_active, shrinkr_forwarding_must_confirmed, shrinkr_time_until_forwarding, shrinkr_expertmode_active, shrinkr_dashboard_enabled, shrinkr_normal_page_mode (jeweils + .description, formal + informal)
- [ ] **Hash/Ziel:** shrinkr_hash_length, shrinkr_hash_prefix, shrinkr_only_https, shrinkr_deactivate_forwarding_chains, shrinkr_pattern, shrinkr_external_url (+ .description)
- [ ] **Experte/Demo:** shrinkr_install_demo_data, shrinkr_remove_shrinkr_prefix (+ .description)
- [ ] **Interaktion:** shrinkr_enable_reactions, shrinkr_enable_guest_reactions, shrinkr_enable_share_button, shrinkr_enable_descriptions, shrinkr_password_session_storage, shrinkr_rate_limit_* (+ .description)
- [ ] **Design:** shrinkr_enable_custom_forward_button (+ .label, .description, .preview), shrinkr_title_icon, shrinkr_enable_theme_effects, shrinkr_enable_qr_code (+ .description)

---

## 2. ACP-Menü & Listen (shrinkr.acp.menu + list.title/list.description)

- [ ] **Menü:** shrinkr.acp.menu.badge.*, .link.menu, .link.link.*, .link.discount.*, .link.voucher.*, .link.onetimemessage.*, .link.description.*, .link.featuredLink.*, .link.customButton.*, .link.special.*, .link.theme.*, .link.statistic.*, .link.settings
- [ ] **Listen-Beschreibungen:** shrinkr.acp.url.list.description, .list.password.description; shrinkr.acp.discount.list.description; shrinkr.acp.featuredLink.list.description; shrinkr.acp.special.list.description; shrinkr.acp.description.list.description; shrinkr.acp.theme.list.description; shrinkr.acp.customButton.list.description; shrinkr.acp.voucher.*.list.description; shrinkr.acp.otm.list.description (+ ggf. .password.description)

---

## 3. Statistik (shrinkr.acp.statistic)

- [ ] **Titel & Einleitung:** title, description, comingSoon.*
- [ ] **Tabs/Überschriften:** systemOverview (+ .description), overview (+ .description), visitTrend, topLinks, visitors (+ .description), hourlyDistribution, interactionTypes, filter, period, linkFilter.description, tabs
- [ ] **Kennzahlen:** today, thisWeek, total (+ .description), uniqueVisitors (+ .description), avgClicksPerLink, conversionRate, mostActiveHour, mostActiveWeekday
- [ ] **Bereiche:** linkPerformance, interactionDetails, timeAnalysis, trafficSources, browserOS, countries, customButtons, featuredLinks, specials, reactions, linkButtonInteractions, devices, visitorTypes, avgSessionDuration
- [ ] **Filter:** startDate.description, endDate.description, linkFilter.description (Hilfetext: optional einen Link filtern, Vorschläge)

---

## 4. Dashboard (shrinkr.acp.dashboard)

- [ ] box.title, version, totalLinks, totalClicks, totalVisitors, activeSpecials, featuredLinks, vouchersTotal, oneTimeMessagesTotal, viewStatistics, manageLinks, support, supportUrl, copyright

---

## 5. Formulare & Buttons

- [ ] **Optionen:** shrinkr.acp.option.reload
- [ ] **URL/Formulare:** shrinkr.acp.url.add, .edit, .list, .delete.confirmMessage, .success.*, .hash.error.*, .url.error.*, removeShrinkrPrefix.info.*, rewrite.*
- [ ] **Voucher/OTM:** shrinkr.voucher.*, shrinkr.otm.*, shrinkr.acp.voucher.*, shrinkr.acp.otm.*
- [ ] **Allgemein:** shrinkr.acp.form.enable, sortOrder; wcf.shrinkr.* (copyUrl, password, redirect, featured, customButton, special, description, theme, …)
- [ ] **Fehlermeldungen, Platzhalter, formHelp:** alle .error.*, .placeholder, .description in Formularkontext

---

## Begriffe konsistent (Abschluss)

- **Kurz-URL** (nicht wechselnd Link/URL/Shortlink)
- **Weiterleitungsseite** (Ort wo Nutzer vor der Ziel-URL landen)
- **Featured Link** / **Custom Button** / **Special** / **Theme** / **Einmalnachricht** / **Gutschein**
- **Sie** vs. **du** (variant="informal") überall passend

Nach jeder Kategorie: **Vale** (check_text) auf geänderte Fließtexte anwenden.
