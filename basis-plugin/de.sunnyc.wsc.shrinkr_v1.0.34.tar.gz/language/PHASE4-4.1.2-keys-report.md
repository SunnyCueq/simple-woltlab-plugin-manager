# Phase 4.1.2 — Language Keys Abgleich

## Durchführung

- Skript: `tools/check-language-keys.py` (Extraktion aus de.xml/en.xml sowie aus PHP, Templates, JS).
- Definierte Keys (Basis, ohne variant): DE 957, EN 955.
- Im Code referenzierte Keys (wcf.* / shrinkr.*): 262.

## Verwaiste Keys (in XML, nicht explizit im Plugin-Code referenziert)

Die Mehrzahl der „verwaisten“ Keys wird vom WoltLab-Framework geladen (z. B. Optionen über `wcf.acp.option.*`, Formular-Labels, Statistik-UI). Diese nicht entfernen; sie sind in der Redaktion/ACP sichtbar.

## Fehlende Keys (im Code referenziert, in Plugin-Sprachdateien ergänzt)

- **Plugin-spezifisch ergänzt:**
  - `wcf.shrinkr.url.linkTitle` — in de.xml und en.xml ergänzt (Label für Linktitel/Featured-Links-Spalte).
  - `wcf.shrinkr.url.linkTitle.description` — in de.xml und en.xml ergänzt (Placeholder/Beschreibung).
  - `shrinkr.acp.statistic.tab.voucher` — in en.xml ergänzt (Tab „Gutscheine“).
  - `shrinkr.acp.statistic.tab.onetime` — in en.xml ergänzt (Tab „Einmal-Nachrichten“).

- **Nicht ergänzt (WoltLab-Core):**  
  `wcf.global.button.delete`, `wcf.global.button.edit`, `wcf.global.filter`, `wcf.global.form.error.empty`, `wcf.global.form.required`, `wcf.global.noItems`, `wcf.global.objectID`, `wcf.acp.option.type.boolean.no/yes`, `wcf.acp.rewrite.fileContent/filename`, `wcf.message.share`, `wcf.page.sidebar.left`, `wcf.reactions.react` stammen aus dem Core und sind nicht in den Plugin-Sprachdateien zu pflegen.

---

## 4.1.3 Key-Namen (WoltLab-Konvention)

Prüfung: Alle Keys folgen der üblichen Hierarchie `wcf.acp.<bereich>.<element>`, `shrinkr.acp.<bereich>.<element>`, `wcf.shrinkr.<bereich>.<element>`; mehrteilige Segmente in camelCase (z. B. `beforeRedirectContainer`). Keine offensichtlichen Verstöße; keine Umbenennung vorgenommen.

---

## 4.1.4 Pluralisierung

- **Templates:** Kein Einsatz von `{#$count|plural do=...}`; in statisticClick.tpl wird nur `({$count|intval})` ausgegeben (reine Zahl, kein Satz mit Einheit).
- **StatisticUtil (Dauer):** Verwendet `shrinkr.acp.statistic.duration.hours/minutes/seconds` mit Abkürzungen (DE: Std, Min, Sek; EN: h, Min, Sec). Diese Abkürzungen funktionieren für Singular und Plural (z. B. „1 Std“, „2 Std“); keine zusätzlichen Plural-Keys nötig.
- **Redirect-Countdown:** `shrinkr.redirect.second` und `shrinkr.redirect.seconds` sind in DE und EN vorhanden; das Template wählt per `seconds === 1` die richtige Form. Pluralisierung dort korrekt.
- **Ergebnis:** Keine Änderungen erforderlich.

---

## 4.1.1 de-informal (Vollständigkeit)

Es gibt keine separate Datei `de-informal.xml`; informelle Anrede wird in **de.xml** über `<item ... variant="informal">` abgedeckt. Stichprobe: Alle geprüften ACP-Optionstexte mit „Sie“/„Ihre“/„Ihnen“ haben eine passende informal-Variante („du“/„deine“/„dir“). Keine fehlenden informal-Einträge ergänzt.
