#!/usr/bin/env python3
"""
Extrahiert alle CDATA-Texte aus de.xml und en.xml in Markdown-Dateien,
die mit Vale geprüft werden können (Schlüssel in Code-Blöcken, damit
Vale nur die sichtbaren UI-Texte prüft).

Aufruf aus basis-plugin/:
  python3 temp_edit/language/extract_for_vale.py

Danach Vale ausführen (aus basis-plugin/):
  vale --config=.vale.ini temp_edit/language/de_texte_fuer_vale.md
  vale --config=.vale.ini temp_edit/language/en_texte_fuer_vale.md
"""

import re
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent


def extract(path_in: Path, path_out: Path) -> int:
    content = path_in.read_text(encoding="utf-8")
    pattern = re.compile(
        r'<item\s+name="([^"]+)"[^>]*>\s*<!\[CDATA\[(.*?)\]\]>\s*</item>',
        re.DOTALL,
    )
    matches = pattern.findall(content)
    blocks = []
    for key, text in matches:
        text_clean = text.strip().replace("\r", "")
        blocks.append(f"```\n{key}\n```\n\n{text_clean}\n")
    path_out.write_text("\n---\n\n".join(blocks), encoding="utf-8")
    return len(matches)


def main() -> None:
    n_de = extract(
        SCRIPT_DIR / "de.xml",
        SCRIPT_DIR / "de_texte_fuer_vale.md",
    )
    n_en = extract(
        SCRIPT_DIR / "en.xml",
        SCRIPT_DIR / "en_texte_fuer_vale.md",
    )
    print(f"DE: {n_de} Einträge → de_texte_fuer_vale.md")
    print(f"EN: {n_en} Einträge → en_texte_fuer_vale.md")
    print("\nVale ausführen (im basis-plugin-Verzeichnis):")
    print("  vale --config=.vale.ini temp_edit/language/de_texte_fuer_vale.md")
    print("  vale --config=.vale.ini temp_edit/language/en_texte_fuer_vale.md")


if __name__ == "__main__":
    main()
