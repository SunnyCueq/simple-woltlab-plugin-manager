```
wcf.acp.ad.location.category.de.sunnyc.wsc.shrinkr
```

Shr1nkr

---

```
wcf.acp.ad.location.de.sunnyc.wsc.shrinkr.beforeRedirectContainer
```

Vor dem Weiterleitungscontainer

---

```
wcf.acp.ad.location.de.sunnyc.wsc.shrinkr.afterRedirectContainer
```

Nach dem Weiterleitungscontainer

---

```
wcf.acp.option.category.shrinkr
```

Shr1nkr

---

```
wcf.acp.option.category.shrinkr.general
```

Allgemein

---

```
wcf.acp.option.category.shrinkr.redirect
```

Weiterleitung

---

```
wcf.acp.option.category.shrinkr.target
```

Ziel-URL

---

```
wcf.acp.option.category.shrinkr.hash
```

Hash-Konfiguration

---

```
wcf.acp.option.category.shrinkr.interaction
```

Interaktion

---

```
wcf.acp.option.category.shrinkr.interaction.description
```

Hier legen Sie fest, was Besucher auf der Weiterleitungsseite tun können: Reaktionen (z. B. Daumen hoch), Teilen-Button und Beschreibungstexte. Alle Optionen wirken nur, wenn der Shr1nkr unter „Allgemein“ aktiviert ist.

---

```
wcf.acp.option.category.shrinkr.interaction.description
```

Hier legst du fest, was Besucher auf der Weiterleitungsseite tun können: Reaktionen (z. B. Daumen hoch), Teilen-Button und Beschreibungstexte. Alle Optionen wirken nur, wenn der Shr1nkr unter „Allgemein“ aktiviert ist.

---

```
wcf.acp.option.category.shrinkr.design
```

Aussehen

---

```
wcf.acp.option.category.shrinkr.design.description
```

Hier gestalten Sie die Weiterleitungsseite: den Weiterleitungs-Button, ein Icon vor der Überschrift, Spezialeffekte (z. B. Schnee) und QR-Codes. Die Optionen greifen nur, wenn der Shr1nkr unter „Allgemein“ aktiviert ist.

---

```
wcf.acp.option.category.shrinkr.design.description
```

Hier gestaltest du die Weiterleitungsseite: den Weiterleitungs-Button, ein Icon vor der Überschrift, Spezialeffekte (z. B. Schnee) und QR-Codes. Die Optionen greifen nur, wenn der Shr1nkr unter „Allgemein“ aktiviert ist.

---

```
wcf.acp.option.category.shrinkr.advanced
```

Experte

---

```
wcf.acp.option.category.shrinkr.advanced.description
```

Nur für erfahrene Administratoren. Hier schalten Sie erweiterte Optionen frei (z. B. Demo-Daten, externe URL). <strong>Vorsicht:</strong> Falsche Einstellungen können den Shr1nkr lahmlegen. Aktivieren Sie diesen Bereich nur, wenn Sie wissen, was Sie tun.

---

```
wcf.acp.option.category.shrinkr.advanced.description
```

Nur für erfahrene Administratoren. Hier schaltest du erweiterte Optionen frei (z. B. Demo-Daten, externe URL). <strong>Vorsicht:</strong> Falsche Einstellungen können den Shr1nkr lahmlegen. Aktiviere diesen Bereich nur, wenn du weißt, was du tust.

---

```
wcf.acp.option.shrinkr_active
```

Aktiviere den Shr1nkr

---

```
wcf.acp.option.shrinkr_active.description
```

Schalten Sie den Shr1nkr hier ein. Erst wenn diese Option aktiv ist, können Sie Kurz-URLs anlegen und das Menü „Shr1nkr“ im ACP nutzen. Ohne Aktivierung sind alle anderen Shr1nkr-Optionen wirkungslos.

---

```
wcf.acp.option.shrinkr_active.description
```

Schalte den Shr1nkr hier ein. Erst wenn diese Option aktiv ist, kannst du Kurz-URLs anlegen und das Menü „Shr1nkr“ im ACP nutzen. Ohne Aktivierung sind alle anderen Shr1nkr-Optionen wirkungslos.

---

```
wcf.acp.option.shrinkr_counter_active
```

Aktiviere den Besuche-Zähler für Kurz-URLs

---

```
wcf.acp.option.shrinkr_counter_active.description
```

Zeigt an, wie oft eine Kurz-URL aufgerufen wurde. Der Zähler erscheint in der <a href="{link controller='ShrinkrLinkList'}{/link}">Liste Ihrer Kurz-URLs</a> (Menü: Shr1nkr → Links) und kann dort zurückgesetzt werden.

---

```
wcf.acp.option.shrinkr_counter_active.description
```

Zeigt an, wie oft eine Kurz-URL aufgerufen wurde. Der Zähler erscheint in der <a href="{link controller='ShrinkrLinkList'}{/link}">Liste deiner Kurz-URLs</a> (Menü: Shr1nkr → Links) und kann dort zurückgesetzt werden.

---

```
wcf.acp.option.shrinkr_forwarding_must_confirmed
```

Weiterleitung auf Knopfdruck

---

```
wcf.acp.option.shrinkr_forwarding_must_confirmed.description
```

Besucher sehen zuerst die Weiterleitungsseite und müssen auf einen Button klicken, um zur Ziel-URL zu gelangen. So verhindern Sie automatische Weiterleitungen. Wenn Sie „Verzögerte Weiterleitung“ nutzen, ist der Button erst nach Ablauf der Wartezeit klickbar.

---

```
wcf.acp.option.shrinkr_forwarding_must_confirmed.description
```

Besucher sehen zuerst die Weiterleitungsseite und müssen auf einen Button klicken, um zur Ziel-URL zu gelangen. So verhinderst du automatische Weiterleitungen. Wenn du „Verzögerte Weiterleitung“ nutzt, ist der Button erst nach Ablauf der Wartezeit klickbar.

---

```
wcf.acp.option.shrinkr_time_until_forwarding
```

Verzögerte Weiterleitung (in Sekunden)

---

```
wcf.acp.option.shrinkr_time_until_forwarding.description
```

Besucher sehen die Weiterleitungsseite für so viele Sekunden, wie Sie hier eintragen. Danach erfolgt die Weiterleitung zur Ziel-URL. Beispiel: 5 = 5 Sekunden Wartezeit. Mit 0 leiten Sie sofort weiter (keine Wartezeit). Wenn „Weiterleitung auf Knopfdruck“ aktiv ist, erscheint der Button erst nach Ablauf dieser Zeit.

---

```
wcf.acp.option.shrinkr_time_until_forwarding.description
```

Besucher sehen die Weiterleitungsseite für so viele Sekunden, wie du hier einträgst. Danach erfolgt die Weiterleitung zur Ziel-URL. Beispiel: 5 = 5 Sekunden Wartezeit. Mit 0 leitest du sofort weiter (keine Wartezeit). Wenn „Weiterleitung auf Knopfdruck“ aktiv ist, erscheint der Button erst nach Ablauf dieser Zeit.

---

```
wcf.acp.option.shrinkr_expertmode_active
```

Aktiviere den Expertenmodus

---

```
wcf.acp.option.shrinkr_expertmode_active.description
```

Nur für erfahrene Administratoren. Wenn du aktivierst, erscheinen zusätzliche Optionen (z. B. „Demo-Daten installieren“, „Externe URL“). Die meisten Nutzer brauchen den Expertenmodus nicht. <strong>Vorsicht:</strong> Falsche Einstellungen können den Shr1nkr lahmlegen. Aktiviere nur, wenn du die Folgen kennst.

---

```
wcf.acp.option.shrinkr_dashboard_enabled
```

ACP Dashboard-Box anzeigen

---

```
wcf.acp.option.shrinkr_dashboard_enabled.description
```

Sie entscheiden, ob auf der ACP-Startseite (Dashboard) eine Shr1nkr-Box erscheint. In der Box sehen Sie eine Kurzstatistik (z. B. Anzahl Kurz-URLs, Klicks), die Version und einen Support-Link. Nützlich für einen schnellen Überblick ohne Menü „Shr1nkr“ zu öffnen.

---

```
wcf.acp.option.shrinkr_dashboard_enabled.description
```

Du entscheidest, ob auf der ACP-Startseite (Dashboard) eine Shr1nkr-Box erscheint. In der Box siehst du eine Kurzstatistik (z. B. Anzahl Kurz-URLs, Klicks), die Version und einen Support-Link. Nützlich für einen schnellen Überblick ohne Menü „Shr1nkr“ zu öffnen.

---

```
wcf.acp.option.shrinkr_normal_page_mode
```

Weiterleitungsseite mit Header und Footer anzeigen

---

```
wcf.acp.option.shrinkr_normal_page_mode.description
```

Normalerweise sehen Besucher nur die reine Weiterleitungsseite (ohne Kopf- und Fußbereich Ihrer Community). Wenn Sie aktivieren, erscheinen Header, Footer und alle Seitenboxen. Sinnvoll, wenn die Weiterleitungsseite wie eine normale Community-Seite aussehen soll.

---

```
wcf.acp.option.shrinkr_normal_page_mode.description
```

Normalerweise sehen Besucher nur die reine Weiterleitungsseite (ohne Kopf- und Fußbereich deiner Community). Wenn du aktivierst, erscheinen Header, Footer und alle Seitenboxen. Sinnvoll, wenn die Weiterleitungsseite wie eine normale Community-Seite aussehen soll.

---

```
wcf.acp.option.shrinkr_hash_length
```

Hash-Länge

---

```
wcf.acp.option.shrinkr_hash_length.description
```

Der Hash ist der kurze Code in jeder Kurz-URL (z. B. „abc1“ in /r/abc1/). Hier legen Sie fest, aus wie vielen Zeichen er bestehen soll. Länger = mehr mögliche Kurz-URLs, kürzer = kürzere Adressen. Empfohlen: 4 bis 8 Zeichen. Änderungen gelten nur für neu erstellte Kurz-URLs.

---

```
wcf.acp.option.shrinkr_hash_length.description
```

Der Hash ist der kurze Code in jeder Kurz-URL (z. B. „abc1“ in /r/abc1/). Hier legst du fest, aus wie vielen Zeichen er bestehen soll. Länger = mehr mögliche Kurz-URLs, kürzer = kürzere Adressen. Empfohlen: 4 bis 8 Zeichen. Änderungen gelten nur für neu erstellte Kurz-URLs.

---

```
wcf.acp.option.shrinkr_hash_prefix
```

Hash-Präfix

---

```
wcf.acp.option.shrinkr_hash_prefix.description
```

Optional: Ein fester Text vor jedem Hash. So bauen Sie z. B. lesbare Kurz-URLs: Präfix „link-“ + Hash „abc“ ergibt <kbd>/r/link-abc/</kbd>. Leer lassen = kein Präfix. Präfix und Hash zusammen dürfen maximal 64 Zeichen haben. Gilt nur für neu angelegte Kurz-URLs.

---

```
wcf.acp.option.shrinkr_hash_prefix.description
```

Optional: Ein fester Text vor jedem Hash. So baust du z. B. lesbare Kurz-URLs: Präfix „link-“ + Hash „abc“ ergibt <kbd>/r/link-abc/</kbd>. Leer lassen = kein Präfix. Präfix und Hash zusammen dürfen maximal 64 Zeichen haben. Gilt nur für neu angelegte Kurz-URLs.

---

```
wcf.acp.option.shrinkr_only_https
```

Nur HTTPS-Ziel-URLs (https://) erlauben

---

```
wcf.acp.option.shrinkr_only_https.description
```

Sie können nur Ziel-Adressen eintragen, die mit <kbd>https://</kbd> beginnen. Adressen mit <kbd>http://</kbd> (unverschlüsselt) werden abgelehnt. So stellen Sie sicher, dass Besucher nur auf sichere Seiten weitergeleitet werden.

---

```
wcf.acp.option.shrinkr_only_https.description
```

Du kannst nur Ziel-Adressen eintragen, die mit <kbd>https://</kbd> beginnen. Adressen mit <kbd>http://</kbd> (unverschlüsselt) werden abgelehnt. So stellst du sicher, dass Besucher nur auf sichere Seiten weitergeleitet werden.

---

```
wcf.acp.option.shrinkr_deactivate_forwarding_chains
```

Weiterleitungsketten der Ziel-URL blockieren

---

```
wcf.acp.option.shrinkr_deactivate_forwarding_chains.description
```

Eine Weiterleitungskette entsteht, wenn die Ziel-URL selbst wieder weiterleitet (z. B. Seite A → Seite B → Seite C). Solche Ketten können Besucher verwirren oder fehleranfällig sein. Wenn aktiviert, lehnt der Shr1nkr Ziel-URLs ab, die weiterleiten. Standard: blockiert.

---

```
wcf.acp.option.shrinkr_deactivate_forwarding_chains.description
```

Eine Weiterleitungskette entsteht, wenn die Ziel-URL selbst wieder weiterleitet (z. B. Seite A → Seite B → Seite C). Solche Ketten können Besucher verwirren oder fehleranfällig sein. Wenn aktiviert, lehnt der Shr1nkr Ziel-URLs ab, die weiterleiten. Standard: blockiert.

---

```
wcf.acp.option.shrinkr_pattern
```

Hash-RegEx-Pattern

---

```
wcf.acp.option.shrinkr_pattern.description
```

Nur für Experten. Hier legen Sie ein Muster fest, das jeder Hash erfüllen muss (z. B. nur Zahlen und Kleinbuchstaben). Standard: <kbd>[0-9a-z\-]{1,64}</kbd>. Ein falsches Muster kann dazu führen, dass keine neuen Kurz-URLs mehr erstellt werden können. Lassen Sie das Feld leer oder unverändert, wenn Sie unsicher sind.

---

```
wcf.acp.option.shrinkr_pattern.description
```

Nur für Experten. Hier legst du ein Muster fest, das jeder Hash erfüllen muss (z. B. nur Zahlen und Kleinbuchstaben). Standard: <kbd>[0-9a-z\-]{1,64}</kbd>. Ein falsches Muster kann dazu führen, dass keine neuen Kurz-URLs mehr erstellt werden können. Lass das Feld leer oder unverändert, wenn du unsicher bist.

---

```
wcf.acp.option.shrinkr_external_url
```

Externe URL

---

```
wcf.acp.option.shrinkr_external_url.description
```

Sie können eine andere Basis-Adresse für alle Kurz-URLs vorgeben. Beispiel: Statt <kbd>https://example.com/shrinkr/r/test/</kbd> wird dann <kbd>https://short.example.com/r/test/</kbd> erzeugt. Dafür müssen Sie Ihren Webserver (z. B. Subdomain) extra einrichten. Diese Option erscheint nur, wenn der <a href="{link controller='Option'}#category_shrinkr.expertmode{/link}">Expertenmodus</a> aktiviert ist.

---

```
wcf.acp.option.shrinkr_external_url.description
```

Du kannst eine andere Basis-Adresse für alle Kurz-URLs vorgeben. Beispiel: Statt <kbd>https://example.com/shrinkr/r/test/</kbd> wird dann <kbd>https://short.example.com/r/test/</kbd> erzeugt. Dafür musst du deinen Webserver (z. B. Subdomain) extra einrichten. Diese Option erscheint nur, wenn der <a href="{link controller='Option'}#category_shrinkr.expertmode{/link}">Expertenmodus</a> aktiviert ist.

---

```
wcf.acp.option.shrinkr_install_demo_data
```

Demo-Daten installieren

---

```
wcf.acp.option.shrinkr_install_demo_data.description
```

Legt Beispiel-Kurz-URLs an (DEMO-1 bis DEMO-7) mit Rabatten, Specials, Featured Links und Custom Buttons. Nützlich zum Testen und Kennenlernen. Beim Ausschalten werden nur diese Demo-Daten gelöscht; Ihre eigenen Kurz-URLs, Gutscheine usw. bleiben erhalten. Diese Option erscheint nur im Expertenmodus.

---

```
wcf.acp.option.shrinkr_install_demo_data.description
```

Legt Beispiel-Kurz-URLs an (DEMO-1 bis DEMO-7) mit Rabatten, Specials, Featured Links und Custom Buttons. Nützlich zum Testen und Kennenlernen. Beim Ausschalten werden nur diese Demo-Daten gelöscht; deine eigenen Kurz-URLs, Gutscheine usw. bleiben erhalten. Diese Option erscheint nur im Expertenmodus.

---

```
wcf.acp.option.shrinkr_remove_shrinkr_prefix
```

/shrinkr/ aus Kurz-URLs entfernen

---

```
wcf.acp.option.shrinkr_remove_shrinkr_prefix.description
```

Kurz-URLs werden ohne <kbd>/shrinkr/</kbd> erzeugt: z. B. <kbd>/r/test/</kbd> statt <kbd>/shrinkr/r/test/</kbd>. Gilt für Links, Gutscheine und Einmalnachrichten. Dafür müssen Sie im Webserver (z. B. .htaccess) eigene Regeln eintragen. <strong>Voraussetzung:</strong> Unter „Allgemein“ müssen die Link-Umschreibungen (SEO) aktiviert sein; sonst funktionieren die Kurz-URLs nicht.

---

```
wcf.acp.option.shrinkr_remove_shrinkr_prefix.description
```

Kurz-URLs werden ohne <kbd>/shrinkr/</kbd> erzeugt: z. B. <kbd>/r/test/</kbd> statt <kbd>/shrinkr/r/test/</kbd>. Gilt für Links, Gutscheine und Einmalnachrichten. Dafür musst du im Webserver (z. B. .htaccess) eigene Regeln eintragen. <strong>Voraussetzung:</strong> Unter „Allgemein“ müssen die Link-Umschreibungen (SEO) aktiviert sein; sonst funktionieren die Kurz-URLs nicht.

---

```
wcf.acp.option.shrinkr_enable_reactions
```

Reaktionen aktivieren

---

```
wcf.acp.option.shrinkr_enable_reactions.description
```

Besucher können auf der Weiterleitungsseite reagieren (z. B. Daumen hoch). So sehen Sie, ob eine Kurz-URL gut ankommt. Die Reaktionen erscheinen nur, wenn diese Option aktiv ist. Gäste-Reaktionen schalten Sie separat unter „Gäste-Reaktionen aktivieren“ frei.

---

```
wcf.acp.option.shrinkr_enable_reactions.description
```

Besucher können auf der Weiterleitungsseite reagieren (z. B. Daumen hoch). So siehst du, ob eine Kurz-URL gut ankommt. Die Reaktionen erscheinen nur, wenn diese Option aktiv ist. Gäste-Reaktionen schaltest du separat unter „Gäste-Reaktionen aktivieren“ frei.

---

```
wcf.acp.option.shrinkr_enable_guest_reactions
```

Gäste-Reaktionen aktivieren

---

```
wcf.acp.option.shrinkr_enable_guest_reactions.description
```

Nicht eingeloggte Besucher können dann auf der Weiterleitungsseite reagieren. Die Reaktionen werden gespeichert. Wenn sich der Gast später anmeldet, werden seine Reaktionen seinem Konto zugeordnet. Voraussetzung: „Reaktionen aktivieren“ muss eingeschaltet sein.

---

```
wcf.acp.option.shrinkr_enable_guest_reactions.description
```

Nicht eingeloggte Besucher können dann auf der Weiterleitungsseite reagieren. Die Reaktionen werden gespeichert. Wenn sich der Gast später anmeldet, werden seine Reaktionen seinem Konto zugeordnet. Voraussetzung: „Reaktionen aktivieren“ muss eingeschaltet sein.

---

```
wcf.acp.option.shrinkr_enable_share_button
```

Teilen-Button anzeigen

---

```
wcf.acp.option.shrinkr_enable_share_button.description
```

Auf der Weiterleitungsseite erscheint ein Button zum Teilen der Kurz-URL (z. B. in sozialen Netzwerken). Besucher können die Seite so einfach weiterempfehlen.

---

```
wcf.acp.option.shrinkr_enable_share_button.description
```

Auf der Weiterleitungsseite erscheint ein Button zum Teilen der Kurz-URL (z. B. in sozialen Netzwerken). Besucher können die Seite so einfach weiterempfehlen.

---

```
wcf.acp.option.shrinkr_enable_descriptions
```

Beschreibungen aktivieren

---

```
wcf.acp.option.shrinkr_enable_descriptions.description
```

Aktiviert die Anzeige von Beschreibungstexten auf der Weiterleitungsseite. Es wird jeweils ein Text zufällig aus den unter Shr1nkr → Beschreibungen angelegten Einträgen gewählt. Diese Einstellung schaltet die Anzeige global ein oder aus; einzelne Beschreibungen können dort aktiv oder inaktiv gesetzt werden.

---

```
wcf.acp.option.shrinkr_enable_descriptions.description
```

Aktiviert die Anzeige von Beschreibungstexten auf der Weiterleitungsseite. Es wird jeweils ein Text zufällig aus den unter Shr1nkr → Beschreibungen angelegten Einträgen gewählt. Diese Einstellung schaltet die Anzeige global ein oder aus; einzelne Beschreibungen kannst du dort aktiv oder inaktiv setzen.

---

```
wcf.acp.option.shrinkr_password_session_storage
```

Passwort in Session speichern

---

```
wcf.acp.option.shrinkr_password_session_storage.description
```

Bei passwortgeschützten Kurz-URLs müssen Besucher das Passwort normalerweise bei jedem Aufruf eingeben. Wenn Sie aktivieren, reicht eine Eingabe pro Browsersitzung: Danach wird der Zugriff bis zum Schließen des Browsers gespeichert. Praktisch für Besucher, die mehrere passwortgeschützte Kurz-URLs nacheinander öffnen.

---

```
wcf.acp.option.shrinkr_password_session_storage.description
```

Bei passwortgeschützten Kurz-URLs müssen Besucher das Passwort normalerweise bei jedem Aufruf eingeben. Wenn du aktivierst, reicht eine Eingabe pro Browsersitzung: Danach wird der Zugriff bis zum Schließen des Browsers gespeichert. Praktisch für Besucher, die mehrere passwortgeschützte Kurz-URLs nacheinander öffnen.

---

```
wcf.acp.option.shrinkr_rate_limit_enabled
```

Passwortversuche begrenzen

---

```
wcf.acp.option.shrinkr_rate_limit_enabled.description
```

Schützt passwortgeschützte Kurz-URLs vor Angriffen mit vielen Passwort-Versuchen. Pro Kurz-URL und pro Besucher-IP gilt: Nach einer bestimmten Anzahl falscher Versuche (siehe nächste Optionen) wird der Zugriff für ein Zeitfenster gesperrt. Danach können Versuche wieder gezählt werden.

---

```
wcf.acp.option.shrinkr_rate_limit_enabled.description
```

Schützt passwortgeschützte Kurz-URLs vor Angriffen mit vielen Passwort-Versuchen. Pro Kurz-URL und pro Besucher-IP gilt: Nach einer bestimmten Anzahl falscher Versuche (siehe nächste Optionen) wird der Zugriff für ein Zeitfenster gesperrt. Danach können Versuche wieder gezählt werden.

---

```
wcf.acp.option.shrinkr_rate_limit_attempts
```

Maximal erlaubte Fehlversuche

---

```
wcf.acp.option.shrinkr_rate_limit_attempts.description
```

Wie oft darf jemand ein falsches Passwort eingeben, bevor der Zugriff vorübergehend gesperrt wird? Beispiel: 5 = nach 5 Fehlversuchen folgt eine Sperre. Gilt nur, wenn „Passwortversuche begrenzen“ aktiv ist.

---

```
wcf.acp.option.shrinkr_rate_limit_attempts.description
```

Wie oft darf jemand ein falsches Passwort eingeben, bevor der Zugriff vorübergehend gesperrt wird? Beispiel: 5 = nach 5 Fehlversuchen folgt eine Sperre. Gilt nur, wenn „Passwortversuche begrenzen“ aktiv ist.

---

```
wcf.acp.option.shrinkr_rate_limit_window
```

Sperrzeit in Sekunden

---

```
wcf.acp.option.shrinkr_rate_limit_window.description
```

Nach zu vielen Fehlversuchen wird der Zugriff für so viele Sekunden gesperrt. Beispiel: 900 = 15 Minuten. Danach zählen die Versuche wieder von vorn. Gilt nur, wenn „Passwortversuche begrenzen“ aktiv ist.

---

```
wcf.acp.option.shrinkr_rate_limit_window.description
```

Nach zu vielen Fehlversuchen wird der Zugriff für so viele Sekunden gesperrt. Beispiel: 900 = 15 Minuten. Danach zählen die Versuche wieder von vorn. Gilt nur, wenn „Passwortversuche begrenzen“ aktiv ist.

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button
```

3D-Button-Stil aktivieren

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button.label
```

Weiterleitungs-Button überschreiben

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button.description
```

Der Weiterleitungs-Button erhält einen 3D-Stil und übernimmt die Farben des Promo-Badges (Rabatt-Bereich) auf der Weiterleitungsseite. Ohne Aktivierung wird der Standard-Button angezeigt.

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button.description
```

Der Weiterleitungs-Button erhält einen 3D-Stil und übernimmt die Farben des Promo-Badges (Rabatt-Bereich) auf der Weiterleitungsseite. Ohne Aktivierung wird der Standard-Button angezeigt.

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button.preview
```

Vorschau:

---

```
wcf.acp.option.shrinkr_title_icon
```

Titel-Icon

---

```
wcf.acp.option.shrinkr_title_icon.description
```

Vor der Hauptüberschrift auf der Weiterleitungsseite können Sie ein kleines Symbol (Icon) anzeigen. Wählen Sie hier ein Icon aus der Font-Awesome-Bibliothek. Leer = kein Icon.

---

```
wcf.acp.option.shrinkr_title_icon.description
```

Vor der Hauptüberschrift auf der Weiterleitungsseite kannst du ein kleines Symbol (Icon) anzeigen. Wähle hier ein Icon aus der Font-Awesome-Bibliothek. Leer = kein Icon.

---

```
wcf.acp.option.shrinkr_enable_theme_effects
```

Spezialeffekte aktivieren

---

```
wcf.acp.option.shrinkr_enable_theme_effects.description
```

Schaltet themenbasierte Effekte wie Herbstblätter, Schnee oder Geister frei. Die Effekte erscheinen nur auf der Weiterleitungsseite, wenn ein Special mit einem Theme verknüpft ist (Themes verwalten unter Shr1nkr → Themes; beim Special den gewünschten Effekt auswählen).

---

```
wcf.acp.option.shrinkr_enable_theme_effects.description
```

Schaltet themenbasierte Effekte wie Herbstblätter, Schnee oder Geister frei. Die Effekte erscheinen nur auf der Weiterleitungsseite, wenn ein Special mit einem Theme verknüpft ist (Themes verwalten unter Shr1nkr → Themes; beim Special den gewünschten Effekt auswählen).

---

```
wcf.acp.option.shrinkr_enable_qr_code
```

QR-Code-Generierung aktivieren

---

```
wcf.acp.option.shrinkr_enable_qr_code.description
```

Sie können für jede Kurz-URL einen QR-Code erzeugen und anzeigen. Besucher können den Code mit dem Handy scannen und gelangen so direkt zur Weiterleitungsseite. Die QR-Codes erscheinen in der Liste Ihrer Kurz-URLs (Menü: Shr1nkr → Links) und lassen sich dort anzeigen und herunterladen.

---

```
wcf.acp.option.shrinkr_enable_qr_code.description
```

Du kannst für jede Kurz-URL einen QR-Code erzeugen und anzeigen. Besucher können den Code mit dem Handy scannen und gelangen so direkt zur Weiterleitungsseite. Die QR-Codes erscheinen in der Liste deiner Kurz-URLs (Menü: Shr1nkr → Links) und lassen sich dort anzeigen und herunterladen.

---

```
wcf.acp.group.option.category.user.shrinkr
```

Shr1nkr

---

```
wcf.acp.group.option.category.mod.shrinkr
```

Shr1nkr

---

```
wcf.acp.group.option.category.admin.shrinkr
```

Shr1nkr-Verwaltung

---

```
wcf.acp.group.option.admin.shrinkr.canManageLinks
```

Kann Links verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageDiscounts
```

Kann Rabatte verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageDescriptions
```

Kann Beschreibungen verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageFeaturedLinks
```

Kann Featured Links verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageCustomButtons
```

Kann Custom Buttons verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageSpecials
```

Kann Specials verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageThemes
```

Kann Themes verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageButtonClicks
```

Kann Button-Klicks verwalten

---

```
shrinkr.acp.option.reload
```

Optionen nachladen

---

```
shrinkr.acp.menu.badge.expert
```

EXPERTE

---

```
shrinkr.acp.menu.badge.demo
```

DEMO

---

```
shrinkr.acp.menu.badge.expertDemo
```

EXPERTE, DEMO

---

```
shrinkr.acp.menu.link.menu
```

Shr1nkr

---

```
shrinkr.acp.menu.link.link.list
```

Links

---

```
shrinkr.acp.menu.link.link.add
```

Link hinzufügen

---

```
shrinkr.acp.menu.link.discount.list
```

Rabatte

---

```
shrinkr.acp.menu.link.discount.add
```

Rabatt hinzufügen

---

```
shrinkr.acp.menu.link.discount.edit
```

Rabatt bearbeiten

---

```
shrinkr.acp.menu.link.voucher.permanent.list
```

Gutscheine

---

```
shrinkr.acp.menu.link.voucher.permanent.add
```

Gutschein (dauerhaft) hinzufügen

---

```
shrinkr.acp.menu.link.voucher.permanent.edit
```

Gutschein (dauerhaft) bearbeiten

---

```
shrinkr.acp.menu.link.voucher.permanent.password
```

Passwortgeschützte Gutscheine (dauerhaft)

---

```
shrinkr.acp.menu.link.voucher.once.list
```

Einmalig

---

```
shrinkr.acp.menu.link.voucher.once.add
```

Gutschein (einmalig) hinzufügen

---

```
shrinkr.acp.menu.link.voucher.once.edit
```

Gutschein (einmalig) bearbeiten

---

```
shrinkr.acp.menu.link.voucher.once.password
```

Passwortgeschützte Gutscheine (einmalig)

---

```
shrinkr.acp.menu.link.onetimemessage.list
```

Einmal-Nachrichten

---

```
shrinkr.acp.menu.link.onetimemessage.add
```

Einmal-Nachricht hinzufügen

---

```
shrinkr.acp.menu.link.onetimemessage.edit
```

Einmal-Nachricht bearbeiten

---

```
shrinkr.acp.menu.link.onetimemessage.password
```

Passwortgeschützte Einmal-Nachrichten

---

```
shrinkr.acp.menu.link.description.list
```

Beschreibungen

---

```
shrinkr.acp.menu.link.description.add
```

Beschreibung hinzufügen

---

```
shrinkr.acp.menu.link.description.edit
```

Beschreibung bearbeiten

---

```
shrinkr.acp.menu.link.featuredLink.list
```

Featured Links

---

```
shrinkr.acp.menu.link.featuredLink.add
```

Featured Link hinzufügen

---

```
shrinkr.acp.menu.link.featuredLink.edit
```

Featured Link bearbeiten

---

```
shrinkr.acp.menu.link.customButton.list
```

Custom Buttons

---

```
shrinkr.acp.menu.link.customButton.add
```

Custom Button hinzufügen

---

```
shrinkr.acp.menu.link.customButton.edit
```

Custom Button bearbeiten

---

```
shrinkr.acp.menu.link.special.list
```

Specials

---

```
shrinkr.acp.menu.link.special.add
```

Special hinzufügen

---

```
shrinkr.acp.menu.link.special.edit
```

Special bearbeiten

---

```
shrinkr.acp.menu.link.link.password
```

Passwort-geschützte Links

---

```
shrinkr.acp.menu.link.link.password.filter
```

Nur passwortgeschützte Links

---

```
shrinkr.acp.menu.link.theme.list
```

Themes

---

```
shrinkr.acp.menu.link.theme.add
```

Theme hinzufügen

---

```
shrinkr.acp.menu.link.theme.edit
```

Theme bearbeiten

---

```
shrinkr.acp.menu.link.statistic
```

Statistiken

---

```
shrinkr.acp.menu.link.statistic.info
```

Info

---

```
shrinkr.acp.menu.link.settings
```

Einstellungen

---

```
shrinkr.voucher.code
```

Gutscheincode

---

```
shrinkr.voucher.code.description
```

Der Rabatt-Code, der auf der Weiterleitungsseite angezeigt wird (z. B. SAVE20).

---

```
shrinkr.voucher.title
```

Titel

---

```
shrinkr.voucher.title.description
```

Kurzer Titel oder Bezeichnung für diesen Gutschein.

---

```
shrinkr.voucher.token
```

Token

---

```
shrinkr.voucher.token.description
```

Eindeutiger Kurzcode für die Gutschein-Kurz-URL (z. B. /v/SAVE20). Leer lassen = automatische Generierung.

---

```
shrinkr.voucher.discountValue.description
```

Anzeigetext für den Rabatt (z. B. „20 % Rabatt“ oder „10 € Gutschein“).

---

```
shrinkr.voucher.maxViews
```

Max. Aufrufe (0 = unbegrenzt)

---

```
shrinkr.voucher.maxViews.description
```

Maximale Anzahl Aufrufe der Gutschein-URL. 0 = unbegrenzt.

---

```
shrinkr.voucher.viewCount
```

Aufrufe

---

```
shrinkr.voucher.password.description
```

Dieser Gutschein ist mit einem Passwort geschützt. Bitte geben Sie das Passwort ein, um den Gutschein anzuzeigen.

---

```
shrinkr.otm.pageTitle
```

Einmal-Nachricht

---

```
shrinkr.otm.messageText
```

Nachrichtentext

---

```
shrinkr.otm.messageText.description
```

Der Text, der beim ersten Aufruf der Einmal-Nachricht-Kurz-URL (/m/…) angezeigt wird. Danach ist die URL ungültig.

---

```
shrinkr.otm.createdTime
```

Erstellt

---

```
shrinkr.otm.expiryTime
```

Ablaufzeit

---

```
shrinkr.otm.expiryTime.description
```

Optional: Nach Ablauf wird die Einmal-Nachricht nicht mehr angezeigt.

---

```
shrinkr.otm.password
```

Passwort

---

```
shrinkr.otm.password.description
```

Optional: Nur mit Passwort sichtbar.

---

```
shrinkr.otm.password.pageDescription
```

Diese Einmal-Nachricht ist passwortgeschützt. Bitte geben Sie das Passwort ein, um den Inhalt zu lesen.

---

```
shrinkr.acp.form.enable
```

Aktivieren

---

```
shrinkr.acp.form.sortOrder
```

Sortierung

---

```
shrinkr.acp.voucher.permanent.add.description
```

Sie legen hier einen dauerhaften Gutschein an. Er hat eine feste Kurz-URL (z. B. /v/SAVE20/). Besucher können die URL beliebig oft aufrufen; die Gutschein-Seite mit Code und Rabatt erscheint jedes Mal. Auswertung: Shr1nkr → Statistiken, Bereich Gutscheine.

---

```
shrinkr.acp.voucher.permanent.edit.description
```

Hier passen Sie Titel, Gutscheincode, Rabatttext und weitere Einstellungen des dauerhaften Gutscheins an. Die Kurz-URL (/v/…) bleibt bestehen.

---

```
shrinkr.acp.voucher.permanent.list.description
```

Übersicht aller dauerhaften Gutscheine. Jeder hat eine feste Kurz-URL (z. B. /v/SAVE20/) und kann unbegrenzt oft aufgerufen werden. Anlegen hier; die Gutschein-Seite erscheint, wenn jemand die Kurz-URL öffnet. Einlösungen werten Sie unter Shr1nkr → Statistiken aus.

---

```
shrinkr.acp.voucher.permanent.list.password
```

Passwortgeschützte Gutscheine (dauerhaft)

---

```
shrinkr.acp.voucher.permanent.list.password.description
```

Nur dauerhafte Gutscheine, die ein Passwort haben. Besucher müssen es eingeben, um den Gutschein zu sehen. Angelegt werden sie unter Shr1nkr → Gutscheine (dauerhaft); hier sehen Sie sie gefiltert.

---

```
shrinkr.acp.voucher.once.add.description
```

Sie legen hier einen Gutschein an, der nur einmal eingelöst werden kann. Nach dem ersten Aufruf der Kurz-URL ist sie ungültig. Sinnvoll für einmalige Aktionen oder persönliche Gutscheine.

---

```
shrinkr.acp.voucher.once.edit.description
```

Hier passen Sie Titel, Gutscheincode und Einstellungen des Einmal-Gutscheins an. Wenn die Kurz-URL schon aufgerufen wurde, ist sie weiterhin ungültig.

---

```
shrinkr.acp.voucher.once.list.description
```

Übersicht aller Einmal-Gutscheine. Jeder hat eine Kurz-URL (/v/…); nach dem ersten Aufruf ist sie ungültig. Anlegen hier unter Shr1nkr → Gutscheine (Einmalig). Auswertung: Shr1nkr → Statistiken, Bereich Gutscheine.

---

```
shrinkr.acp.voucher.once.list.password
```

Passwortgeschützte Gutscheine (einmalig)

---

```
shrinkr.acp.voucher.once.list.password.description
```

Nur Einmal-Gutscheine mit Passwort. Angelegt unter Shr1nkr → Gutscheine (Einmalig); hier gefiltert. Besucher müssen das Passwort eingeben, um den Gutschein zu sehen.

---

```
shrinkr.acp.otm.add.description
```

Sie legen hier eine Einmal-Nachricht an. Sie hat eine eigene Kurz-URL (/m/…). Beim ersten Aufruf sehen Besucher Ihren Text; danach ist die URL ungültig. Ideal für einmalige Infos oder persönliche Nachrichten.

---

```
shrinkr.acp.otm.edit.description
```

Hier ändern Sie den Nachrichtentext und weitere Einstellungen. Wenn die Kurz-URL schon einmal aufgerufen wurde, ist sie weiterhin ungültig; der neue Inhalt gilt nur für neue Einmal-Nachrichten.

---

```
shrinkr.acp.otm.list.description
```

Übersicht aller Einmal-Nachrichten. Jede hat eine Kurz-URL (/m/…); der Inhalt wird nur beim ersten Aufruf angezeigt, danach ist die URL ungültig. Anlegen hier unter Shr1nkr → Einmal-Nachrichten. Auswertung: Shr1nkr → Statistiken.

---

```
shrinkr.acp.otm.list.password
```

Passwortgeschützte Einmal-Nachrichten

---

```
shrinkr.acp.otm.list.password.description
```

Nur Einmal-Nachrichten mit Passwort. Angelegt unter Shr1nkr → Einmal-Nachrichten; hier gefiltert. Besucher müssen das Passwort eingeben, um die Nachricht zu lesen.

---

```
shrinkr.acp.dashboard.box.title
```

Shr1nkr

---

```
shrinkr.acp.dashboard.version
```

Version

---

```
shrinkr.acp.dashboard.totalLinks
```

Kurz-URLs gesamt

---

```
shrinkr.acp.dashboard.totalClicks
```

Klicks (30 Tage)

---

```
shrinkr.acp.dashboard.totalVisitors
```

Besucher (30 Tage)

---

```
shrinkr.acp.dashboard.activeSpecials
```

Aktive Specials

---

```
shrinkr.acp.dashboard.featuredLinks
```

Featured Links

---

```
shrinkr.acp.dashboard.vouchersTotal
```

Gutscheine gesamt

---

```
shrinkr.acp.dashboard.oneTimeMessagesTotal
```

Einmalnachrichten gesamt

---

```
shrinkr.acp.dashboard.viewStatistics
```

Statistiken

---

```
shrinkr.acp.dashboard.manageLinks
```

Kurz-URLs verwalten

---

```
shrinkr.acp.dashboard.support
```

Support

---

```
shrinkr.acp.dashboard.supportUrl
```

https://sunnyc.de

---

```
shrinkr.acp.dashboard.copyright
```

Shr1nkr von sunnyc.de

---

```
wcf.shrinkr.url
```

Kurz-URL

---

```
wcf.shrinkr.copyUrl
```

Kurz-URL kopieren

---

```
wcf.shrinkr.copyUrl.success
```

URL wurde erfolgreich kopiert

---

```
wcf.shrinkr.copyUrl.error
```

Beim Kopieren ist ein Fehler aufgetreten

---

```
wcf.shrinkr.notActive
```

Shr1nkr wurde nicht aktiviert.

---

```
wcf.shrinkr.yes
```

Ja

---

```
wcf.shrinkr.no
```

Nein

---

```
wcf.shrinkr.urlGoal
```

Ziel-URL

---

```
wcf.shrinkr.urlGoal.description
```

Die vollständige Ziel-URL, zu der weitergeleitet werden soll (z. B. https://example.com).

---

```
wcf.shrinkr.url.hash
```

Hash

---

```
wcf.shrinkr.url.hash.description
```

Der Hash ist der kurze Teil in der Kurz-URL (z. B. „abc1“ in /r/abc1/). Leer lassen = System erzeugt einen zufälligen Hash. Sie können einen eigenen eingeben (z. B. „angebot1“), dann lautet die Kurz-URL …/r/angebot1/.

---

```
wcf.shrinkr.url.counter
```

Besucher

---

```
wcf.shrinkr.link.password
```

Passwort

---

```
wcf.shrinkr.link.password.description
```

Optional. Wenn Sie ein Passwort eintragen, müssen Besucher es auf der Weiterleitungsseite eingeben, bevor sie zur Ziel-URL gelangen. Ohne Passwort ist die Kurz-URL für jeden sofort erreichbar.

---

```
wcf.shrinkr.link.passwordProtected
```

Passwortgeschützt

---

```
wcf.shrinkr.password.wrong
```

Falsches Passwort

---

```
wcf.shrinkr.password.enter
```

Passwort eingeben

---

```
wcf.shrinkr.password.description
```

Bitte geben Sie das Passwort ein, um auf diese Kurz-URL zuzugreifen.

---

```
wcf.shrinkr.password.description
```

Bitte gib das Passwort ein, um auf diese Kurz-URL zuzugreifen.

---

```
wcf.shrinkr.password.confirm
```

Bestätigen

---

```
wcf.shrinkr.password.unlock
```

Inhalt freischalten

---

```
wcf.shrinkr.qrCode
```

QR-Code

---

```
wcf.shrinkr.qrCode.download
```

Download

---

```
wcf.shrinkr.qrCode.zoom
```

Vergrößern

---

```
wcf.shrinkr.resetCounter
```

Besuche-Zähler zurücksetzen

---

```
wcf.shrinkr.copyright
```

<a href="https://sunnyc.de" rel="nofollow"{if EXTERNAL_LINK_TARGET_BLANK} target="_blank"{/if}><strong>Shr1nkr</strong> (von <strong>sunnyc.de</strong>)</a>

---

```
shrinkr.acp.rewrite.title
```

Rewrite-Regeln für Shr1nkr

---

```
shrinkr.acp.rewrite.generate
```

Rewrite-Regeln generieren

---

```
shrinkr.acp.rewrite.description
```

Entfernt das /shrinkr/ Prefix aus den generierten Kurz-URLs. Statt /shrinkr/r/test/, /shrinkr/v/test/ oder /shrinkr/m/test/ werden dann /r/test/, /v/test/ bzw. /m/test/ generiert (Links, Gutscheine, Einmalnachrichten). Erfordert manuelle Webserver-Konfiguration. Wichtig: Die Link-Umschreibungen müssen unter "Allgemein" aktiviert sein.

---

```
shrinkr.acp.rewrite.info.title
```

Wichtig

---

```
shrinkr.acp.rewrite.info.description
```

Die Regel für /r/ muss GANZ OBEN in der .htaccess stehen (vor der urls/ Regel). Die Link-Umschreibungen müssen unter "Allgemein" → "Suchmaschinenoptimierung (SEO)" aktiviert sein.

---

```
shrinkr.acp.url.removeUrlsPrefix.info.title
```

/shrinkr/ Prefix entfernen

---

```
shrinkr.acp.url.removeUrlsPrefix.info.description
```

Sie haben die Option aktiviert, das /shrinkr/ Prefix aus URLs zu entfernen. Damit Links wie <strong>https://example.com/r/abc123</strong> funktionieren, müssen Rewrite-Regeln in Ihrer Webserver-Konfiguration eingetragen werden.

---

```
shrinkr.acp.url.removeUrlsPrefix.info.description
```

Du hast die Option aktiviert, das /shrinkr/ Prefix aus URLs zu entfernen. Damit Links wie <strong>https://example.com/r/abc123</strong> funktionieren, müssen Rewrite-Regeln in deiner Webserver-Konfiguration eingetragen werden.

---

```
shrinkr.acp.url.removeUrlsPrefix.info.htaccess.generate
```

Rewrite-Regeln anzeigen

---

```
shrinkr.acp.url.removeUrlsPrefix.info.htaccess.generate.description
```

Klicken Sie auf den Button, um die passenden Rewrite-Regeln für Ihren Webserver anzuzeigen.

---

```
shrinkr.acp.url.removeUrlsPrefix.info.htaccess.generate.description
```

Klicke auf den Button, um die passenden Rewrite-Regeln für deinen Webserver anzuzeigen.

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink
```

Featured Links

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink.description
```

Zeigt nur Kurz-URLs mit Featured Link oder nur solche ohne. Featured Links sind „Dazu empfohlen“-Empfehlungen auf der Weiterleitungsseite.

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink.yes
```

Mit Featured Link bzw. mehreren

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink.no
```

Ohne Featured Link

---

```
shrinkr.acp.url.list.filter.hasCustomButton
```

Custom Buttons

---

```
shrinkr.acp.url.list.filter.hasCustomButton.description
```

Zeigt nur Kurz-URLs mit Custom Button oder nur solche ohne. Custom Buttons sind eigene Buttons unter dem Weiterleitungs-Button auf der Weiterleitungsseite.

---

```
shrinkr.acp.url.list.filter.hasCustomButton.yes
```

Mit Custom Button bzw. mehreren

---

```
shrinkr.acp.url.list.filter.hasCustomButton.no
```

Ohne Custom Button

---

```
shrinkr.acp.url.list
```

Kurz-URLs verwalten

---

```
shrinkr.acp.url.list.description
```

Übersicht aller Ihre Kurz-URLs. Sie können hier neue anlegen, bestehende bearbeiten oder löschen. Suche nach Hash, Ziel-URL oder Titel; Sortierung und Filter (z. B. nur passwortgeschützte oder nur mit Featured Link) helfen bei vielen Einträgen. Die Kurz-URLs führen Besucher auf die Weiterleitungsseite, von dort zur Ziel-URL.

---

```
shrinkr.acp.url.list.description
```

Übersicht aller deiner Kurz-URLs. Du kannst hier neue anlegen, bestehende bearbeiten oder löschen. Suche nach Hash, Ziel-URL oder Titel; Sortierung und Filter (z. B. nur passwortgeschützte oder nur mit Featured Link) helfen bei vielen Einträgen. Die Kurz-URLs führen Besucher auf die Weiterleitungsseite, von dort zur Ziel-URL.

---

```
shrinkr.acp.url.list.password
```

Passwortgeschützte Kurz-URLs verwalten

---

```
shrinkr.acp.url.list.password.description
```

Nur Kurz-URLs, die ein Passwort haben. Besucher müssen es eingeben, bevor sie zur Ziel-URL weitergeleitet werden. Angelegt werden passwortgeschützte Kurz-URLs wie normale unter „Links“; hier sehen Sie sie gebündelt.

---

```
shrinkr.acp.url.list.password.description
```

Nur Kurz-URLs, die ein Passwort haben. Besucher müssen es eingeben, bevor sie zur Ziel-URL weitergeleitet werden. Angelegt werden passwortgeschützte Kurz-URLs wie normale unter „Links“; hier siehst du sie gebündelt.

---

```
shrinkr.acp.url.add
```

URL kürzen

---

```
shrinkr.acp.url.edit
```

Kurz-URL bearbeiten

---

```
shrinkr.acp.url.delete.confirmMessage
```

Wollen Sie diese Kurz-URL wirklich löschen? Alle gesammelten Daten werden dadurch gelöscht.

---

```
shrinkr.acp.url.delete.confirmMessage
```

Willst du diese Kurz-URL wirklich löschen? Alle gesammelten Daten werden dadurch gelöscht.

---

```
shrinkr.acp.url.success.theShortUrlIs
```

Die gekürzte URL lautet:

---

```
shrinkr.acp.url.hash.error.tooLong
```

Der Hash darf nicht länger als 64 Zeichen sein.

---

```
shrinkr.acp.url.hash.error.alreadyExists
```

Der Hash wird schon verwendet.

---

```
shrinkr.acp.url.hash.error.notMatchesPattern
```

Der Hash darf nur bestimmte Zeichen enthalten, die vom Administrator festgelegt wurden.

---

```
shrinkr.acp.url.url.error.tooLong
```

Die Ziel-URL darf nicht länger als 255 Zeichen sein.

---

```
shrinkr.acp.url.url.error.noUrl
```

Die angegebene URL ist ungültig.

---

```
shrinkr.acp.url.url.error.httpsRequired
```

Die URL muss HTTPS (https://) verwenden.

---

```
shrinkr.acp.url.url.error.isOnBlacklist
```

Die angegebene URL steht auf der Blacklist.

---

```
shrinkr.acp.url.url.error.forwardingChain
```

Weiterleitungsketten sind nicht erlaubt.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.title
```

Erweiterte URL-Generierung aktiviert

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.description
```

Die URLs werden ohne <kbd>/shrinkr/</kbd> Prefix generiert (z. B. <kbd>/r/test/</kbd>, <kbd>/v/test/</kbd>, <kbd>/m/test/</kbd> statt <kbd>/shrinkr/r/test/</kbd> usw.). Damit dies funktioniert, muss die Webserver-Konfiguration (Apache <kbd>.htaccess</kbd> oder nginx <kbd>nginx.conf</kbd>) manuell angepasst werden. Klicken Sie auf den Button "Rewrite-Regeln generieren" oben rechts, um die benötigten Regeln anzuzeigen. Diese Info verschwindet automatisch, sobald die Regeln korrekt in der Webserver-Konfiguration eingefügt wurden.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.description
```

Die URLs werden ohne <kbd>/shrinkr/</kbd> Prefix generiert (z. B. <kbd>/r/test/</kbd>, <kbd>/v/test/</kbd>, <kbd>/m/test/</kbd> statt <kbd>/shrinkr/r/test/</kbd> usw.). Damit dies funktioniert, muss die Webserver-Konfiguration (Apache <kbd>.htaccess</kbd> oder nginx <kbd>nginx.conf</kbd>) manuell angepasst werden. Klicke auf den Button "Rewrite-Regeln generieren" oben rechts, um die benötigten Regeln anzuzeigen. Diese Info verschwindet automatisch, sobald die Regeln korrekt in der Webserver-Konfiguration eingefügt wurden.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.title
```

Anleitung: Webserver-Konfiguration anpassen

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.step1
```

Gehe zu: ACP → Allgemein → Suchmaschinenoptimierung (SEO) → Rewrite-Regeln generieren

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.step2
```

Kopiere die generierten Standard-Regeln von WoltLab

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.step3
```

Füge die Regeln für <kbd>/r/</kbd>, <kbd>/v/</kbd> und <kbd>/m/</kbd> GANZ OBEN ein (vor der <kbd>shrinkr/</kbd> Regel)

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.alreadySet
```

Die Regeln für <kbd>/r/</kbd>, <kbd>/v/</kbd> und <kbd>/m/</kbd> sind bereits in der .htaccess vorhanden.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.apache
```

Apache (.htaccess)

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.nginx
```

nginx (nginx.conf)

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.generate
```

Rewrite-Regeln generieren

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.generate.description
```

Klicken Sie auf den Button "Rewrite-Regeln generieren" oben rechts, um die benötigten Regeln für Apache (.htaccess) und nginx (nginx.conf) anzuzeigen und in Ihre Webserver-Konfiguration einzufügen.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.generate.description
```

Klicke auf den Button "Rewrite-Regeln generieren" oben rechts, um die benötigten Regeln für Apache (.htaccess) und nginx (nginx.conf) anzuzeigen und in deine Webserver-Konfiguration einzufügen.

---

```
shrinkr.acp.url.rewrite.nginx.instructions
```

Diese Regeln müssen in den server-Block Ihrer nginx.conf eingefügt werden

---

```
shrinkr.acp.url.rewrite.nginx.instructions
```

Diese Regeln müssen in den server-Block deiner nginx.conf eingefügt werden

---

```
shrinkr.acp.url.rewrite.nginx.important
```

WICHTIG: Die /r/ Regel muss VOR den Standard-WoltLab-Regeln stehen.

---

```
shrinkr.acp.url.rewrite.nginx.note
```

Hinweis: Stellen Sie sicher, dass die Standard-WoltLab-Regeln
für /shrinkr/ ebenfalls in Ihrer nginx.conf vorhanden sind.

---

```
shrinkr.acp.url.rewrite.nginx.note
```

Hinweis: Stelle sicher, dass die Standard-WoltLab-Regeln
für /shrinkr/ ebenfalls in deiner nginx.conf vorhanden sind.

---

```
shrinkr.redirect.headline
```

Weiterleitungsseite

---

```
shrinkr.redirect.text.confirm
```

Sie sollen zu folgender Zieladresse weitergeleitet werden: <kbd>{$redirectUrl}</kbd>

---

```
shrinkr.redirect.text.confirm
```

Du sollst zu folgender Zieladresse weitergeleitet werden: <kbd>{$redirectUrl}</kbd>

---

```
shrinkr.redirect.text.timer
```

Die Weiterleitung erfolgt automatisch nach Ablauf des Timers.

---

```
shrinkr.redirect.forwardingIn
```

Weiterleitung erfolgt in

---

```
shrinkr.redirect.second
```

Sekunde

---

```
shrinkr.redirect.seconds
```

Sekunden

---

```
shrinkr.redirect.confirm
```

Empfehlung ansehen

---

```
shrinkr.redirect.forwardingNow
```

Weiterleitung erfolgt jetzt

---

```
shrinkr.featured.texts.recommended
```

Dazu empfohlen

---

```
shrinkr.featured.texts.discount
```

Profitiere auch bei diesen Anbietern von exklusiven Rabatten

---

```
wcf.shrinkr.design
```

Aussehen

---

```
wcf.shrinkr.featured
```

Dazu empfohlen

---

```
wcf.shrinkr.featuredLinks
```

Empfohlene Links

---

```
wcf.shrinkr.featuredLinks.manage.description
```

Featured Links sind „Dazu empfohlen“-Empfehlungen auf der Weiterleitungsseite. Sie legen sie pro Kurz-URL unter Shr1nkr → Featured Links an oder in der Kurz-URL-Bearbeitung. Hier sehen Sie die Übersicht für diese Kurz-URL.

---

```
wcf.shrinkr.featuredLinks.manage.description
```

Featured Links sind „Dazu empfohlen“-Empfehlungen auf der Weiterleitungsseite. Du legst sie pro Kurz-URL unter Shr1nkr → Featured Links an oder in der Kurz-URL-Bearbeitung. Hier siehst du die Übersicht für diese Kurz-URL.

---

```
wcf.shrinkr.customButtons
```

Custom Buttons

---

```
wcf.shrinkr.customButtons.manage.description
```

Custom Buttons sind eigene Buttons unter dem Weiterleitungs-Button auf der Weiterleitungsseite. Sie legen sie pro Kurz-URL unter Shr1nkr → Custom Buttons an oder in der Kurz-URL-Bearbeitung. Hier sehen Sie die Übersicht für diese Kurz-URL.

---

```
wcf.shrinkr.customButtons.manage.description
```

Custom Buttons sind eigene Buttons unter dem Weiterleitungs-Button auf der Weiterleitungsseite. Du legst sie pro Kurz-URL unter Shr1nkr → Custom Buttons an oder in der Kurz-URL-Bearbeitung. Hier siehst du die Übersicht für diese Kurz-URL.

---

```
wcf.shrinkr.hosts
```

Host-Namen

---

```
wcf.shrinkr.hosts.description
```

Geben Sie einen oder mehrere Host-Namen ein (z. B. amazon.de, ebay.de, mediamarkt.de)

---

```
wcf.shrinkr.hosts.description
```

Gib einen oder mehrere Host-Namen ein (z. B. amazon.de, ebay.de, mediamarkt.de)

---

```
wcf.shrinkr.special
```

Special

---

```
wcf.shrinkr.special.identifier
```

Special-Identifier

---

```
wcf.shrinkr.special.identifier.description
```

Über diesen Wert nach "&special=" ist das Special verfügbar

---

```
wcf.shrinkr.special.manage
```

Specials verwalten

---

```
wcf.shrinkr.special.edit
```

Special bearbeiten

---

```
wcf.shrinkr.special.add
```

Special hinzufügen

---

```
wcf.shrinkr.special.manage.description
```

Verwalten Sie temporäre Specials für diese URL

---

```
wcf.shrinkr.special.manage.description
```

Verwalte temporäre Specials für diese URL

---

```
wcf.shrinkr.special.noItems
```

Es wurden keine Specials gefunden.

---

```
wcf.shrinkr.special.noItems.howToAdd.title
```

Wie füge ich Specials hinzu?

---

```
wcf.shrinkr.special.noItems.howToAdd.text
```

Specials können auf zwei Arten erstellt werden:

---

```
wcf.shrinkr.special.noItems.howToAdd.viaUrlList
```

In der URL-Liste über den \"+\"-Button in der Special-Spalte

---

```
wcf.shrinkr.special.noItems.howToAdd.viaLinkEdit
```

Über die Link-Bearbeitung im Navigationsmenü

---

```
wcf.shrinkr.special.noItems.dependencies.title
```

Wovon sind Specials abhängig?

---

```
wcf.shrinkr.special.noItems.dependencies.text
```

Specials benötigen eine existierende URL. Jedes Special ist einer bestimmten URL zugeordnet und wird auf der entsprechenden Redirect-Seite angezeigt.

---

```
wcf.shrinkr.special.noItems.impact.title
```

Wovon hängen andere Funktionen ab?

---

```
wcf.shrinkr.special.noItems.impact.text
```

Specials werden auf der Redirect-Seite angezeigt und können mit Themes, Rabatt-Codes und Countdown-Timern kombiniert werden. Featured Links können optional mit Specials verknüpft werden.

---

```
wcf.shrinkr.special.saveFirst
```

Bitte speichern Sie die URL zuerst, bevor Sie Specials verwalten können.

---

```
wcf.shrinkr.special.saveFirst
```

Bitte speichere die URL zuerst, bevor du Specials verwalten kannst.

---

```
wcf.shrinkr.special.deleteConfirm
```

Möchten Sie dieses Special wirklich löschen?

---

```
wcf.shrinkr.special.deleteConfirm
```

Möchtest du dieses Special wirklich löschen?

---

```
wcf.shrinkr.special.noSpecials
```

Noch keine Specials vorhanden

---

```
wcf.shrinkr.special.theme
```

Thema

---

```
wcf.shrinkr.special.theme.description
```

Wählen Sie ein Thema aus, um vorgegebene Farben zu verwenden

---

```
wcf.shrinkr.special.theme.description
```

Wähle ein Thema aus, um vorgegebene Farben zu verwenden

---

```
wcf.shrinkr.special.title
```

Titel

---

```
wcf.shrinkr.special.title.description
```

Titel des Specials (nur für die Übersichtsseite)

---

```
wcf.shrinkr.special.discount
```

Rabatt

---

```
wcf.shrinkr.special.discount.description
```

Rabatt, der auf der Weiterleitungsseite angezeigt wird (z. B. "30%")

---

```
wcf.shrinkr.special.codes.description
```

Rabattcodes für das Special (überschreibt normale Codes)

---

```
wcf.shrinkr.special.additionalText.description
```

Zusätzlicher HTML-Text für das Special (überschreibt normalen Zusatztext)

---

```
wcf.shrinkr.special.startTime
```

Startzeit

---

```
wcf.shrinkr.special.startTime.description
```

Startzeitpunkt des Specials (Datum und Uhrzeit)

---

```
wcf.shrinkr.special.endTime
```

Endzeit

---

```
wcf.shrinkr.special.endTime.description
```

Endzeitpunkt des Specials (Datum und Uhrzeit)

---

```
wcf.shrinkr.special.isActive
```

Aktiv

---

```
wcf.shrinkr.special.isActive.description
```

Das Special ist aktiviert. Der Countdown läuft weiter, auch wenn deaktiviert.

---

```
wcf.shrinkr.special.isActive.yes
```

Aktiv

---

```
wcf.shrinkr.special.isActive.no
```

Inaktiv

---

```
wcf.shrinkr.special.urlHash
```

Kurz-URL

---

```
wcf.shrinkr.special.shortUrl
```

Kurz-URL / Hash

---

```
wcf.shrinkr.special.shortUrl.placeholder
```

z. B. #42 oder mylink

---

```
wcf.shrinkr.special.timeRange
```

Zeitplan

---

```
wcf.shrinkr.special.timeRange.start
```

Start

---

```
wcf.shrinkr.special.timeRange.end
```

Ende

---

```
wcf.shrinkr.special.timeRange.notConfigured
```

Kein Zeitplan konfiguriert

---

```
wcf.shrinkr.special.urlList
```

Kurz-URLs öffnen

---

```
wcf.shrinkr.special.refresh
```

Liste neu laden

---

```
wcf.shrinkr.special.status
```

Status

---

```
wcf.shrinkr.special.status.active
```

Aktiv

---

```
wcf.shrinkr.special.status.expired
```

Abgelaufen

---

```
wcf.shrinkr.special.status.scheduled
```

Geplant

---

```
wcf.shrinkr.special.status.inactive
```

Inaktiv

---

```
wcf.shrinkr.special.editUrl
```

Kurz-URL bearbeiten

---

```
wcf.shrinkr.additionalText
```

Zusätzlicher Text

---

```
wcf.shrinkr.additionalText.description
```

HTML-formatierter Text, der unter den Rabattcodes angezeigt wird

---

```
wcf.shrinkr.codes
```

Rabattcodes

---

```
wcf.shrinkr.codes.description
```

Ein oder mehrere Rabattcodes (Standard: SHRINKR). Weitere Codes können hinzugefügt werden.

---

```
wcf.shrinkr.copyCode
```

Rabattcode kopieren

---

```
wcf.shrinkr.copyCode.success
```

Rabattcode wurde erfolgreich kopiert.

---

```
wcf.shrinkr.copyCode.error
```

Beim Kopieren des Codes ist ein Fehler aufgetreten.

---

```
wcf.shrinkr.codes.single
```

Rabattcode

---

```
wcf.shrinkr.codes.multiple
```

Rabattcodes

---

```
wcf.shrinkr.code.clickToCopy
```

Klicken zum Kopieren

---

```
wcf.shrinkr.copySpecialData
```

Special-Daten kopieren

---

```
wcf.shrinkr.discount
```

Rabatt

---

```
wcf.shrinkr.discount.description
```

Geben Sie den Rabatt an, der auf der Weiterleitungsseite angezeigt werden soll.

---

```
wcf.shrinkr.discount.description
```

Gib den Rabatt an, der auf der Weiterleitungsseite angezeigt werden soll.

---

```
wcf.shrinkr.discount.placeholder
```

z. B. 30%, 10€ oder Black Friday

---

```
wcf.shrinkr.discount.favicon.description
```

Das Favicon wird automatisch von der Ziel-URL geladen. Wenn Sie ein Favicon manuell hochladen, hat dieses Vorrang.

---

```
wcf.shrinkr.discount.favicon.description
```

Das Favicon wird automatisch von der Ziel-URL geladen. Wenn du ein Favicon manuell hochlädst, hat dieses Vorrang.

---

```
wcf.shrinkr.discount.special
```

Special-Vorlage

---

```
wcf.shrinkr.discount.specialIdentifier
```

Identifier

---

```
wcf.shrinkr.discount.countdown.active
```

Aktiv

---

```
wcf.shrinkr.discount.countdown.expired
```

Abgelaufen

---

```
wcf.shrinkr.discount.countdown.notConfigured
```

Nicht konfiguriert

---

```
wcf.shrinkr.colors.primary
```

Primäre Farben

---

```
wcf.shrinkr.colors.secondary
```

Sekundäre Farben

---

```
wcf.shrinkr.primaryColor
```

Hintergrundfarbe

---

```
wcf.shrinkr.primaryColor.description
```

Hauptfarbe für Hintergründe und große Flächen

---

```
wcf.shrinkr.secondaryColor
```

Akzentfarbe

---

```
wcf.shrinkr.secondaryColor.description
```

Farbe für Akzente, Buttons und Hervorhebungen

---

```
wcf.shrinkr.primaryTextColor
```

Textfarbe (Primär)

---

```
wcf.shrinkr.primaryTextColor.description
```

Textfarbe auf der Hintergrundfarbe

---

```
wcf.shrinkr.secondaryTextColor
```

Textfarbe (Sekundär)

---

```
wcf.shrinkr.secondaryTextColor.description
```

Textfarbe auf der Akzentfarbe

---

```
wcf.shrinkr.theme
```

Theme

---

```
wcf.shrinkr.theme.identifier
```

Identifier

---

```
wcf.shrinkr.theme.identifier.description
```

Eindeutiger Schlüssel für das Theme (z. B. halloween, christmas). Wird in der URL verwendet.

---

```
wcf.shrinkr.theme.identifier.error.notUnique
```

Dieser Identifier wird bereits verwendet. Bitte wählen Sie einen anderen.

---

```
wcf.shrinkr.theme.identifier.error.notUnique
```

Dieser Identifier wird bereits verwendet. Bitte wähle einen anderen.

---

```
wcf.shrinkr.theme.title
```

Titel

---

```
wcf.shrinkr.theme.title.description
```

Anzeigename des Themes (z. B. Halloween, Weihnachten).

---

```
wcf.shrinkr.theme.effect
```

Spezialeffekt

---

```
wcf.shrinkr.theme.effect.description
```

Bestimmt, welcher visuelle Effekt bei Specials mit diesem Theme ausgeführt wird.

---

```
wcf.shrinkr.theme.effect.none
```

Kein Effekt

---

```
wcf.shrinkr.theme.effect.autumnLeaves
```

Herbstblätter

---

```
wcf.shrinkr.theme.effect.snow
```

Schneefall

---

```
wcf.shrinkr.theme.effect.ghosts
```

Halloween-Geister

---

```
wcf.shrinkr.theme.colors
```

Farben

---

```
wcf.shrinkr.theme.color.primary
```

Hauptfarbe

---

```
wcf.shrinkr.theme.color.primaryText
```

Hauptfarbe Text

---

```
wcf.shrinkr.theme.color.secondary
```

Akzentfarbe

---

```
wcf.shrinkr.theme.color.secondaryText
```

Akzentfarbe Text

---

```
wcf.shrinkr.theme.primaryColor.description
```

Hauptfarbe des Themes (z. B. für Hintergrund)

---

```
wcf.shrinkr.theme.secondaryColor.description
```

Sekundärfarbe des Themes (z. B. für Akzente)

---

```
wcf.shrinkr.theme.primaryTextColor.description
```

Textfarbe auf der Hauptfarbe

---

```
wcf.shrinkr.theme.secondaryTextColor.description
```

Textfarbe auf der Sekundärfarbe

---

```
wcf.shrinkr.theme.isActive
```

Aktiv

---

```
wcf.shrinkr.theme.isActive.yes
```

Aktiv

---

```
wcf.shrinkr.theme.isActive.no
```

Inaktiv

---

```
wcf.shrinkr.theme.status
```

Status

---

```
wcf.shrinkr.theme.isActive.description
```

Nur aktive Themes können in Specials ausgewählt werden.

---

```
wcf.shrinkr.theme.sortOrder
```

Sortierung

---

```
wcf.shrinkr.theme.sortOrder.description
```

Reihenfolge in der Theme-Auswahl (niedrigere Werte zuerst)

---

```
wcf.shrinkr.theme.css.edit
```

CSS bearbeiten

---

```
wcf.shrinkr.theme.css.edit.description
```

Bearbeiten Sie die CSS-Datei dieses Themes direkt im ACP. Änderungen werden in die CSS-Datei und die Datenbank geschrieben.

---

```
wcf.shrinkr.theme.css.edit.description
```

Bearbeite die CSS-Datei dieses Themes direkt im ACP. Änderungen werden in die CSS-Datei und die Datenbank geschrieben.

---

```
wcf.shrinkr.theme.css.edit.warning
```

Achtung: Bearbeiten Sie diese CSS-Datei nur, wenn Sie wissen, was Sie tun. Änderungen an vorgefertigten Themes können das Design beeinträchtigen.

---

```
wcf.shrinkr.theme.css.edit.warning
```

Achtung: Bearbeite diese CSS-Datei nur, wenn du weißt, was du tust. Änderungen an vorgefertigten Themes können das Design beeinträchtigen.

---

```
wcf.shrinkr.theme.css.content
```

CSS-Inhalt

---

```
wcf.shrinkr.theme.css.content.description
```

Der vollständige CSS-Code für dieses Theme.

---

```
wcf.shrinkr.form.tab.basic
```

Grundeinstellungen

---

```
wcf.shrinkr.form.tab.period
```

Zeitraum

---

```
wcf.shrinkr.form.tab.additionalText
```

Zusatztext

---

```
wcf.shrinkr.form.tab.css
```

CSS bearbeiten

---

```
wcf.shrinkr.form.section.basic
```

Grundeinstellungen

---

```
wcf.shrinkr.form.section.basic.description
```

Identifier, Titel, Effekt und Status des Themes

---

```
wcf.shrinkr.form.section.basic.description.description
```

Titel und Beschreibungstext

---

```
wcf.shrinkr.form.section.colors
```

Farben für Promo Badge

---

```
wcf.shrinkr.form.section.colors.description
```

Primäre Farben (linke Seite) und Sekundäre Farben (rechte Seite) des Promo Badges

---

```
wcf.shrinkr.form.section.settings
```

Einstellungen

---

```
wcf.shrinkr.form.section.settings.description
```

Status und Sichtbarkeit

---

```
wcf.shrinkr.countdownStart
```

Countdown Start

---

```
wcf.shrinkr.countdownStart.description
```

Startzeit der Countdown-Aktion (Datum und Uhrzeit)

---

```
wcf.shrinkr.countdownEnd
```

Countdown

---

```
wcf.shrinkr.countdownEnd.description
```

Endzeit der Countdown-Aktion (Datum und Uhrzeit)

---

```
wcf.shrinkr.countdown.expired
```

BEENDET

---

```
wcf.shrinkr.countdown.textColor
```

Countdown Textfarbe

---

```
wcf.shrinkr.countdown.textColor.description
```

Textfarbe für den Countdown-Timer

---

```
wcf.shrinkr.countdown.backgroundColor
```

Countdown Hintergrundfarbe

---

```
wcf.shrinkr.countdown.backgroundColor.description
```

Hintergrundfarbe für den Countdown-Timer

---

```
wcf.shrinkr.badge.textColor
```

Badge Textfarbe

---

```
wcf.shrinkr.badge.textColor.description
```

Textfarbe für das Badge

---

```
wcf.shrinkr.badge.backgroundColor
```

Badge Hintergrundfarbe

---

```
wcf.shrinkr.badge.backgroundColor.description
```

Hintergrundfarbe für das Badge

---

```
wcf.shrinkr.url.urlTitle
```

Titel der Ziel-URL

---

```
wcf.shrinkr.url.urlTitle.description
```

Titel, der auf der Weiterleitungsseite angezeigt wird

---

```
wcf.shrinkr.url.linkTitle.placeholder
```

Empfohlene Links

---

```
wcf.shrinkr.likeableUrl.notification
```

Jemand hat auf deine Kurz-URL reagiert

---

```
wcf.shrinkr.likeableUrl.notification.title
```

Reaktion auf Kurz-URL

---

```
wcf.shrinkr.description.title
```

Titel

---

```
wcf.shrinkr.description.title.description
```

Ein kurzer Titel für diese Beschreibung (nur im ACP sichtbar)

---

```
wcf.shrinkr.description.descriptionText
```

Beschreibungstext

---

```
wcf.shrinkr.description.descriptionText.description
```

Beschreibungstext für die Weiterleitungsseite (HTML & Smarty erlaubt).<br><br><strong>Variablen (klicken zum Einfügen):</strong><br><button type="button" class="button small descriptionVariable" data-variable="{literal}{$url}{/literal}">{icon size=16 name='plus'} <span>Ziel-URL</span></button> <button type="button" class="button small descriptionVariable" data-variable="{literal}{$extractedTitle}{/literal}">{icon size=16 name='plus'} <span>Seitentitel</span></button> <button type="button" class="button small descriptionVariable" data-variable="{literal}{$discount->discountValue}{/literal}">{icon size=16 name='plus'} <span>Rabatt-Titel</span></button><br><br><strong>Platzhalter:</strong><br><button type="button" class="button small descriptionVariable" data-variable="[[FAV_URL_LINK]]">{icon size=16 name='plus'} <span>Link mit Favicon</span></button>

---

```
wcf.shrinkr.description.isActive
```

Aktiv

---

```
wcf.shrinkr.description.preview
```

Vorschau

---

```
wcf.shrinkr.description.isActive.description
```

Nur aktive Beschreibungen werden auf der Weiterleitungsseite zufällig angezeigt.

---

```
wcf.shrinkr.description.isActive.yes
```

Aktiv

---

```
wcf.shrinkr.description.isActive.no
```

Inaktiv

---

```
wcf.shrinkr.description.status
```

Status

---

```
wcf.shrinkr.featuredLink.add
```

Featured Link hinzufügen

---

```
wcf.shrinkr.featuredLink.addAnother
```

Weiteren Featured Link hinzufügen

---

```
wcf.shrinkr.featuredLink.manage
```

Featured Links verwalten

---

```
wcf.shrinkr.featuredLink.manage.description
```

Verwalten Sie empfohlene Links für diese URL

---

```
wcf.shrinkr.featuredLink.manage.description
```

Verwalte empfohlene Links für diese URL

---

```
wcf.shrinkr.featuredLink.noItems
```

Es wurden keine Featured Links gefunden. Featured Links können nur über die URL-Bearbeitung hinzugefügt werden.

---

```
wcf.shrinkr.featuredLink.goToUrls
```

Zu den Kurz-URLs

---

```
wcf.shrinkr.featuredLink.section
```

Featured Links

---

```
wcf.shrinkr.featuredLink.section.description
```

Empfohlene Links die auf der Weiterleitungsseite angezeigt werden

---

```
wcf.shrinkr.featuredLink.noItemsInUrl
```

Für diese URL wurden noch keine Featured Links hinzugefügt.

---

```
wcf.shrinkr.featuredLink.saveFirst
```

Bitte speichern Sie die URL zuerst, bevor Sie Featured Links verwalten können.

---

```
wcf.shrinkr.featuredLink.saveFirst
```

Bitte speichere die URL zuerst, bevor du Featured Links verwalten kannst.

---

```
wcf.shrinkr.featuredLink.deleteConfirm
```

Möchten Sie diesen Featured Link wirklich löschen?

---

```
wcf.shrinkr.featuredLink.deleteConfirm
```

Möchtest du diesen Featured Link wirklich löschen?

---

```
wcf.shrinkr.featuredLink.noLinks
```

Noch keine Featured Links vorhanden

---

```
wcf.shrinkr.featuredLink.url
```

URL

---

```
wcf.shrinkr.featuredLink.url.description
```

Die vollständige URL des empfohlenen Links (z. B. https://amazon.de/produkt)

---

```
wcf.shrinkr.featuredLink.title.description
```

Titel des empfohlenen Links, der auf der Weiterleitungsseite angezeigt wird

---

```
wcf.shrinkr.featuredLink.error.titleOrUrlRequired
```

Bitte Titel oder URL angeben.

---

```
wcf.shrinkr.featuredLink.sortOrder
```

Sortierung

---

```
wcf.shrinkr.featuredLink.sortOrder.description
```

Reihenfolge der Anzeige (niedrigere Werte werden zuerst angezeigt)

---

```
wcf.shrinkr.featuredLink.urlInfo
```

Kurz-URL

---

```
wcf.shrinkr.featuredLink.urlInfo.description
```

Klicken Sie auf den Hash, um zur Kurz-URL zu gelangen

---

```
wcf.shrinkr.featuredLink.urlInfo.description
```

Klicke auf den Hash, um zur Kurz-URL zu gelangen

---

```
wcf.shrinkr.featuredLink.backToUrl
```

Zur Kurz-URL

---

```
wcf.shrinkr.featuredLink.forHash
```

Ziel

---

```
wcf.shrinkr.featuredLink.editUrl
```

Kurz-URL bearbeiten

---

```
shrinkr.acp.featuredLink.list.description
```

Übersicht aller Featured Links. Sie erscheinen auf der Weiterleitungsseite (wenn Sie sie einer Kurz-URL zuweisen). Anlegen und Zuordnen: Shr1nkr → Links → Kurz-URL bearbeiten → Bereich „Featured Links“. Hier verwalten Sie die globalen Einträge.

---

```
shrinkr.acp.featuredLink.list.description
```

Übersicht aller Featured Links. Sie erscheinen auf der Weiterleitungsseite (wenn du sie einer Kurz-URL zuweist). Anlegen und Zuordnen: Shr1nkr → Links → Kurz-URL bearbeiten → Bereich „Featured Links“. Hier verwaltest du die globalen Einträge.

---

```
shrinkr.acp.special.list.description
```

Übersicht aller Specials (z. B. Aktionen, Rabatte, saisonale Events). Ein Special weisen Sie einer Kurz-URL zu; dann erscheint die Weiterleitungsseite im gewählten Theme mit dem Special-Text. Themes legen Sie unter Shr1nkr → Themes fest.

---

```
shrinkr.acp.special.list.description
```

Übersicht aller Specials (z. B. Aktionen, Rabatte, saisonale Events). Ein Special weist du einer Kurz-URL zu; dann erscheint die Weiterleitungsseite im gewählten Theme mit dem Special-Text. Themes legst du unter Shr1nkr → Themes fest.

---

```
shrinkr.acp.discount.list.description
```

Übersicht aller Rabatte. Sie legen hier Rabatt-Wert, Gutscheincode und Gültigkeit fest. Die Promo-Badges erscheinen automatisch auf der Weiterleitungsseite (vor dem Weiterklick) und informieren Besucher über aktuelle Angebote. Auswertung: Shr1nkr → Statistiken.

---

```
shrinkr.acp.discount.list.description
```

Übersicht aller Rabatte. Du legst hier Rabatt-Wert, Gutscheincode und Gültigkeit fest. Die Promo-Badges erscheinen automatisch auf der Weiterleitungsseite (vor dem Weiterklick) und informieren Besucher über aktuelle Angebote. Auswertung: Shr1nkr → Statistiken.

---

```
shrinkr.acp.description.list.description
```

Kurze Zusatztexte für die Weiterleitungsseite. Es wird jeweils ein Text zufällig aus der Liste angezeigt. So können Sie z. B. Aktionen, Hinweise oder Vertrauenstexte anzeigen, ohne die Zielseite anzupassen. Anlegen hier; Zuordnung zur Kurz-URL erfolgt über Shr1nkr → Links.

---

```
shrinkr.acp.description.list.description
```

Kurze Zusatztexte für die Weiterleitungsseite. Es wird jeweils ein Text zufällig aus der Liste angezeigt. So kannst du z. B. Aktionen, Hinweise oder Vertrauenstexte anzeigen, ohne die Zielseite anzupassen. Anlegen hier; Zuordnung zur Kurz-URL erfolgt über Shr1nkr → Links.

---

```
shrinkr.acp.theme.list.description
```

Themes legen Farben und Effekte der Weiterleitungsseite fest. Sie wählen ein Theme beim Anlegen oder Bearbeiten eines Specials (Shr1nkr → Specials). Ohne Special wird kein Theme angewendet; die Standard-Weiterleitungsseite erscheint.

---

```
shrinkr.acp.theme.list.description
```

Themes legen Farben und Effekte der Weiterleitungsseite fest. Du wählst ein Theme beim Anlegen oder Bearbeiten eines Specials (Shr1nkr → Specials). Ohne Special wird kein Theme angewendet; die Standard-Weiterleitungsseite erscheint.

---

```
wcf.shrinkr.customButton.targetUrl
```

Ziel-URL

---

```
wcf.shrinkr.customButton.targetUrl.description
```

Die URL, zu der der Button weiterleitet

---

```
wcf.shrinkr.customButton.title
```

Titel

---

```
wcf.shrinkr.customButton.title.description
```

Titel des Buttons, der auf der Weiterleitungsseite angezeigt wird

---

```
wcf.shrinkr.customButton.error.titleOrUrlRequired
```

Bitte Titel oder Ziel-URL angeben.

---

```
wcf.shrinkr.customButton.sortOrder
```

Sortierung

---

```
wcf.shrinkr.customButton.sortOrder.description
```

Reihenfolge der Anzeige (niedrigere Werte werden zuerst angezeigt)

---

```
wcf.shrinkr.customButton.urlInfo
```

Kurz-URL

---

```
wcf.shrinkr.customButton.urlInfo.description
```

Klicken Sie auf den Kurzcode (Hash), um die Kurz-URL im Frontend zu öffnen.

---

```
wcf.shrinkr.customButton.urlInfo.description
```

Klicke auf den Kurzcode (Hash), um die Kurz-URL im Frontend zu öffnen.

---

```
wcf.shrinkr.customButton.backToUrl
```

Zur Kurz-URL

---

```
wcf.shrinkr.customButton.forHash
```

Ziel

---

```
wcf.shrinkr.customButton.editUrl
```

Kurz-URL bearbeiten

---

```
wcf.shrinkr.customButton.noItems
```

Es wurden keine Custom Buttons gefunden.

---

```
wcf.shrinkr.customButton.noItemsInUrl
```

Für diese Kurz-URL wurden noch keine Custom Buttons angelegt.

---

```
wcf.shrinkr.customButton.goToUrls
```

Zur URL-Liste

---

```
wcf.shrinkr.customButton.section
```

Custom Buttons

---

```
wcf.shrinkr.customButton.section.description
```

Verwalten Sie Custom Buttons, die direkt unter dem Forward-Button angezeigt werden.

---

```
wcf.shrinkr.customButton.section.description
```

Verwalte Custom Buttons, die direkt unter dem Forward-Button angezeigt werden.

---

```
wcf.shrinkr.customButton.add
```

Custom Button hinzufügen

---

```
wcf.shrinkr.customButton.addAnother
```

Weiteren Custom Button hinzufügen

---

```
shrinkr.acp.customButton.list.description
```

Übersicht aller Custom Buttons. Sie erscheinen auf der Weiterleitungsseite direkt unter dem Weiter-Button (wenn Sie sie einer Kurz-URL zuweisen). Anlegen und Zuordnen: Shr1nkr → Links → Kurz-URL bearbeiten → Bereich „Custom Buttons“. Hier verwalten Sie die globalen Einträge.

---

```
shrinkr.acp.customButton.list.description
```

Übersicht aller Custom Buttons. Sie erscheinen auf der Weiterleitungsseite direkt unter dem Weiter-Button (wenn du sie einer Kurz-URL zuweist). Anlegen und Zuordnen: Shr1nkr → Links → Kurz-URL bearbeiten → Bereich „Custom Buttons“. Hier verwaltest du die globalen Einträge.

---

```
wcf.shrinkr.url.ogImage
```

Open Graph Bild

---

```
wcf.shrinkr.url.ogImage.description
```

Bild, das beim Teilen des Links in Social Media (Facebook, X, etc.) angezeigt wird. Empfohlen: Mindestens 1200x630 Pixel.

---

```
wcf.shrinkr.url.password
```

Passwort

---

```
wcf.shrinkr.url.password.description
```

Optional: Schützt die Kurz-URL mit einem Passwort. Besucher müssen es eingeben, bevor sie zur Ziel-URL weitergeleitet werden.

---

```
wcf.shrinkr.url.password.description
```

Optional: Schützt die Kurz-URL mit einem Passwort. Besucher müssen es eingeben, bevor sie zur Ziel-URL weitergeleitet werden.

---

```
wcf.shrinkr.url.passwordProtected
```

Passwort-geschützt

---

```
wcf.shrinkr.password.dialog.title
```

Passwort erforderlich

---

```
wcf.shrinkr.password.label
```

Passwort

---

```
wcf.shrinkr.password.description
```

Bitte geben Sie das Passwort ein, um auf die Kurz-URL zuzugreifen.

---

```
wcf.shrinkr.password.description
```

Bitte gib das Passwort ein, um auf die Kurz-URL zuzugreifen.

---

```
wcf.shrinkr.password.error.empty
```

Bitte geben Sie ein Passwort ein.

---

```
wcf.shrinkr.password.error.empty
```

Bitte gib ein Passwort ein.

---

```
wcf.shrinkr.password.error.wrong
```

Das eingegebene Passwort ist falsch.

---

```
wcf.shrinkr.password.error.wrong
```

Das eingegebene Passwort ist falsch.

---

```
wcf.shrinkr.password.error.rateLimitExceeded
```

Zu viele fehlgeschlagene Versuche. Bitte versuchen Sie es später erneut.

---

```
wcf.shrinkr.password.error.rateLimitExceeded
```

Zu viele fehlgeschlagene Versuche. Bitte versuche es später erneut.

---

```
wcf.shrinkr.password.error.invalidLink
```

Ungültige Kurz-URL.

---

```
wcf.shrinkr.password.error.invalidLink
```

Ungültige Kurz-URL.

---

```
wcf.shrinkr.password.error.notRequired
```

Für diese Kurz-URL ist kein Passwort erforderlich.

---

```
wcf.shrinkr.password.error.notRequired
```

Für diese Kurz-URL ist kein Passwort erforderlich.

---

```
wcf.shrinkr.password.success
```

Passwort korrekt. Sie werden weitergeleitet...

---

```
wcf.shrinkr.password.success
```

Passwort korrekt. Du wirst weitergeleitet...

---

```
shrinkr.redirect.password.title
```

Passwort erforderlich

---

```
shrinkr.redirect.password.label
```

Passwort

---

```
shrinkr.redirect.password.description
```

Bitte geben Sie das Passwort ein, um auf die Kurz-URL zuzugreifen.

---

```
shrinkr.redirect.password.description
```

Bitte gib das Passwort ein, um auf die Kurz-URL zuzugreifen.

---

```
shrinkr.redirect.password.error.empty
```

Bitte geben Sie ein Passwort ein.

---

```
shrinkr.redirect.password.error.empty
```

Bitte gib ein Passwort ein.

---

```
shrinkr.redirect.password.error.invalid
```

Das eingegebene Passwort ist ungültig.

---

```
shrinkr.redirect.password.error.invalid
```

Das eingegebene Passwort ist ungültig.

---

```
shrinkr.redirect.password.error.general
```

Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.

---

```
shrinkr.redirect.password.error.general
```

Ein Fehler ist aufgetreten. Bitte versuche es erneut.

---

```
wcf.shrinkr.geolite2.database_provider.default
```

Standard (Standard)

---

```
wcf.shrinkr.geolite2.database_provider.maxmind
```

MaxMind (Eigener Account)

---

```
wcf.shrinkr.geolite2.database_provider.local
```

Lokale Datenbank

---

```
wcf.shrinkr.global.all
```

Alle

---

```
wcf.shrinkr.reaction.thankYou
```

Vielen Dank für Ihr Feedback.

---

```
wcf.shrinkr.reaction.thankYou
```

Vielen Dank für dein Feedback.

---

```
wcf.acp.menu.link.shrinkr.statistic
```

Statistiken

---

```
shrinkr.acp.statistic.title
```

Statistiken

---

```
shrinkr.acp.statistic.comingSoon.title
```

In Kürze verfügbar

---

```
shrinkr.acp.statistic.comingSoon.description
```

Die Statistik-Funktion wird in einer zukünftigen Version verfügbar sein.

---

```
shrinkr.acp.statistic.comingSoon.description
```

Die Statistik-Funktion wird in einer zukünftigen Version verfügbar sein.

---

```
shrinkr.acp.statistic.description
```

Übersicht über Klicks, Besucher und Interaktionen zu Ihren Kurz-URLs. Sie können nach Link (Hash oder ID) filtern; die Daten beziehen sich auf die in der Link-Liste angelegten URLs sowie auf Gutscheine und Einmalnachrichten.

---

```
shrinkr.acp.statistic.description
```

Übersicht über Klicks, Besucher und Interaktionen zu deinen Kurz-URLs. Du kannst nach Link (Hash oder ID) filtern; die Daten beziehen sich auf die in der Link-Liste angelegten URLs sowie auf Gutscheine und Einmalnachrichten.

---

```
shrinkr.acp.statistic.systemOverview
```

System-Übersicht

---

```
shrinkr.acp.statistic.systemOverview.description
```

Bestandsaufnahme aller Features im System: Wie viele Links, Featured Links, Custom Buttons, Specials und Reaktionen sind vorhanden?

---

```
shrinkr.acp.statistic.systemOverview.description
```

Bestandsaufnahme aller Features im System: Wie viele Links, Featured Links, Custom Buttons, Specials und Reaktionen sind vorhanden?

---

```
shrinkr.acp.statistic.totalLinks
```

Links gesamt

---

```
shrinkr.acp.statistic.activeLinks
```

Aktive Links

---

```
shrinkr.acp.statistic.totalFeaturedLinks
```

Featured Links gesamt

---

```
shrinkr.acp.statistic.totalCustomButtons
```

Custom Buttons gesamt

---

```
shrinkr.acp.statistic.totalSpecials
```

Specials/Themes gesamt

---

```
shrinkr.acp.statistic.linksWithSpecials
```

Links mit Specials

---

```
shrinkr.acp.statistic.linksWithCustomButtons
```

Links mit Custom Buttons

---

```
shrinkr.acp.statistic.linksWithFeaturedLinks
```

Links mit Featured Links

---

```
shrinkr.acp.statistic.specialsByTheme
```

Specials nach Theme

---

```
shrinkr.acp.statistic.specialTrend
```

Special-Trend

---

```
shrinkr.acp.statistic.specialTrend.description
```

Zeigt die Entwicklung von Special-Aufrufen über den gewählten Zeitraum.

---

```
shrinkr.acp.statistic.specialDetails
```

Special-Details

---

```
shrinkr.acp.statistic.specialDetails.description
```

Detaillierte Auflistung aller Special-Events nach Link und Special-Typ.

---

```
shrinkr.acp.statistic.reactionTypes
```

Reaction-Typen

---

```
shrinkr.acp.statistic.reactionTypes.description
```

Folgende Reaction-Typen wurden in den letzten 30 Tagen verwendet:

---

```
shrinkr.acp.statistic.reactionTypes.description
```

Folgende Reaction-Typen wurden in den letzten 30 Tagen verwendet:

---

```
shrinkr.acp.statistic.count
```

Anzahl

---

```
shrinkr.acp.statistic.hash
```

Hash

---

```
shrinkr.acp.statistic.overview
```

Übersicht

---

```
shrinkr.acp.statistic.overview.description
```

Die wichtigsten Kennzahlen auf einen Blick: Wie viele Besucher haben Ihre Links heute, diese Woche und insgesamt erreicht?

---

```
shrinkr.acp.statistic.overview.description
```

Die wichtigsten Kennzahlen auf einen Blick: Wie viele Besucher haben deine Links heute, diese Woche und insgesamt erreicht?

---

```
shrinkr.acp.statistic.today
```

Heute

---

```
shrinkr.acp.statistic.today.description
```

Besuche seit Mitternacht heute.

---

```
shrinkr.acp.statistic.today.description
```

Besuche seit Mitternacht heute.

---

```
shrinkr.acp.statistic.yesterday
```

Gestern

---

```
shrinkr.acp.statistic.thisWeek
```

Diese Woche

---

```
shrinkr.acp.statistic.thisWeek.description
```

Besuche seit Montag dieser Woche.

---

```
shrinkr.acp.statistic.thisWeek.description
```

Besuche seit Montag dieser Woche.

---

```
shrinkr.acp.statistic.thisMonth
```

Dieser Monat

---

```
shrinkr.acp.statistic.total
```

Gesamt

---

```
shrinkr.acp.statistic.total.description
```

Alle Besuche seit Aktivierung des Trackings.

---

```
shrinkr.acp.statistic.total.description
```

Alle Besuche seit Aktivierung des Trackings.

---

```
shrinkr.acp.statistic.interactionsToday
```

Interaktionen heute

---

```
shrinkr.acp.statistic.interactionsToday.description
```

Button-Klicks und Reaktionen seit Mitternacht heute.

---

```
shrinkr.acp.statistic.interactionsToday.description
```

Button-Klicks und Reaktionen seit Mitternacht heute.

---

```
shrinkr.acp.statistic.visitTrend
```

Besucherverlauf

---

```
shrinkr.acp.statistic.topLinks
```

Meistbesuchte Links

---

```
shrinkr.acp.statistic.visits
```

Besuche

---

```
shrinkr.acp.statistic.visitors
```

Besucher

---

```
shrinkr.acp.statistic.visitors.description
```

Detaillierte Informationen über Ihre Besucher: Welche Browser und Betriebssysteme werden genutzt? Aus welchen Ländern kommen Ihre Besucher? Welche Geräte werden verwendet?

---

```
shrinkr.acp.statistic.visitors.description
```

Detaillierte Informationen über deine Besucher: Welche Browser und Betriebssysteme werden genutzt? Aus welchen Ländern kommen deine Besucher? Welche Geräte werden verwendet?

---

```
shrinkr.acp.statistic.hourlyDistribution
```

Stündliche Verteilung

---

```
shrinkr.acp.statistic.hourlyDistribution.description
```

Zeigt die Besucherverteilung über 24 Stunden der letzten 7 Tage an.

---

```
shrinkr.acp.statistic.hourlyDistribution.description
```

Zeigt die Besucherverteilung über 24 Stunden der letzten 7 Tage an.

---

```
shrinkr.acp.statistic.hourlyTooltipSuffix
```

Uhr

---

```
shrinkr.acp.statistic.interactionTypes
```

Interaktionstypen

---

```
shrinkr.acp.statistic.filter
```

Filter

---

```
shrinkr.acp.statistic.filter.apply
```

Filter anwenden

---

```
shrinkr.acp.statistic.period
```

Zeitraum

---

```
shrinkr.acp.statistic.startDate.description
```

Anfangsdatum des angezeigten Zeitraums.

---

```
shrinkr.acp.statistic.startDate.description
```

Anfangsdatum des angezeigten Zeitraums.

---

```
shrinkr.acp.statistic.endDate.description
```

Enddatum des angezeigten Zeitraums.

---

```
shrinkr.acp.statistic.endDate.description
```

Enddatum des angezeigten Zeitraums.

---

```
shrinkr.acp.statistic.linkFilter.description
```

Optional: Wenn Sie einen Kurz-URL-Hash oder eine ID eingeben, werden nur die Statistiken für diese eine Kurz-URL angezeigt. Beim Tippen erscheinen Vorschläge aus Ihren Links. Leer lassen = Statistiken für alle Kurz-URLs.

---

```
shrinkr.acp.statistic.linkFilter.description
```

Optional: Wenn du einen Kurz-URL-Hash oder eine ID eingibst, werden nur die Statistiken für diese eine Kurz-URL angezeigt. Beim Tippen erscheinen Vorschläge aus deinen Links. Leer lassen = Statistiken für alle Kurz-URLs.

---

```
shrinkr.acp.statistic.tabs
```

Statistik-Bereiche

---

```
shrinkr.acp.statistic.uniqueVisitors
```

Eindeutige Besucher

---

```
shrinkr.acp.statistic.uniqueVisitors.description
```

Verschiedene Personen, die Ihre Links besucht haben. Besucht dieselbe Person einen Link mehrmals, wird sie nur einmal gezählt.

---

```
shrinkr.acp.statistic.uniqueVisitors.description
```

Verschiedene Personen, die deine Links besucht haben. Besucht dieselbe Person einen Link mehrmals, wird sie nur einmal gezählt.

---

```
shrinkr.acp.statistic.uniqueVisitorsToday
```

Eindeutige Besucher (Heute)

---

```
shrinkr.acp.statistic.uniqueVisitorsTotal
```

Eindeutige Besucher (Gesamt)

---

```
shrinkr.acp.statistic.avgClicksPerLink
```

Ø Klicks pro Link

---

```
shrinkr.acp.statistic.avgClicksPerLink.description
```

Durchschnittliche Anzahl der Button-Klicks auf jedem Ihrer Links.

---

```
shrinkr.acp.statistic.avgClicksPerLink.description
```

Durchschnittliche Anzahl der Button-Klicks auf jedem deiner Links.

---

```
shrinkr.acp.statistic.conversionRate
```

Klickrate

---

```
shrinkr.acp.statistic.conversionRate.description
```

Der Prozentsatz der Besucher, die auf einen Button geklickt haben. Beispiel: 25% bedeutet, dass jeder vierte Besucher einen Button angeklickt hat.

---

```
shrinkr.acp.statistic.conversionRate.description
```

Der Prozentsatz der Besucher, die auf einen Button geklickt haben. Beispiel: 25% bedeutet, dass jeder vierte Besucher einen Button angeklickt hat.

---

```
shrinkr.acp.statistic.mostActiveHour
```

Aktivste Stunde

---

```
shrinkr.acp.statistic.mostActiveHour.description
```

Die Tageszeit, zu der Ihre Links am häufigsten besucht werden.

---

```
shrinkr.acp.statistic.mostActiveHour.description
```

Die Tageszeit, zu der deine Links am häufigsten besucht werden.

---

```
shrinkr.acp.statistic.mostActiveWeekday
```

Aktivster Wochentag

---

```
shrinkr.acp.statistic.mostActiveWeekday.description
```

Der Wochentag, an dem Ihre Links am häufigsten besucht werden.

---

```
shrinkr.acp.statistic.mostActiveWeekday.description
```

Der Wochentag, an dem deine Links am häufigsten besucht werden.

---

```
shrinkr.acp.statistic.linkPerformance
```

Link Performance

---

```
shrinkr.acp.statistic.linkPerformance.description
```

Detaillierte Statistiken für alle Ihre Kurz-URLs

---

```
shrinkr.acp.statistic.linkPerformance.description
```

Detaillierte Statistiken für alle deine Kurz-URLs

---

```
shrinkr.acp.statistic.linkName
```

Link-Name

---

```
shrinkr.acp.statistic.lastActivity
```

Letzte Aktivität

---

```
shrinkr.acp.statistic.noLinks
```

Keine Links vorhanden

---

```
shrinkr.acp.statistic.interactionDetails
```

Interaktions-Details

---

```
shrinkr.acp.statistic.interactionDetails.description
```

Detaillierte Aufschlüsselung aller Interaktionstypen

---

```
shrinkr.acp.statistic.interactionDetails.description
```

Detaillierte Aufschlüsselung aller Interaktionstypen

---

```
shrinkr.acp.statistic.interactionType
```

Interaktionstyp

---

```
shrinkr.acp.statistic.total
```

Gesamt

---

```
shrinkr.acp.statistic.unique
```

Unique

---

```
shrinkr.acp.statistic.avgPerDay
```

Ø pro Tag

---

```
shrinkr.acp.statistic.trend
```

Trend

---

```
shrinkr.acp.statistic.noInteractions
```

Keine Interaktionen vorhanden

---

```
shrinkr.acp.statistic.timeAnalysis
```

Zeitanalyse

---

```
shrinkr.acp.statistic.weekdayDistribution
```

Wochentags-Verteilung

---

```
shrinkr.acp.statistic.weekdayDistribution.description
```

Besucherverteilung über die Wochentage der letzten 30 Tage

---

```
shrinkr.acp.statistic.monthlyOverview
```

Monatliche Übersicht

---

```
shrinkr.acp.statistic.monthlyOverview.description
```

Besucherentwicklung der letzten 12 Monate

---

```
shrinkr.acp.statistic.peakTimes
```

Peak-Zeiten

---

```
shrinkr.acp.statistic.peakTimes.description
```

Die 5 Stunden mit den meisten Besuchen

---

```
shrinkr.acp.statistic.hour
```

Stunde

---

```
shrinkr.acp.statistic.trafficSources
```

Traffic-Quellen

---

```
shrinkr.acp.statistic.trafficSources.description
```

Von welchen Websites kommen Ihre Besucher? Hier sehen Sie die häufigsten Herkunftsseiten (z. B. Google, Facebook, andere Websites).

---

```
shrinkr.acp.statistic.trafficSources.description
```

Von welchen Websites kommen deine Besucher? Hier siehst du die häufigsten Herkunftsseiten.

---

```
shrinkr.acp.statistic.referer
```

Herkunft

---

```
shrinkr.acp.statistic.referer.description
```

Die Website, von der ein Besucher auf Ihren Link gekommen ist (z. B. Google, Facebook, ein Forum).

---

```
shrinkr.acp.statistic.directTraffic
```

Direkter Aufruf

---

```
shrinkr.acp.statistic.directTraffic.description
```

Der Besucher hat die Kurz-URL direkt eingegeben oder aus einem Lesezeichen geöffnet.

---

```
shrinkr.acp.statistic.noReferers
```

Noch keine Herkunftsdaten vorhanden

---

```
shrinkr.acp.statistic.browserOS
```

Browser & Geräte

---

```
shrinkr.acp.statistic.browserOS.description
```

Welche Browser und Betriebssysteme nutzen Ihre Besucher?

---

```
shrinkr.acp.statistic.browserOS.description
```

Welche Browser und Betriebssysteme nutzen deine Besucher?

---

```
shrinkr.acp.statistic.browser
```

Browser

---

```
shrinkr.acp.statistic.os
```

Betriebssystem

---

```
shrinkr.acp.statistic.version
```

Version

---

```
shrinkr.acp.statistic.percentage
```

Anteil

---

```
shrinkr.acp.statistic.noBrowserData
```

Keine Browser-Daten vorhanden

---

```
shrinkr.acp.statistic.noOSData
```

Keine Betriebssystem-Daten vorhanden

---

```
shrinkr.acp.statistic.countries
```

Länder-Verteilung

---

```
shrinkr.acp.statistic.countries.description
```

Aus welchen Ländern kommen Ihre Besucher?

---

```
shrinkr.acp.statistic.countries.description
```

Aus welchen Ländern kommen deine Besucher?

---

```
shrinkr.acp.statistic.country
```

Land

---

```
shrinkr.acp.statistic.noCountryData
```

Keine Länder-Daten vorhanden

---

```
shrinkr.acp.statistic.customButtons
```

Custom Button Performance

---

```
shrinkr.acp.statistic.customButtons.description
```

Welche Custom Buttons werden am häufigsten geklickt?

---

```
shrinkr.acp.statistic.buttonText
```

Button-Text

---

```
shrinkr.acp.statistic.clicks
```

Klicks

---

```
shrinkr.acp.statistic.uniqueClicks
```

Unique Klicks

---

```
shrinkr.acp.statistic.noCustomButtons
```

Keine Custom Buttons vorhanden

---

```
shrinkr.acp.statistic.featuredLinks
```

Featured Link Performance

---

```
shrinkr.acp.statistic.featuredLinks.description
```

Welche Featured Links werden am häufigsten geklickt?

---

```
shrinkr.acp.statistic.noFeaturedLinks
```

Keine Featured Links vorhanden

---

```
shrinkr.acp.statistic.specials
```

Special Effects / Themes

---

```
shrinkr.acp.statistic.specials.description
```

Welche saisonalen Effekte und Themes wurden wie oft angezeigt?

---

```
shrinkr.acp.statistic.theme
```

Theme/Effect

---

```
shrinkr.acp.statistic.views
```

Aufrufe

---

```
shrinkr.acp.statistic.uniqueVisitors
```

Unique Besucher

---

```
shrinkr.acp.statistic.lastSeen
```

Zuletzt gesehen

---

```
shrinkr.acp.statistic.noSpecials
```

Keine Specials vorhanden

---

```
shrinkr.acp.statistic.reactions
```

Reaktionen Performance

---

```
shrinkr.acp.statistic.reactions.description
```

Welche Reaktionen werden am häufigsten genutzt?

---

```
shrinkr.acp.statistic.reactionType
```

Reaktionstyp

---

```
shrinkr.acp.statistic.usages
```

Nutzungen

---

```
shrinkr.acp.statistic.uniqueUsers
```

Unique User

---

```
shrinkr.acp.statistic.noReactions
```

Keine Reaktionen vorhanden

---

```
shrinkr.acp.statistic.linkButtonInteractions
```

Button-Klicks pro Link

---

```
shrinkr.acp.statistic.linkButtonInteractions.description
```

Detaillierte Übersicht: Welche Buttons wurden auf welchen Links geklickt?

---

```
shrinkr.acp.statistic.noLinkButtonInteractions
```

Keine Button-Interaktionen vorhanden

---

```
shrinkr.acp.statistic.buttonType
```

Button-Typ

---

```
shrinkr.acp.statistic.devices
```

Geräte-Typen

---

```
shrinkr.acp.statistic.devices.description
```

Welche Geräte-Typen nutzen Ihre Besucher?

---

```
shrinkr.acp.statistic.devices.description
```

Welche Geräte-Typen nutzen deine Besucher?

---

```
shrinkr.acp.statistic.mobile
```

Mobile

---

```
shrinkr.acp.statistic.desktop
```

Desktop

---

```
shrinkr.acp.statistic.tablet
```

Tablet

---

```
shrinkr.acp.statistic.deviceType
```

Geräte-Typ

---

```
shrinkr.acp.statistic.visitorTypes
```

Besucher-Typen

---

```
shrinkr.acp.statistic.visitorTypes.description
```

Neue vs. wiederkehrende Besucher

---

```
shrinkr.acp.statistic.newVisitors
```

Neue Besucher

---

```
shrinkr.acp.statistic.returningVisitors
```

Wiederkehrende Besucher

---

```
shrinkr.acp.statistic.avgSessionDuration
```

Ø Verweildauer

---

```
shrinkr.acp.statistic.avgSessionDuration.description
```

Wie lange bleiben Besucher durchschnittlich auf Ihrer Weiterleitungsseite, bevor sie auf den Button klicken?

---

```
shrinkr.acp.statistic.sessionDuration
```

Verweildauer

---

```
shrinkr.acp.statistic.minutes
```

Minuten

---

```
shrinkr.acp.statistic.seconds
```

Sekunden

---

```
shrinkr.acp.statistic.showingTop
```

Zeigt die Top

---

```
shrinkr.acp.statistic.export
```

Exportieren

---

```
shrinkr.acp.statistic.exportCSV
```

Als CSV exportieren

---

```
shrinkr.acp.statistic.info.title
```

Statistik-Informationen

---

```
shrinkr.acp.statistic.info.description
```

Erklärungen zu den Statistiken, Metriken und deren Berechnung

---

```
shrinkr.acp.statistic.info.general
```

Allgemeine Informationen

---

```
shrinkr.acp.statistic.info.general.text
```

Die Shr1nkr-Statistiken bieten Ihnen einen umfassenden Überblick über die Nutzung Ihrer Kurz-URLs. Alle Daten werden DSGVO-konform erfasst: IP-Adressen werden mit einem täglichen Salt gehasht, Rohdaten werden nach der konfigurierten Aufbewahrungsfrist automatisch gelöscht. Aggregierte Statistiken bleiben dauerhaft erhalten.

---

```
shrinkr.acp.statistic.info.general.text
```

Die Shr1nkr-Statistiken bieten dir einen umfassenden Überblick über die Nutzung deiner Kurz-URLs. Alle Daten werden DSGVO-konform erfasst: IP-Adressen werden mit einem täglichen Salt gehasht, Rohdaten werden nach der konfigurierten Aufbewahrungsfrist automatisch gelöscht. Aggregierte Statistiken bleiben dauerhaft erhalten.

---

```
shrinkr.acp.statistic.info.kpis
```

Kennzahlen (KPIs)

---

```
shrinkr.acp.statistic.info.today
```

Anzahl der Besuche heute (seit Mitternacht). Jeder Aufruf einer Kurz-URL wird gezählt.

---

```
shrinkr.acp.statistic.info.uniqueVisitorsToday
```

Anzahl der einzigartigen Besucher heute. Berechnet anhand des gehashten IP/User-Agent-Fingerprints.

---

```
shrinkr.acp.statistic.info.interactionsToday
```

Anzahl aller Interaktionen heute (Button-Klicks und Reaktionen).

---

```
shrinkr.acp.statistic.info.conversionRate
```

Conversion Rate: (Interaktionen / Besuche) × 100. Zeigt an, wie viel Prozent der Besucher auf Buttons klicken oder Reaktionen abgeben.

---

```
shrinkr.acp.statistic.info.avgClicksPerLink
```

Durchschnittliche Anzahl an Klicks/Interaktionen pro Link.

---

```
shrinkr.acp.statistic.info.mostActiveHour
```

Die Stunde des Tages (0-23 Uhr), in der die meisten Besuche stattfanden.

---

```
shrinkr.acp.statistic.info.avgSessionDuration
```

Durchschnittliche Verweildauer der Besucher auf den Weiterleitungsseiten.

---

```
shrinkr.acp.statistic.info.browserOS
```

Zeigt an, welche Browser und Betriebssysteme Ihre Besucher verwenden. Die Erkennung erfolgt über den User-Agent.

---

```
shrinkr.acp.statistic.info.browserOS
```

Zeigt an, welche Browser und Betriebssysteme deine Besucher verwenden. Die Erkennung erfolgt über den User-Agent.

---

```
shrinkr.acp.statistic.info.devices
```

Verteilung der Zugriffe nach Gerät-Typ (Mobile, Desktop, Tablet). Erkennung anhand von User-Agent-Patterns.

---

```
shrinkr.acp.statistic.info.visitorTypes
```

Neue Besucher (erste Interaktion) vs. Wiederkehrende Besucher (wurden bereits zuvor erfasst). Basiert auf dem gehashten User-Fingerprint.

---

```
shrinkr.acp.statistic.info.trafficSources
```

Zeigt an, von welchen Websites (Referrer) die Besucher kamen. "Direkter Zugriff" bedeutet, dass kein Referrer vorhanden ist (z. B. direkte URL-Eingabe, Lesezeichen).

---

```
shrinkr.acp.statistic.info.button.forward
```

Klicks auf den "Weiterleiten"-Button, der zur eigentlichen Ziel-URL führt.

---

```
shrinkr.acp.statistic.info.button.custom
```

Klicks auf benutzerdefinierte Buttons, die Sie in den ACP-Einstellungen konfiguriert haben.

---

```
shrinkr.acp.statistic.info.button.custom
```

Klicks auf benutzerdefinierte Buttons, die du in den ACP-Einstellungen konfiguriert hast.

---

```
shrinkr.acp.statistic.info.button.featured_link
```

Klicks auf Featured Links (hervorgehobene Links), die ebenfalls im ACP konfiguriert werden können.

---

```
shrinkr.acp.statistic.info.reactions
```

Anzahl der Reaktionen (z. B. Likes, Emojis), die von Besuchern abgegeben wurden.

---

```
shrinkr.acp.statistic.info.privacy
```

Datenschutz & DSGVO

---

```
shrinkr.acp.statistic.info.privacy.text
```

Die Shr1nkr-Statistiken erfassen personenbezogene Daten (IP-Adressen, User-Agents) nur in anonymisierter Form:

---

```
shrinkr.acp.statistic.info.privacy.hashing
```

IP-Adressen werden mit einem täglichen Salt mittels SHA-256 gehasht. Eine Rückverfolgung auf die ursprüngliche IP ist nicht möglich.

---

```
shrinkr.acp.statistic.info.privacy.retention
```

Rohdaten (einzelne Besuche/Interaktionen) werden nach der konfigurierten Aufbewahrungsfrist automatisch gelöscht.

---

```
shrinkr.acp.statistic.info.privacy.aggregation
```

Nur aggregierte Statistiken (Tages-/Monatsübersichten) bleiben dauerhaft erhalten.

---

```
shrinkr.acp.statistic.info.experimentalWarning.title
```

WICHTIGER HINWEIS: Experimentelle Funktion

---

```
shrinkr.acp.statistic.info.experimentalWarning.text
```

Die Statistik-Funktionen sind experimentell, können sich jederzeit ändern oder entfernt werden und haben aus experimenteller Sicht keinerlei Anspruch auf Fortbestand.

---

```
shrinkr.acp.statistic.info.experimentalWarning.details
```

Diese Statistiken dienen derzeit primär der Entwicklung und dem Testen. Wir behalten uns vor, Funktionen zu ändern, zu entfernen oder die Datenspeicherung anzupassen, ohne vorherige Ankündigung.

---

```
shrinkr.acp.statistic.info.trackedData
```

Was wird getrackt?

---

```
shrinkr.acp.statistic.info.trackedData.stored
```

Gespeicherte Daten

---

```
shrinkr.acp.statistic.info.trackedData.stored.text
```

Bei jedem Besuch einer Kurz-URL werden folgende Daten erfasst:

---

```
shrinkr.acp.statistic.info.trackedData.linkID
```

Link-ID

---

```
shrinkr.acp.statistic.info.trackedData.linkID.desc
```

Welcher Link wurde besucht

---

```
shrinkr.acp.statistic.info.trackedData.timestamp
```

Zeitstempel

---

```
shrinkr.acp.statistic.info.trackedData.timestamp.desc
```

Wann wurde der Link besucht

---

```
shrinkr.acp.statistic.info.trackedData.ipHash
```

Gehashte IP-Adresse

---

```
shrinkr.acp.statistic.info.trackedData.ipHash.desc
```

Zur Unterscheidung von Besuchern (SHA-256 Hash, nicht rückverfolgbar)

---

```
shrinkr.acp.statistic.info.trackedData.userID
```

User-ID

---

```
shrinkr.acp.statistic.info.trackedData.userID.desc
```

Falls eingeloggt (optional)

---

```
shrinkr.acp.statistic.info.trackedData.browserName
```

Browser-Name

---

```
shrinkr.acp.statistic.info.trackedData.browserName.desc
```

Vereinfacht (z. B. Chrome, Firefox), keine Version, kein vollständiger User-Agent.

---

```
shrinkr.acp.statistic.info.trackedData.osName
```

Betriebssystem-Name

---

```
shrinkr.acp.statistic.info.trackedData.osName.desc
```

Vereinfacht (z. B. Windows, Android), keine Version.

---

```
shrinkr.acp.statistic.info.trackedData.deviceType
```

Gerätetyp

---

```
shrinkr.acp.statistic.info.trackedData.deviceType.desc
```

Mobile, Desktop oder Tablet (geschätzt)

---

```
shrinkr.acp.statistic.info.trackedData.refererHash
```

Gehashte Referer-URL

---

```
shrinkr.acp.statistic.info.trackedData.refererHash.desc
```

Von welcher Seite kam der Besucher (SHA-256 Hash der Domain)

---

```
shrinkr.acp.statistic.info.trackedData.interactions
```

Interaktionen

---

```
shrinkr.acp.statistic.info.trackedData.interactions.desc
```

Welche Buttons wurden geklickt (Custom Buttons, Featured Links, Reactions)

---

```
shrinkr.acp.statistic.info.trackedData.notStored
```

Was wird NICHT gespeichert?

---

```
shrinkr.acp.statistic.info.trackedData.notStored.ip
```

Vollständige IP-Adressen (nur Hash)

---

```
shrinkr.acp.statistic.info.trackedData.notStored.userAgent
```

Vollständige User-Agent-Strings

---

```
shrinkr.acp.statistic.info.trackedData.notStored.browserVersion
```

Browser-Versionen oder OS-Versionen im Detail

---

```
shrinkr.acp.statistic.info.trackedData.notStored.country
```

Länder-Informationen (Geo-Lokalisierung)

---

```
shrinkr.acp.statistic.info.trackedData.notStored.personalData
```

Persönliche Daten (Name, E-Mail, etc.)

---

```
shrinkr.acp.statistic.info.trackedData.notStored.refererUrl
```

Vollständige Referer-URLs (nur Domain-Hash)

---

```
shrinkr.acp.statistic.info.availableStats
```

Verfügbare Statistiken

---

```
shrinkr.acp.statistic.info.availableStats.overview
```

Übersicht

---

```
shrinkr.acp.statistic.info.availableStats.visits
```

Besuche

---

```
shrinkr.acp.statistic.info.availableStats.visits.desc
```

Anzahl der Aufrufe pro Tag/Woche/Gesamt

---

```
shrinkr.acp.statistic.info.availableStats.uniqueVisitors
```

Eindeutige Besucher

---

```
shrinkr.acp.statistic.info.availableStats.uniqueVisitors.desc
```

Geschätzt basierend auf gehashten IP-Adressen

---

```
shrinkr.acp.statistic.info.availableStats.interactions
```

Interaktionen

---

```
shrinkr.acp.statistic.info.availableStats.interactions.desc
```

Anzahl der Button-Klicks, Reactions, etc.

---

```
shrinkr.acp.statistic.info.availableStats.conversionRate
```

Conversion Rate

---

```
shrinkr.acp.statistic.info.availableStats.conversionRate.desc
```

Prozentualer Anteil der Besucher, die interagieren

---

```
shrinkr.acp.statistic.info.availableStats.timeline
```

Zeitverlauf

---

```
shrinkr.acp.statistic.info.availableStats.timeline.desc
```

Chart mit Besuchen über Zeit

---

```
shrinkr.acp.statistic.info.availableStats.linkPerformance
```

Link-Performance

---

```
shrinkr.acp.statistic.info.availableStats.topLinks
```

Top Links

---

```
shrinkr.acp.statistic.info.availableStats.topLinks.desc
```

Welche Links werden am häufigsten besucht

---

```
shrinkr.acp.statistic.info.availableStats.interactionsPerLink
```

Interaktionen pro Link

---

```
shrinkr.acp.statistic.info.availableStats.interactionsPerLink.desc
```

Welche Links generieren die meisten Klicks auf Buttons

---

```
shrinkr.acp.statistic.info.availableStats.conversionRatePerLink
```

Conversion Rate pro Link

---

```
shrinkr.acp.statistic.info.availableStats.conversionRatePerLink.desc
```

Wie erfolgreich ist jeder Link

---

```
shrinkr.acp.statistic.info.availableStats.marketing
```

Marketing-Features

---

```
shrinkr.acp.statistic.info.availableStats.customButtons
```

Custom Buttons

---

```
shrinkr.acp.statistic.info.availableStats.customButtons.desc
```

Welche Custom Buttons werden am häufigsten geklickt

---

```
shrinkr.acp.statistic.info.availableStats.featuredLinks
```

Featured Links

---

```
shrinkr.acp.statistic.info.availableStats.featuredLinks.desc
```

Welche Featured Links funktionieren am besten

---

```
shrinkr.acp.statistic.info.availableStats.trafficSources
```

Traffic-Quellen

---

```
shrinkr.acp.statistic.info.availableStats.trafficSources.desc
```

Von welchen Domains kommen die meisten Besucher

---

```
shrinkr.acp.statistic.info.availableStats.technical
```

Technische Statistiken

---

```
shrinkr.acp.statistic.info.availableStats.hourlyDistribution
```

Stunden-Verteilung

---

```
shrinkr.acp.statistic.info.availableStats.hourlyDistribution.desc
```

Zu welchen Uhrzeiten gibt es die meisten Besuche

---

```
shrinkr.acp.statistic.info.availableStats.deviceTypes
```

Gerätetypen

---

```
shrinkr.acp.statistic.info.availableStats.deviceTypes.desc
```

Mobile vs Desktop vs Tablet

---

```
shrinkr.acp.statistic.info.privacy.anonymization
```

Anonymisierung

---

```
shrinkr.acp.statistic.info.privacy.ipAddresses
```

IP-Adressen

---

```
shrinkr.acp.statistic.info.privacy.ipAddresses.desc
```

Werden sofort nach Erfassung mit SHA-256 gehasht und können nicht rückverfolgt werden

---

```
shrinkr.acp.statistic.info.privacy.refererUrls
```

Referer-URLs

---

```
shrinkr.acp.statistic.info.privacy.refererUrls.desc
```

Werden gehasht, nur Domain wird für Statistiken verwendet

---

```
shrinkr.acp.statistic.info.privacy.userAgent
```

User-Agent

---

```
shrinkr.acp.statistic.info.privacy.userAgent.desc
```

Wird nicht gespeichert, nur Browser/OS-Name extrahiert

---

```
shrinkr.acp.statistic.info.privacy.retention
```

Datenretention

---

```
shrinkr.acp.statistic.info.privacy.retention.current
```

Aktuell: Keine automatische Löschung (experimentell)

---

```
shrinkr.acp.statistic.info.privacy.retention.planned
```

Geplant: Automatische Löschung nach 90 Tagen (wenn Feature final wird)

---

```
shrinkr.acp.statistic.info.privacy.optIn
```

Opt-In / Opt-Out

---

```
shrinkr.acp.statistic.info.privacy.optIn.current
```

Aktuell: Statistiken werden automatisch erfasst, wenn Tracking aktiviert ist

---

```
shrinkr.acp.statistic.info.privacy.optIn.note
```

Hinweis: Tracking kann in den Plugin-Einstellungen deaktiviert werden

---

```
shrinkr.acp.statistic.info.privacy.legal
```

Rechtliche Hinweise

---

```
shrinkr.acp.statistic.info.privacy.legal.text
```

Diese Statistiken dienen ausschließlich der Funktionsanalyse und Optimierung des Plugins. Es werden keine personenbezogenen Daten im Sinne der DSGVO gespeichert, da IP-Adressen gehasht und nicht rückverfolgbar sind.

---

```
shrinkr.acp.statistic.info.privacy.legal.important
```

Wichtig: Bei Nutzung in EU/EWR sollten Sie in Ihrer Datenschutzerklärung auf die Erfassung von Statistiken hinweisen, auch wenn diese anonymisiert sind.

---

```
shrinkr.acp.statistic.info.limitations
```

Bekannte Einschränkungen

---

```
shrinkr.acp.statistic.info.limitations.uniqueVisitors
```

Unique Visitors

---

```
shrinkr.acp.statistic.info.limitations.uniqueVisitors.desc
```

Geschätzt basierend auf IP-Hash, nicht 100% genau (gleiche IP = gleicher Besucher)

---

```
shrinkr.acp.statistic.info.limitations.deviceType
```

Gerätetyp

---

```
shrinkr.acp.statistic.info.limitations.deviceType.desc
```

Geschätzt basierend auf OS/Browser, nicht immer korrekt

---

```
shrinkr.acp.statistic.info.limitations.sessionDuration
```

Session-Dauer

---

```
shrinkr.acp.statistic.info.limitations.sessionDuration.desc
```

Wird nicht erfasst (für Weiterleitungsseiten irrelevant)

---

```
shrinkr.acp.statistic.info.limitations.returningVisitors
```

Returning Visitors

---

```
shrinkr.acp.statistic.info.limitations.returningVisitors.desc
```

Wird nicht zuverlässig erfasst

---

```
shrinkr.acp.statistic.info.limitations.countryStats
```

Länder-Statistiken

---

```
shrinkr.acp.statistic.info.limitations.countryStats.desc
```

Werden nicht erfasst (DSGVO-Konformität)

---

```
shrinkr.acp.statistic.info.performance
```

Performance

---

```
shrinkr.acp.statistic.info.performance.caching
```

Caching

---

```
shrinkr.acp.statistic.info.performance.caching.desc
```

Statistiken werden gecacht, um Datenbank-Last zu reduzieren

---

```
shrinkr.acp.statistic.info.performance.aggregation
```

Aggregation

---

```
shrinkr.acp.statistic.info.performance.aggregation.desc
```

Tägliche Aggregation über Cronjob für bessere Performance

---

```
shrinkr.acp.statistic.info.performance.limitations
```

Begrenzungen

---

```
shrinkr.acp.statistic.info.performance.limitations.desc
```

Listen sind auf Top 10-20 Einträge begrenzt, um Overload zu vermeiden

---

```
shrinkr.acp.statistic.info.changelog
```

Changelog

---

```
shrinkr.acp.statistic.info.changelog.text
```

Änderungen an den Statistiken werden im Changelog dokumentiert. Da die Funktionen experimentell sind, können sich Metriken, Berechnungen oder verfügbare Statistiken jederzeit ändern.

---

```
shrinkr.acp.statistic.weekday.monday
```

Montag

---

```
shrinkr.acp.statistic.weekday.tuesday
```

Dienstag

---

```
shrinkr.acp.statistic.weekday.wednesday
```

Mittwoch

---

```
shrinkr.acp.statistic.weekday.thursday
```

Donnerstag

---

```
shrinkr.acp.statistic.weekday.friday
```

Freitag

---

```
shrinkr.acp.statistic.weekday.saturday
```

Samstag

---

```
shrinkr.acp.statistic.weekday.sunday
```

Sonntag

---

```
shrinkr.acp.statistic.month.january
```

Januar

---

```
shrinkr.acp.statistic.month.february
```

Februar

---

```
shrinkr.acp.statistic.month.march
```

März

---

```
shrinkr.acp.statistic.month.april
```

April

---

```
shrinkr.acp.statistic.month.may
```

Mai

---

```
shrinkr.acp.statistic.month.june
```

Juni

---

```
shrinkr.acp.statistic.month.july
```

Juli

---

```
shrinkr.acp.statistic.month.august
```

August

---

```
shrinkr.acp.statistic.month.september
```

September

---

```
shrinkr.acp.statistic.month.october
```

Oktober

---

```
shrinkr.acp.statistic.month.november
```

November

---

```
shrinkr.acp.statistic.month.december
```

Dezember

---

```
shrinkr.acp.stat.noData
```

Keine Daten verfügbar

---

```
shrinkr.acp.stat.visits
```

Besuche

---

```
shrinkr.acp.stat.interactions
```

Interaktionen

---

```
shrinkr.acp.stat.interactionType.button.forward
```

Weiterleitung

---

```
shrinkr.acp.stat.interactionType.button.custom
```

Custom Button

---

```
shrinkr.acp.stat.interactionType.button.featured_link
```

Featured Link

---

```
shrinkr.acp.stat.interactionType.reaction
```

Reaktion

---

```
wcf.acp.option.shrinkr_tracking_enabled
```

Tracking aktivieren

---

```
wcf.acp.option.shrinkr_tracking_enabled.description
```

Aktiviert das Tracking von Besuchen und Interaktionen für Ihre Kurz-URLs. Deaktivieren Sie diese Option, um das Tracking vollständig zu deaktivieren.

---

```
wcf.acp.option.shrinkr_tracking_enabled.description
```

Aktiviert das Tracking von Besuchen und Interaktionen für deine Kurz-URLs. Deaktiviere diese Option, um das Tracking vollständig zu deaktivieren.

---

```
wcf.acp.option.shrinkr_statistic_retention_days
```

Aufbewahrungsdauer (Tage)

---

```
wcf.acp.option.shrinkr_statistic_retention_days.description
```

Rohdaten (einzelne Besuche und Interaktionen) werden nach dieser Anzahl von Tagen automatisch gelöscht. Aggregierte Statistiken bleiben dauerhaft erhalten. DSGVO-konform: IP-Adressen werden mit täglichem Salt gehasht.

---

```
wcf.acp.option.shrinkr_statistic_retention_days.description
```

Rohdaten (einzelne Besuche und Interaktionen) werden nach dieser Anzahl von Tagen automatisch gelöscht. Aggregierte Statistiken bleiben dauerhaft erhalten. DSGVO-konform: IP-Adressen werden mit täglichem Salt gehasht.

---

```
wcf.acp.group.option.admin.shrinkr.canViewStatistics
```

Kann Statistiken anzeigen

---

```
wcf.acp.group.option.admin.shrinkr.canViewStatistics.description
```

Erlaubt das Anzeigen von Statistiken im ACP.

---

```
wcf.acp.group.option.admin.shrinkr.canViewStatistics.description
```

Erlaubt das Anzeigen von Statistiken im ACP.

---

```
wcf.acp.group.option.admin.shrinkr.canManageStatistics
```

Kann Statistiken verwalten

---

```
wcf.acp.group.option.admin.shrinkr.canManageStatistics.description
```

Erlaubt das Löschen und Verwalten von Statistik-Daten (Demo-Daten generieren, Cleanup auslösen, etc.).

---

```
wcf.acp.group.option.admin.shrinkr.canManageStatistics.description
```

Erlaubt das Löschen und Verwalten von Statistik-Daten (Demo-Daten generieren, Cleanup auslösen, etc.).

---

```
shrinkr.acp.statistic.tab.overview
```

Übersicht

---

```
shrinkr.acp.statistic.tab.visitor
```

Besucher

---

```
shrinkr.acp.statistic.tab.click
```

Klicks & Buttons

---

```
shrinkr.acp.statistic.tab.reaction
```

Reactions

---

```
shrinkr.acp.statistic.tab.share
```

Teilen

---

```
shrinkr.acp.statistic.tab.special
```

Specials

---

```
shrinkr.acp.statistic.tab.voucher
```

Gutscheine

---

```
shrinkr.acp.statistic.tab.onetime
```

Einmal-Nachrichten

---

```
shrinkr.acp.statistic.tab.overview.description
```

Gesamtwerte für den gewählten Zeitraum und optional gefiltert nach Link.

---

```
shrinkr.acp.statistic.tab.visitor.description
```

Sessions pro Link: Gäste vs. angemeldete Nutzer und durchschnittliche Verweildauer.

---

```
shrinkr.acp.statistic.tab.click.description
```

Klicks auf Hauptlink, Custom Buttons und Featured Links, wie Ihre Besucher interagieren.

---

```
shrinkr.acp.statistic.tab.reaction.description
```

Reaktionen pro Link und Reaktionstyp (z. B. Like, Love).

---

```
shrinkr.acp.statistic.tab.share.description
```

Getrackte Teilen-Aktionen: Dialog geöffnet, HTML/Link geklickt, BBCode, soziale Kanäle.

---

```
shrinkr.acp.statistic.tab.special.description
```

Specials angezeigt (Seitenaufruf) vs. aktiv (Nutzer hat den Special-Bereich geklickt).

---

```
shrinkr.acp.statistic.tab.voucher.description
```

Aufrufe pro Gutschein (dauerhaft und einmalig) im gewählten Zeitraum.

---

```
shrinkr.acp.statistic.tab.onetime.description
```

Aufrufe pro Einmal-Nachricht (OTM) im gewählten Zeitraum.

---

```
shrinkr.acp.statistic.visitTrend.description
```

Aufrufe und Klicks pro Tag im gewählten Zeitraum.

---

```
shrinkr.acp.statistic.clickTrend
```

Klicks pro Tag

---

```
shrinkr.acp.statistic.reactionDistribution
```

Verteilung nach Reaktionstyp

---

```
shrinkr.acp.statistic.reactionDistribution.description
```

Anteil der Reaktionen pro Typ im gewählten Zeitraum.

---

```
shrinkr.acp.statistic.topLinks.description
```

Links mit den meisten Aufrufen und Klicks im gewählten Zeitraum.

---

```
shrinkr.acp.statistic.noTitle
```

Kein Titel

---

```
shrinkr.acp.statistic.customButtonFallback
```

Button #%d

---

```
shrinkr.acp.statistic.featuredLinkFallback
```

Featured Link #%d

---

```
shrinkr.acp.statistic.unknownReaction
```

Unbekannte Reaktion

---

```
shrinkr.acp.statistic.clickDetails
```

Button- und Link-Details anzeigen

---

```
shrinkr.acp.statistic.clickDetails.description
```

Klick-Statistik pro Link mit Hauptlink, Custom Buttons und Featured Links.

---

```
shrinkr.acp.statistic.reactionDetails
```

Reaktions-Details

---

```
shrinkr.acp.statistic.reactionDetails.description
```

Aufschlüsselung der Reaktionen pro Link und Reaktionstyp.

---

```
shrinkr.acp.statistic.noData
```

Keine Daten verfügbar

---

```
shrinkr.acp.statistic.visitorDistribution
```

Besucher-Verteilung

---

```
shrinkr.acp.statistic.visitorDistribution.description
```

Verteilung zwischen Gästen und registrierten Benutzern.

---

```
shrinkr.acp.statistic.visitorDetails
```

Besucher-Details

---

```
shrinkr.acp.statistic.visitorDetails.description
```

Detaillierte Auflistung aller Besucher-Sessions.

---

```
shrinkr.acp.statistic.shareTrend
```

Teilungen pro Tag

---

```
shrinkr.acp.statistic.shareTrend.description
```

Anzahl der Teilungen über den gewählten Zeitraum.

---

```
shrinkr.acp.statistic.shareDetails
```

Teilungs-Details

---

```
shrinkr.acp.statistic.shareDetails.description
```

Detaillierte Aufschlüsselung der Teilungs-Aktionen.

---

```
shrinkr.acp.statistic.views
```

Aufrufe

---

```
shrinkr.acp.statistic.voucherTrend
```

Gutschein-Aufrufe pro Tag

---

```
shrinkr.acp.statistic.voucherTrend.description
```

Anzahl der Gutschein-Seitenaufrufe über den gewählten Zeitraum.

---

```
shrinkr.acp.statistic.voucherDetails
```

Gutschein-Details

---

```
shrinkr.acp.statistic.voucherDetails.description
```

Aufrufe pro Gutschein (dauerhaft und einmalig).

---

```
shrinkr.acp.statistic.voucherType
```

Typ

---

```
shrinkr.acp.statistic.voucherType.permanent
```

Dauerhaft

---

```
shrinkr.acp.statistic.voucherType.once
```

Einmalig

---

```
shrinkr.acp.statistic.onetimeTrend
```

OTM-Aufrufe pro Tag

---

```
shrinkr.acp.statistic.onetimeTrend.description
```

Anzahl der Einmal-Nachricht-Aufrufe über den gewählten Zeitraum.

---

```
shrinkr.acp.statistic.onetimeDetails
```

Einmal-Nachricht-Details

---

```
shrinkr.acp.statistic.onetimeDetails.description
```

Aufrufe pro Einmal-Nachricht.

---

```
shrinkr.acp.statistic.onetimePreview
```

Nachricht (Auszug)

---

```
shrinkr.acp.statistic.filter
```

Filter

---

```
shrinkr.acp.statistic.filter.apply
```

Filter anwenden

---

```
shrinkr.acp.statistic.startDate
```

Startdatum

---

```
shrinkr.acp.statistic.endDate
```

Enddatum

---

```
shrinkr.acp.statistic.linkFilter
```

Link-Filter

---

```
shrinkr.acp.statistic.linkHashOrId
```

Link (Hash oder ID)

---

```
shrinkr.acp.statistic.linkHashOrId.placeholder
```

z. B. DEMO-1 oder 12345

---

```
shrinkr.acp.statistic.linkHashOrId.description
```

Optional: Nur Statistiken für einen Link. Hash (z. B. DEMO-1) oder Link-ID eingeben. Leer = alle Links.

---

```
shrinkr.acp.statistic.linkHashOrId.description
```

Optional: Nur Statistiken für einen Link. Gib Hash (z. B. DEMO-1) oder Link-ID ein. Leer = alle Links.

---

```
shrinkr.acp.statistic.linkSearch.resultsCount
```

%d Treffer

---

```
shrinkr.acp.statistic.metric
```

Metrik

---

```
shrinkr.acp.statistic.value
```

Wert

---

```
shrinkr.acp.statistic.totalViews
```

Gesamtaufrufe

---

```
shrinkr.acp.statistic.totalClicks
```

Gesamtklicks

---

```
shrinkr.acp.statistic.totalReactions
```

Gesamtreactions

---

```
shrinkr.acp.statistic.totalShares
```

Gesamtshares

---

```
shrinkr.acp.statistic.conversionRate
```

Klickrate

---

```
shrinkr.acp.statistic.topLinks
```

Top Links

---

```
shrinkr.acp.statistic.performance
```

Performance-Übersicht

---

```
shrinkr.acp.statistic.performance.description
```

Durchschnittliche Performance und beste/schlechteste Links im gewählten Zeitraum.

---

```
shrinkr.acp.statistic.avgConversionRate
```

Durchschnittliche Klickrate

---

```
shrinkr.acp.statistic.totalLinks
```

Anzahl Links

---

```
shrinkr.acp.statistic.bestPerformer
```

Bester Link

---

```
shrinkr.acp.statistic.linkID
```

Link-ID

---

```
shrinkr.acp.statistic.duration.seconds
```

Sek

---

```
shrinkr.acp.statistic.duration.minutes
```

Min

---

```
shrinkr.acp.statistic.duration.hours
```

Std

---

```
shrinkr.acp.statistic.guests
```

Gäste

---

```
shrinkr.acp.statistic.users
```

Benutzer

---

```
shrinkr.acp.statistic.total
```

Gesamt

---

```
shrinkr.acp.statistic.avgTimeOnPage
```

Durchschnittliche Verweildauer

---

```
shrinkr.acp.statistic.avgTimeOnPage
```

Durchschnittliche Verweildauer

---

```
shrinkr.acp.statistic.mainLinkClicks
```

Hauptlink-Klicks

---

```
shrinkr.acp.statistic.customButtonClicks
```

Custom-Button-Klicks

---

```
shrinkr.acp.statistic.featuredLinkClicks
```

Featured-Link-Klicks

---

```
shrinkr.acp.statistic.reactionType
```

Reaction-Typ

---

```
shrinkr.acp.statistic.count
```

Anzahl

---

```
shrinkr.acp.statistic.dialogOpened
```

Dialog geöffnet

---

```
shrinkr.acp.statistic.htmlClick
```

HTML-Link

---

```
shrinkr.acp.statistic.directClick
```

Direktlink

---

```
shrinkr.acp.statistic.bbcodeClick
```

BB-Code

---

```
shrinkr.acp.statistic.socialClicks
```

Social-Share

---

```
shrinkr.acp.statistic.special
```

Special

---

```
shrinkr.acp.statistic.displayed
```

Angezeigt

---

```
shrinkr.acp.statistic.active
```

Aktiv

---

```
shrinkr.acp.statistic.link
```

Link

---

```
shrinkr.acp.statistic.views
```

Aufrufe

---

```
shrinkr.acp.statistic.clicks
```

Klicks
