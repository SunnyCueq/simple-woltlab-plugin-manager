```
wcf.acp.ad.location.category.de.sunnyc.wsc.shrinkr
```

Shr1nkr

---

```
wcf.acp.ad.location.de.sunnyc.wsc.shrinkr.beforeRedirectContainer
```

Before redirect container

---

```
wcf.acp.ad.location.de.sunnyc.wsc.shrinkr.afterRedirectContainer
```

After redirect container

---

```
wcf.acp.option.category.shrinkr
```

Shr1nkr

---

```
wcf.acp.option.category.shrinkr.general
```

General

---

```
wcf.acp.option.category.shrinkr.redirect
```

Redirect

---

```
wcf.acp.option.category.shrinkr.target
```

Destination URL

---

```
wcf.acp.option.category.shrinkr.hash
```

Hash Configuration

---

```
wcf.acp.option.category.shrinkr.interaction
```

Interaction

---

```
wcf.acp.option.category.shrinkr.interaction.description
```

Configure what visitors can do on the redirect page: reactions (e.g. thumbs up), share button, and description texts. All options only apply when Shr1nkr is enabled under General.

---

```
wcf.acp.option.category.shrinkr.design
```

Appearance

---

```
wcf.acp.option.category.shrinkr.design.description
```

Configure the redirect page: forward button, icon before the title, special effects (e.g. snow), and QR codes. Options only apply when Shr1nkr is enabled under General.

---

```
wcf.acp.option.category.shrinkr.advanced
```

Expert

---

```
wcf.acp.option.category.shrinkr.advanced.description
```

For experienced administrators only. Unlocks advanced options (e.g. demo data, external URL). <strong>Warning:</strong> Incorrect settings can break Shr1nkr. Enable only if you know what you are doing.

---

```
wcf.acp.option.shrinkr_active
```

Activate the Shr1nkr

---

```
wcf.acp.option.shrinkr_active.description
```

Turn on Shr1nkr here. Only when this option is enabled can you create short URLs and use the "Shr1nkr" menu in the ACP. Without it, all other Shr1nkr options have no effect.

---

```
wcf.acp.option.shrinkr_counter_active
```

Activate the visit counter for short URLs

---

```
wcf.acp.option.shrinkr_counter_active.description
```

Shows how many times a short URL has been accessed. The counter appears in the <a href="{link controller='ShrinkrLinkList'}{/link}">list of your short URLs</a> (menu: Shr1nkr → Links) and can be reset there.

---

```
wcf.acp.option.shrinkr_forwarding_must_confirmed
```

Forwarding must be confirmed

---

```
wcf.acp.option.shrinkr_forwarding_must_confirmed.description
```

On the redirect page, a button must first be clicked before redirecting to the target URL. This increases security and prevents automatic redirects. If "Delayed forwarding" is activated, the button can only be pressed after the waiting time has elapsed.

---

```
wcf.acp.option.shrinkr_time_until_forwarding
```

Delayed forwarding (in seconds)

---

```
wcf.acp.option.shrinkr_time_until_forwarding.description
```

Visitors see the redirect page for this many seconds before being sent to the destination URL. Example: 5 = 5 seconds wait. Use 0 for immediate redirect. If "Forwarding on button click" is enabled, the button only becomes clickable after this time.

---

```
wcf.acp.option.shrinkr_expertmode_active
```

Activate the expert mode

---

```
wcf.acp.option.shrinkr_expertmode_active.description
```

For experienced administrators only. When enabled, additional options appear (e.g. Install demo data, External URL). Most users do not need expert mode. <strong>Warning:</strong> Incorrect settings can break Shr1nkr. Enable only if you know the consequences.

---

```
wcf.acp.option.shrinkr_dashboard_enabled
```

Show ACP dashboard box

---

```
wcf.acp.option.shrinkr_dashboard_enabled.description
```

Choose whether a Shr1nkr box appears on the ACP home (dashboard). The box shows a short summary (e.g. number of short URLs, clicks), the version, and a support link. Useful for a quick overview without opening the "Shr1nkr" menu.

---

```
wcf.acp.option.shrinkr_normal_page_mode
```

Show redirect page with header and footer

---

```
wcf.acp.option.shrinkr_normal_page_mode.description
```

By default, visitors only see the plain redirect page (without your community header and footer). When enabled, header, footer, and all side boxes are shown. Useful if the redirect page should look like a normal community page.

---

```
wcf.acp.option.shrinkr_hash_length
```

Hash length

---

```
wcf.acp.option.shrinkr_hash_length.description
```

The hash is the short code in each short URL (e.g. "abc1" in /r/abc1/). Set how many characters it has. Longer = more possible short URLs; shorter = shorter addresses. Recommended: 4–8 characters. Changes apply only to newly created short URLs.

---

```
wcf.acp.option.shrinkr_hash_prefix
```

Hash prefix

---

```
wcf.acp.option.shrinkr_hash_prefix.description
```

Optional: Fixed text before each hash. Build readable short URLs, e.g. prefix "link-" + hash "abc" gives <kbd>/r/link-abc/</kbd>. Leave empty = no prefix. Prefix and hash together may not exceed 64 characters. Applies only to newly created short URLs.

---

```
wcf.acp.option.shrinkr_only_https
```

Allow HTTPS destination URLs only (https://)

---

```
wcf.acp.option.shrinkr_only_https.description
```

Only allows target URLs that start with <kbd>https://</kbd>. URLs with <kbd>http://</kbd> are rejected. This increases security by using encrypted connections.

---

```
wcf.acp.option.shrinkr_deactivate_forwarding_chains
```

Deactivate redirect chains

---

```
wcf.acp.option.shrinkr_deactivate_forwarding_chains.description
```

Prevents target URLs that themselves redirect to other URLs (redirect chains). Example: URL A redirects to URL B, which in turn redirects to URL C. Such chains are blocked by default as they can cause problems.

---

```
wcf.acp.option.shrinkr_pattern
```

Hash RegEx pattern

---

```
wcf.acp.option.shrinkr_pattern.description
```

Allows you to define a custom pattern (RegEx pattern) for hash codes. Default: <kbd>[0-9a-z\-]{1,64}</kbd> (numbers, lowercase letters and hyphens, 1-64 characters). <strong>Experts only:</strong> Incorrect patterns can prevent URLs from being created.

---

```
wcf.acp.option.shrinkr_external_url
```

External URL

---

```
wcf.acp.option.shrinkr_external_url.description
```

Overwrites the base URL for all generated short URLs. Example: With <kbd>https://short.example.com</kbd>, URLs like <kbd>https://short.example.com/r/test/</kbd> are generated instead of <kbd>https://example.com/urls/r/test/</kbd>. <strong>Requires:</strong> Additional web server configuration (e.g. subdomain redirect). This option is only available in <a href="{link controller='Option'}#category_shrinkr.expertmode{/link}">Expert Mode</a>.

---

```
wcf.acp.option.shrinkr_install_demo_data
```

Install demo data

---

```
wcf.acp.option.shrinkr_install_demo_data.description
```

Installs demo URLs (DEMO-1 to DEMO-7) with example discounts, specials, featured links and custom buttons for testing purposes. <strong>Caution on production systems:</strong> When deactivating, only the demo data installed by this option is removed; your own data remains unchanged.

---

```
wcf.acp.option.shrinkr_remove_shrinkr_prefix
```

Remove /shrinkr/ prefix from URLs

---

```
wcf.acp.option.shrinkr_remove_shrinkr_prefix.description
```

Removes the <kbd>/shrinkr/</kbd> prefix from generated short URLs. Instead of <kbd>/shrinkr/r/test/</kbd>, <kbd>/shrinkr/v/test/</kbd> or <kbd>/shrinkr/m/test/</kbd>, <kbd>/r/test/</kbd>, <kbd>/v/test/</kbd> or <kbd>/m/test/</kbd> will be generated (links, vouchers, one-time messages). Requires manual webserver configuration. <strong>Important:</strong> Link rewriting must be enabled under General.

---

```
wcf.acp.option.shrinkr_remove_shrinkr_prefix.description
```

Removes the <kbd>/shrinkr/</kbd> prefix from generated short URLs. Instead of <kbd>/shrinkr/r/test/</kbd>, <kbd>/shrinkr/v/test/</kbd> or <kbd>/shrinkr/m/test/</kbd>, <kbd>/r/test/</kbd>, <kbd>/v/test/</kbd> or <kbd>/m/test/</kbd> will be generated (links, vouchers, one-time messages). Requires manual webserver configuration. <strong>Important:</strong> Link rewriting must be enabled under General.

---

```
wcf.acp.option.shrinkr_enable_reactions
```

Enable reactions

---

```
wcf.acp.option.shrinkr_enable_reactions.description
```

Visitors can react on the redirect page (e.g. thumbs up). See how well a short URL is received. Reactions only show when this option is enabled. Enable "Enable guest reactions" separately for guest reactions.

---

```
wcf.acp.option.shrinkr_enable_guest_reactions
```

Enable guest reactions

---

```
wcf.acp.option.shrinkr_enable_guest_reactions.description
```

Guests can then react on the redirect page. Reactions are stored. When the guest logs in later, their reactions are assigned to their account. Requirement: "Enable reactions" must be enabled.

---

```
wcf.acp.option.shrinkr_enable_share_button
```

Show share button

---

```
wcf.acp.option.shrinkr_enable_share_button.description
```

A button to share the short URL (e.g. on social networks) appears on the redirect page. Visitors can easily recommend the page.

---

```
wcf.acp.option.shrinkr_enable_descriptions
```

Enable descriptions

---

```
wcf.acp.option.shrinkr_enable_descriptions.description
```

Enables the display of description texts on the redirect page. One text is chosen at random from the entries you created under Shr1nkr → Descriptions. This setting turns the display on or off globally; individual descriptions can be set active or inactive there.

---

```
wcf.acp.option.shrinkr_password_session_storage
```

Store password in session

---

```
wcf.acp.option.shrinkr_password_session_storage.description
```

For password-protected short URLs, visitors normally must enter the password on every visit. When enabled, one entry per browser session is enough; access is stored until the browser is closed. Useful for visitors opening several protected short URLs in a row.

---

```
wcf.acp.option.shrinkr_rate_limit_enabled
```

Limit password attempts

---

```
wcf.acp.option.shrinkr_rate_limit_enabled.description
```

Protects password-protected short URLs from many failed attempts. Per short URL and per visitor IP: after a set number of wrong attempts (see next options), access is blocked for a time window. Afterwards attempts are counted again.

---

```
wcf.acp.option.shrinkr_rate_limit_attempts
```

Max. allowed failed attempts

---

```
wcf.acp.option.shrinkr_rate_limit_attempts.description
```

How many wrong password attempts before access is temporarily blocked? Example: 5 = block after 5 failed attempts. Only applies when "Limit password attempts" is enabled.

---

```
wcf.acp.option.shrinkr_rate_limit_window
```

Lockout window (seconds)

---

```
wcf.acp.option.shrinkr_rate_limit_window.description
```

After too many failed attempts, access is blocked for this many seconds. Example: 900 = 15 minutes. Then attempts count again from zero. Only applies when "Limit password attempts" is enabled.

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button
```

Enable 3D button style

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button.label
```

Override forward button

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button.description
```

The forward button gets a 3D style and uses the promo badge colours (discount area) on the redirect page. Without this option, the standard button is shown.

---

```
wcf.acp.option.shrinkr_enable_custom_forward_button.preview
```

Preview:

---

```
wcf.acp.option.shrinkr_title_icon
```

Title Icon

---

```
wcf.acp.option.shrinkr_title_icon.description
```

Optional: A small icon before the main heading on the redirect page. Choose an icon from the Font Awesome library. Empty = no icon.

---

```
wcf.acp.option.shrinkr_enable_theme_effects
```

Enable special effects

---

```
wcf.acp.option.shrinkr_enable_theme_effects.description
```

Enables theme-based effects (e.g. autumn leaves, snow, ghosts). Effects only appear on the redirect page when a special is linked to a theme (manage themes under Shr1nkr → Themes; choose the effect when editing a special).

---

```
wcf.acp.option.shrinkr_enable_qr_code
```

Enable QR code generation

---

```
wcf.acp.option.shrinkr_enable_qr_code.description
```

You can generate and show a QR code for each short URL. Visitors can scan it with their phone and go straight to the redirect page. QR codes appear in the short URL list (menu: Shr1nkr → Links) and can be viewed and downloaded there.

---

```
wcf.acp.group.option.category.user.shrinkr
```

Shr1nkr

---

```
wcf.acp.group.option.category.mod.shrinkr
```

Shr1nkr

---

```
wcf.acp.group.option.category.admin.shrinkr
```

Shr1nkr Administration

---

```
wcf.acp.group.option.admin.shrinkr.canManageLinks
```

Can manage links

---

```
wcf.acp.group.option.admin.shrinkr.canManageDiscounts
```

Can manage discounts

---

```
wcf.acp.group.option.admin.shrinkr.canManageDescriptions
```

Can manage descriptions

---

```
wcf.acp.group.option.admin.shrinkr.canManageFeaturedLinks
```

Can manage featured links

---

```
wcf.acp.group.option.admin.shrinkr.canManageCustomButtons
```

Can manage custom buttons

---

```
wcf.acp.group.option.admin.shrinkr.canManageSpecials
```

Can manage specials

---

```
wcf.acp.group.option.admin.shrinkr.canManageThemes
```

Can manage themes

---

```
wcf.acp.group.option.admin.shrinkr.canManageButtonClicks
```

Can manage button clicks

---

```
shrinkr.acp.option.reload
```

Load Options

---

```
shrinkr.acp.menu.badge.expert
```

EXPERT

---

```
shrinkr.acp.menu.badge.demo
```

DEMO

---

```
shrinkr.acp.menu.badge.expertDemo
```

EXPERT, DEMO

---

```
shrinkr.acp.menu.link.menu
```

Shr1nkr

---

```
shrinkr.acp.menu.link.link.list
```

Links

---

```
shrinkr.acp.menu.link.link.add
```

Add Link

---

```
shrinkr.acp.menu.link.discount.list
```

Discounts

---

```
shrinkr.acp.menu.link.discount.add
```

Add discount

---

```
shrinkr.acp.menu.link.discount.edit
```

Edit Discount

---

```
shrinkr.acp.menu.link.voucher.permanent.list
```

Vouchers

---

```
shrinkr.acp.menu.link.voucher.permanent.add
```

Add voucher (permanent)

---

```
shrinkr.acp.menu.link.voucher.permanent.edit
```

Edit voucher (permanent)

---

```
shrinkr.acp.menu.link.voucher.permanent.password
```

Password protected vouchers (permanent)

---

```
shrinkr.acp.menu.link.voucher.once.list
```

One-time

---

```
shrinkr.acp.menu.link.voucher.once.add
```

Add voucher (one-time)

---

```
shrinkr.acp.menu.link.voucher.once.edit
```

Edit voucher (one-time)

---

```
shrinkr.acp.menu.link.voucher.once.password
```

Password protected vouchers (one-time)

---

```
shrinkr.acp.menu.link.onetimemessage.list
```

One-Time Messages

---

```
shrinkr.acp.menu.link.onetimemessage.add
```

Add one-time message

---

```
shrinkr.acp.menu.link.onetimemessage.edit
```

Edit one-time message

---

```
shrinkr.acp.menu.link.onetimemessage.password
```

Password protected one-time messages

---

```
shrinkr.acp.menu.link.description.list
```

Descriptions

---

```
shrinkr.acp.menu.link.description.add
```

Add description

---

```
shrinkr.acp.menu.link.description.edit
```

Edit Description

---

```
shrinkr.acp.menu.link.featuredLink.list
```

Featured Links

---

```
shrinkr.acp.menu.link.featuredLink.add
```

Add featured link

---

```
shrinkr.acp.menu.link.featuredLink.edit
```

Edit featured link

---

```
shrinkr.acp.menu.link.customButton.list
```

Custom Buttons

---

```
shrinkr.acp.menu.link.customButton.add
```

Add custom button

---

```
shrinkr.acp.menu.link.customButton.edit
```

Edit custom button

---

```
shrinkr.acp.menu.link.special.list
```

Specials

---

```
shrinkr.acp.menu.link.special.add
```

Add Special

---

```
shrinkr.acp.menu.link.special.edit
```

Edit Special

---

```
shrinkr.acp.menu.link.link.password
```

Password Protected Links

---

```
shrinkr.acp.menu.link.link.password.filter
```

Only password protected links

---

```
shrinkr.acp.menu.link.theme.list
```

Themes

---

```
shrinkr.acp.menu.link.theme.add
```

Add theme

---

```
shrinkr.acp.menu.link.theme.edit
```

Edit Theme

---

```
shrinkr.acp.menu.link.statistic
```

Statistics

---

```
shrinkr.acp.menu.link.statistic.info
```

Info

---

```
shrinkr.acp.menu.link.settings
```

Settings

---

```
shrinkr.voucher.code
```

Voucher code

---

```
shrinkr.voucher.code.description
```

The discount code displayed on the redirect page (e.g. SAVE20).

---

```
shrinkr.voucher.title
```

Title

---

```
shrinkr.voucher.title.description
```

Short title or label for this voucher.

---

```
shrinkr.voucher.token
```

Token

---

```
shrinkr.voucher.token.description
```

Unique short code for the voucher short URL (e.g. /v/SAVE20). Leave empty = auto-generated.

---

```
shrinkr.voucher.discountValue.description
```

Display text for the discount (e.g. "20% off" or "€10 voucher").

---

```
shrinkr.voucher.maxViews
```

Max. views (0 = unlimited)

---

```
shrinkr.voucher.maxViews.description
```

Maximum number of voucher URL views. 0 = unlimited.

---

```
shrinkr.voucher.viewCount
```

Views

---

```
shrinkr.voucher.password.description
```

This voucher is password protected. Please enter the password to view the voucher.

---

```
shrinkr.otm.pageTitle
```

One-Time Message

---

```
shrinkr.otm.messageText
```

Message text

---

```
shrinkr.otm.messageText.description
```

The text shown when the one-time message short URL (/m/…) is visited for the first time. After that the URL is invalid.

---

```
shrinkr.otm.createdTime
```

Created

---

```
shrinkr.otm.expiryTime
```

Expiry time

---

```
shrinkr.otm.expiryTime.description
```

Optional: After expiry the one-time message is no longer shown.

---

```
shrinkr.otm.password
```

Password

---

```
shrinkr.otm.password.description
```

Optional: Only visible with password.

---

```
shrinkr.otm.password.pageDescription
```

This one-time message is password protected. Please enter the password to read the content.

---

```
shrinkr.acp.form.enable
```

Enable

---

```
shrinkr.acp.form.sortOrder
```

Sort order

---

```
shrinkr.acp.voucher.permanent.add.description
```

Create a permanent voucher here. It has a fixed short URL (e.g. /v/SAVE20/). Visitors can open the URL as often as they like; the voucher page with code and discount appears each time. Evaluation: Shr1nkr → Statistics, vouchers section.

---

```
shrinkr.acp.voucher.permanent.edit.description
```

Change title, voucher code, discount text and other settings. The short URL (/v/…) stays the same.

---

```
shrinkr.acp.voucher.permanent.list.description
```

Overview of all permanent vouchers. Each has a fixed short URL (e.g. /v/SAVE20/) and can be opened any number of times. Create them here; the voucher page appears when someone opens the short URL. Evaluate redemptions under Shr1nkr → Statistics.

---

```
shrinkr.acp.voucher.permanent.list.password
```

Password protected vouchers (permanent)

---

```
shrinkr.acp.voucher.permanent.list.password.description
```

Overview of all permanent vouchers that require a password. They are created under “Vouchers”; this view shows only password-protected entries.

---

```
shrinkr.acp.voucher.once.add.description
```

Create a voucher that can be redeemed only once. After the first visit to the short URL it becomes invalid. Useful for one-off campaigns or personal vouchers.

---

```
shrinkr.acp.voucher.once.edit.description
```

Change title, voucher code and settings. If the short URL was already visited, it remains invalid.

---

```
shrinkr.acp.voucher.once.list.description
```

One-time vouchers are reachable via a short URL (/v/TOKEN/) and can be redeemed only once. After the first visit the URL is invalid. They are created here; evaluation is in Statistics under “Vouchers”.

---

```
shrinkr.acp.voucher.once.list.password
```

Password protected vouchers (one-time)

---

```
shrinkr.acp.voucher.once.list.password.description
```

Overview of all one-time vouchers with password protection. Created under “Vouchers” (one-time); this view shows only password-protected entries.

---

```
shrinkr.acp.otm.add.description
```

Create a one-time message. The content is shown only once when the associated URL is accessed.

---

```
shrinkr.acp.otm.edit.description
```

Edit the one-time message. The content is shown only once when the associated URL is accessed.

---

```
shrinkr.acp.otm.list.description
```

One-time messages appear when the short URL (/m/TOKEN/) is opened for the first time, and only once. Ideal for personal notes or one-off content. Created here; evaluation in Statistics under “One-time messages”.

---

```
shrinkr.acp.otm.list.password
```

Password protected one-time messages

---

```
shrinkr.acp.otm.list.password.description
```

Overview of all one-time messages with password protection. Created under “One-time messages”; this view shows only password-protected entries.

---

```
shrinkr.acp.dashboard.box.title
```

Shr1nkr

---

```
shrinkr.acp.dashboard.version
```

Version

---

```
shrinkr.acp.dashboard.totalLinks
```

Short URLs total

---

```
shrinkr.acp.dashboard.totalClicks
```

Clicks (30 days)

---

```
shrinkr.acp.dashboard.totalVisitors
```

Visitors (30 days)

---

```
shrinkr.acp.dashboard.activeSpecials
```

Active Specials

---

```
shrinkr.acp.dashboard.featuredLinks
```

Featured Links

---

```
shrinkr.acp.dashboard.vouchersTotal
```

Vouchers total

---

```
shrinkr.acp.dashboard.oneTimeMessagesTotal
```

One-time messages total

---

```
shrinkr.acp.dashboard.viewStatistics
```

Statistics

---

```
shrinkr.acp.dashboard.manageLinks
```

Manage short URLs

---

```
shrinkr.acp.dashboard.support
```

Support

---

```
shrinkr.acp.dashboard.supportUrl
```

https://sunnyc.de

---

```
shrinkr.acp.dashboard.copyright
```

Shr1nkr by sunnyc.de

---

```
wcf.shrinkr.url
```

Short URL

---

```
wcf.shrinkr.copyUrl
```

Copy short URL

---

```
wcf.shrinkr.copyUrl.success
```

URL was copied successfully

---

```
wcf.shrinkr.copyUrl.error
```

An error occurred during copying

---

```
wcf.shrinkr.urlGoal
```

Destination URL

---

```
wcf.shrinkr.urlGoal.description
```

The full target URL to redirect to (e.g. https://example.com).

---

```
wcf.shrinkr.notActive
```

Shr1nkr has not been activated.

---

```
wcf.shrinkr.yes
```

Yes

---

```
wcf.shrinkr.no
```

No

---

```
wcf.shrinkr.url.hash
```

Hash

---

```
wcf.shrinkr.url.hash.description
```

The hash is the short code in the short URL (e.g. "abc1" in /r/abc1/). Leave empty for automatic generation. It is shown on the redirect page and in the short URL list.

---

```
wcf.shrinkr.url.counter
```

Visit Counter

---

```
wcf.shrinkr.link.password
```

Password

---

```
wcf.shrinkr.link.password.description
```

Optional: Visitors must enter this password on the redirect page before they are sent to the destination URL.

---

```
wcf.shrinkr.link.passwordProtected
```

Password Protected

---

```
wcf.shrinkr.password.wrong
```

Wrong password

---

```
wcf.shrinkr.password.enter
```

Enter password

---

```
wcf.shrinkr.password.description
```

Please enter the password to access this short URL.

---

```
wcf.shrinkr.password.confirm
```

Confirm

---

```
wcf.shrinkr.password.unlock
```

Unlock content

---

```
wcf.shrinkr.qrCode
```

QR Code

---

```
wcf.shrinkr.qrCode.download
```

Download

---

```
wcf.shrinkr.qrCode.zoom
```

Zoom in

---

```
wcf.shrinkr.resetCounter
```

Reset Visit Counter

---

```
wcf.shrinkr.copyright
```

<a href="https://sunnyc.de" rel="nofollow"{if EXTERNAL_LINK_TARGET_BLANK} target="_blank"{/if}><strong>Shr1nkr</strong> (by <strong>sunnyc.de</strong>)</a>

---

```
shrinkr.acp.rewrite.title
```

Rewrite Rules for Shr1nkr

---

```
shrinkr.acp.rewrite.generate
```

Generate Rewrite Rules

---

```
shrinkr.acp.rewrite.description
```

Removes the /shrinkr/ prefix from generated short URLs. Instead of /shrinkr/r/test/, /shrinkr/v/test/ or /shrinkr/m/test/ then /r/test/, /v/test/ or /m/test/ are generated (links, vouchers, one-time messages). Requires manual webserver configuration. Important: URL rewriting must be enabled under General.

---

```
shrinkr.acp.rewrite.info.title
```

Important

---

```
shrinkr.acp.rewrite.info.description
```

The rule for /r/ must be at the VERY TOP of the .htaccess file (before the urls/ rule). URL rewriting must be enabled under General → Search Engine Optimization (SEO).

---

```
shrinkr.acp.url.removeUrlsPrefix.info.title
```

Remove /shrinkr/ Prefix

---

```
shrinkr.acp.url.removeUrlsPrefix.info.description
```

You have enabled the option to remove the /shrinkr/ prefix from URLs. For links like <strong>https://example.com/r/abc123</strong> to work, rewrite rules must be added to your webserver configuration.

---

```
shrinkr.acp.url.removeUrlsPrefix.info.htaccess.generate
```

Show Rewrite Rules

---

```
shrinkr.acp.url.removeUrlsPrefix.info.htaccess.generate.description
```

Click the button to display the appropriate rewrite rules for your webserver.

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink
```

Featured Links

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink.description
```

Restrict the list to links that have a featured link or that do not.

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink.yes
```

With featured link or multiple

---

```
shrinkr.acp.url.list.filter.hasFeaturedLink.no
```

Without Featured Link

---

```
shrinkr.acp.url.list.filter.hasCustomButton
```

Custom Buttons

---

```
shrinkr.acp.url.list.filter.hasCustomButton.description
```

Restrict the list to links with or without a custom button.

---

```
shrinkr.acp.url.list.filter.hasCustomButton.yes
```

With custom button or multiple

---

```
shrinkr.acp.url.list.filter.hasCustomButton.no
```

Without Custom Button

---

```
shrinkr.acp.url.list
```

Manage short URLs

---

```
shrinkr.acp.url.list.description
```

Overview of all your short URLs. Filter by hash, destination URL or title; manage and edit them here. Create new short URLs via "Shorten URL"; assign featured links, custom buttons and specials when editing a short URL.

---

```
shrinkr.acp.url.list.password
```

Manage Password Protected Short URLs

---

```
shrinkr.acp.url.list.password.description
```

Only short URLs that have a password. Visitors must enter it on the redirect page to reach the destination. Create and manage short URLs under Shr1nkr → Links; this view shows only password-protected entries.

---

```
shrinkr.acp.url.add
```

Shorten URL

---

```
shrinkr.acp.url.edit
```

Edit short URL

---

```
shrinkr.acp.url.delete.confirmMessage
```

Do you really want to delete this short URL? All collected data will be deleted.

---

```
shrinkr.acp.url.success.theShortUrlIs
```

The short URL is:

---

```
shrinkr.acp.url.hash.error.tooLong
```

The hash may not be longer than 64 characters.

---

```
shrinkr.acp.url.hash.error.notMatchesPattern
```

The hash may contain only certain characters specified by the administrator.

---

```
shrinkr.acp.url.hash.error.alreadyExists
```

The hash is already in use.

---

```
shrinkr.acp.url.url.error.tooLong
```

The target URL may not be longer than 255 characters.

---

```
shrinkr.acp.url.url.error.noUrl
```

The specified URL is invalid.

---

```
shrinkr.acp.url.url.error.httpsRequired
```

The URL must use HTTPS (https://).

---

```
shrinkr.acp.url.url.error.isOnBlacklist
```

The specified URL is on the blacklist.

---

```
shrinkr.acp.url.url.error.forwardingChain
```

Redirect chains are not allowed.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.title
```

Advanced URL generation enabled

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.description
```

URLs are generated without <kbd>/shrinkr/</kbd> prefix (e.g. <kbd>/r/test/</kbd>, <kbd>/v/test/</kbd>, <kbd>/m/test/</kbd> instead of <kbd>/shrinkr/r/test/</kbd> etc.). For this to work, the web server configuration (Apache <kbd>.htaccess</kbd> or nginx <kbd>nginx.conf</kbd>) must be manually adjusted. Click the "Generate Rewrite Rules" button in the top right to display the required rules. This info will automatically disappear once the rules are correctly inserted into the web server configuration.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.description
```

URLs are generated without <kbd>/shrinkr/</kbd> prefix (e.g. <kbd>/r/test/</kbd>, <kbd>/v/test/</kbd>, <kbd>/m/test/</kbd> instead of <kbd>/shrinkr/r/test/</kbd> etc.). For this to work, the web server configuration (Apache <kbd>.htaccess</kbd> or nginx <kbd>nginx.conf</kbd>) must be manually adjusted. Click the "Generate Rewrite Rules" button in the top right to display the required rules. This info will automatically disappear once the rules are correctly inserted into the web server configuration.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.title
```

Instructions: Adjust web server configuration

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.step1
```

Go to: ACP → General → Search Engine Optimization (SEO) → Generate Rewrite Rules

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.step2
```

Copy the generated standard rules from WoltLab

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.step3
```

Insert the rules for <kbd>/r/</kbd>, <kbd>/v/</kbd> and <kbd>/m/</kbd> at the VERY TOP (before the <kbd>shrinkr/</kbd> rule)

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.alreadySet
```

The rules for <kbd>/r/</kbd>, <kbd>/v/</kbd> and <kbd>/m/</kbd> are already present in the .htaccess file.

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.apache
```

Apache (.htaccess)

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.nginx
```

nginx (nginx.conf)

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.generate
```

Generate Rewrite Rules

---

```
shrinkr.acp.url.removeShrinkrPrefix.info.htaccess.generate.description
```

Click the "Generate Rewrite Rules" button in the top right to display the required rules for Apache (.htaccess) and nginx (nginx.conf) and insert them into your web server configuration.

---

```
shrinkr.acp.url.rewrite.nginx.instructions
```

These rules must be inserted into the server block of your nginx.conf

---

```
shrinkr.acp.url.rewrite.nginx.important
```

IMPORTANT: The /r/ rule must be placed BEFORE the standard WoltLab rules.

---

```
shrinkr.acp.url.rewrite.nginx.note
```

Note: Ensure that the standard WoltLab rules
for /shrinkr/ are also present in your nginx.conf.

---

```
shrinkr.redirect.headline
```

Redirect page

---

```
shrinkr.redirect.text.confirm
```

You are to be redirected to the following destination address: <kbd>{$redirectUrl}</kbd>

---

```
shrinkr.redirect.text.timer
```

Forwarding is done automatically after the timer expires.

---

```
shrinkr.redirect.forwardingIn
```

Forwarding in

---

```
shrinkr.redirect.second
```

second

---

```
shrinkr.redirect.seconds
```

seconds

---

```
shrinkr.redirect.confirm
```

View recommendation

---

```
shrinkr.redirect.forwardingNow
```

Forwarding now

---

```
shrinkr.featured.texts.recommended
```

Also recommended

---

```
shrinkr.featured.texts.discount
```

Take advantage of exclusive discounts from these providers as well

---

```
wcf.shrinkr.design
```

Appearance

---

```
wcf.shrinkr.featured
```

Recommended for this

---

```
wcf.shrinkr.featuredLinks
```

Recommended links

---

```
wcf.shrinkr.featuredLinks.manage.description
```

Recommended links are displayed on the redirect page. You can manage them via the corresponding menu items.

---

```
wcf.shrinkr.customButtons
```

Custom Buttons

---

```
wcf.shrinkr.customButtons.manage.description
```

Custom buttons are displayed on the redirect page. You can manage them via the corresponding menu items.

---

```
wcf.shrinkr.hosts
```

Host names

---

```
wcf.shrinkr.hosts.description
```

Enter one or more host names (e.g. amazon.com, ebay.com, walmart.com)

---

```
wcf.shrinkr.special
```

Special

---

```
wcf.shrinkr.special.identifier
```

Special identifier

---

```
wcf.shrinkr.special.identifier.description
```

The special is available via this value after "&special="

---

```
wcf.shrinkr.special.manage
```

Manage specials

---

```
wcf.shrinkr.special.edit
```

Edit special

---

```
wcf.shrinkr.special.add
```

Add special

---

```
wcf.shrinkr.special.manage.description
```

Manage temporary specials for this URL

---

```
wcf.shrinkr.special.noItems
```

No specials found.

---

```
wcf.shrinkr.special.noItems.howToAdd.title
```

How do I add specials?

---

```
wcf.shrinkr.special.noItems.howToAdd.text
```

Specials can be created in two ways:

---

```
wcf.shrinkr.special.noItems.howToAdd.viaUrlList
```

In the short URL list (Shr1nkr → Links) via the \"+\" button in the Special column

---

```
wcf.shrinkr.special.noItems.howToAdd.viaLinkEdit
```

Via the link edit page in the navigation menu

---

```
wcf.shrinkr.special.noItems.dependencies.title
```

What are specials dependent on?

---

```
wcf.shrinkr.special.noItems.dependencies.text
```

Specials require an existing URL. Each special is assigned to a specific URL and is displayed on the corresponding redirect page.

---

```
wcf.shrinkr.special.noItems.impact.title
```

What depends on specials?

---

```
wcf.shrinkr.special.noItems.impact.text
```

Specials are displayed on the redirect page and can be combined with themes, discount codes, and countdown timers. Featured links can optionally be linked to specials.

---

```
wcf.shrinkr.special.saveFirst
```

Please save the URL first before you can manage specials.

---

```
wcf.shrinkr.special.deleteConfirm
```

Do you really want to delete this special?

---

```
wcf.shrinkr.special.noSpecials
```

No specials available yet

---

```
wcf.shrinkr.special.theme
```

Theme

---

```
wcf.shrinkr.special.theme.description
```

Select a theme to use predefined colors

---

```
wcf.shrinkr.special.title
```

Title

---

```
wcf.shrinkr.special.title.description
```

Title of the special (only for the overview page)

---

```
wcf.shrinkr.special.discount
```

Discount

---

```
wcf.shrinkr.special.discount.description
```

Discount displayed on the redirect page (e.g. "30%")

---

```
wcf.shrinkr.special.codes.description
```

Discount codes for the special (overrides normal codes)

---

```
wcf.shrinkr.special.additionalText.description
```

Additional HTML text for the special (overrides normal additional text)

---

```
wcf.shrinkr.special.startTime
```

Start time

---

```
wcf.shrinkr.special.startTime.description
```

Start time of the special (date and time)

---

```
wcf.shrinkr.special.endTime
```

End time

---

```
wcf.shrinkr.special.endTime.description
```

End time of the special (date and time)

---

```
wcf.shrinkr.special.isActive
```

Active

---

```
wcf.shrinkr.special.isActive.description
```

The special is activated. The countdown continues even if deactivated.

---

```
wcf.shrinkr.special.isActive.yes
```

Active

---

```
wcf.shrinkr.special.isActive.no
```

Inactive

---

```
wcf.shrinkr.special.urlHash
```

Short URL

---

```
wcf.shrinkr.special.shortUrl
```

Short URL / hash

---

```
wcf.shrinkr.special.shortUrl.placeholder
```

e.g. #42 or mylink

---

```
wcf.shrinkr.special.timeRange
```

Schedule

---

```
wcf.shrinkr.special.timeRange.start
```

Start

---

```
wcf.shrinkr.special.timeRange.end
```

End

---

```
wcf.shrinkr.special.timeRange.notConfigured
```

No schedule configured

---

```
wcf.shrinkr.special.urlList
```

Open short URLs

---

```
wcf.shrinkr.special.refresh
```

Reload list

---

```
wcf.shrinkr.special.status
```

Status

---

```
wcf.shrinkr.special.status.active
```

Active

---

```
wcf.shrinkr.special.status.expired
```

Expired

---

```
wcf.shrinkr.special.status.scheduled
```

Scheduled

---

```
wcf.shrinkr.special.status.inactive
```

Inactive

---

```
wcf.shrinkr.special.editUrl
```

Edit short URL

---

```
wcf.shrinkr.additionalText
```

Additional text

---

```
wcf.shrinkr.additionalText.description
```

HTML-formatted text displayed below the discount codes

---

```
wcf.shrinkr.codes
```

Discount codes

---

```
wcf.shrinkr.codes.description
```

One or more discount codes (Default: SHRINKR). Additional codes can be added.

---

```
wcf.shrinkr.codes.single
```

Discount Code

---

```
wcf.shrinkr.codes.multiple
```

Discount Codes

---

```
wcf.shrinkr.code.clickToCopy
```

Click to copy

---

```
wcf.shrinkr.copySpecialData
```

Copy special data

---

```
wcf.shrinkr.discount
```

Discount

---

```
wcf.shrinkr.discount.description
```

Enter the discount to be displayed on the redirect page.

---

```
wcf.shrinkr.discount.placeholder
```

e.g. 30%, $10 or Black Friday

---

```
wcf.shrinkr.discount.favicon.description
```

The favicon is automatically loaded from the target URL. If you upload a favicon manually, it takes priority.

---

```
wcf.shrinkr.discount.special
```

Special template

---

```
wcf.shrinkr.discount.specialIdentifier
```

Identifier

---

```
wcf.shrinkr.discount.countdown.active
```

Active

---

```
wcf.shrinkr.discount.countdown.expired
```

Expired

---

```
wcf.shrinkr.discount.countdown.notConfigured
```

Not configured

---

```
wcf.shrinkr.colors.primary
```

Primary Colors

---

```
wcf.shrinkr.colors.secondary
```

Secondary Colors

---

```
wcf.shrinkr.primaryColor
```

Background Color

---

```
wcf.shrinkr.primaryColor.description
```

Main color for backgrounds and large areas

---

```
wcf.shrinkr.secondaryColor
```

Accent Color

---

```
wcf.shrinkr.secondaryColor.description
```

Color for accents, buttons and highlights

---

```
wcf.shrinkr.primaryTextColor
```

Text Color (Primary)

---

```
wcf.shrinkr.primaryTextColor.description
```

Text color on background color

---

```
wcf.shrinkr.secondaryTextColor
```

Text Color (Secondary)

---

```
wcf.shrinkr.secondaryTextColor.description
```

Text color on accent color

---

```
wcf.shrinkr.theme
```

Theme

---

```
wcf.shrinkr.theme.identifier
```

Identifier

---

```
wcf.shrinkr.theme.identifier.description
```

Unique key for the theme (e.g. halloween, christmas). Used in the URL.

---

```
wcf.shrinkr.theme.identifier.error.notUnique
```

This identifier is already in use. Please choose another one.

---

```
wcf.shrinkr.theme.title
```

Title

---

```
wcf.shrinkr.theme.title.description
```

Display name of the theme (e.g. Halloween, Christmas).

---

```
wcf.shrinkr.theme.effect
```

Special Effect

---

```
wcf.shrinkr.theme.effect.description
```

Defines which visual effect is executed for specials using this theme.

---

```
wcf.shrinkr.theme.effect.none
```

No Effect

---

```
wcf.shrinkr.theme.effect.autumnLeaves
```

Autumn Leaves

---

```
wcf.shrinkr.theme.effect.snow
```

Snowfall

---

```
wcf.shrinkr.theme.effect.ghosts
```

Halloween Ghosts

---

```
wcf.shrinkr.theme.colors
```

Colors

---

```
wcf.shrinkr.theme.color.primary
```

Primary Color

---

```
wcf.shrinkr.theme.color.primaryText
```

Primary Color Text

---

```
wcf.shrinkr.theme.color.secondary
```

Secondary Color

---

```
wcf.shrinkr.theme.color.secondaryText
```

Secondary Color Text

---

```
wcf.shrinkr.theme.primaryColor.description
```

Main color of the theme (e.g. for background)

---

```
wcf.shrinkr.theme.secondaryColor.description
```

Secondary color of the theme (e.g. for accents)

---

```
wcf.shrinkr.theme.primaryTextColor.description
```

Text color on the primary color

---

```
wcf.shrinkr.theme.secondaryTextColor.description
```

Text color on the secondary color

---

```
wcf.shrinkr.theme.isActive
```

Active

---

```
wcf.shrinkr.theme.isActive.yes
```

Active

---

```
wcf.shrinkr.theme.isActive.no
```

Inactive

---

```
wcf.shrinkr.theme.status
```

Status

---

```
wcf.shrinkr.theme.isActive.description
```

Only active themes can be selected in specials.

---

```
wcf.shrinkr.theme.sortOrder
```

Sort order

---

```
wcf.shrinkr.theme.sortOrder.description
```

Order in the theme selection (lower values first)

---

```
wcf.shrinkr.theme.css.edit
```

Edit CSS

---

```
wcf.shrinkr.theme.css.edit.description
```

Edit the CSS file of this theme directly in the ACP. Changes will be written to the CSS file and the database.

---

```
wcf.shrinkr.theme.css.edit.warning
```

Warning: Only edit this CSS file if you know what you are doing. Changes to predefined themes may affect the design.

---

```
wcf.shrinkr.theme.css.content
```

CSS Content

---

```
wcf.shrinkr.theme.css.content.description
```

The complete CSS code for this theme.

---

```
wcf.shrinkr.form.tab.basic
```

Basic settings

---

```
wcf.shrinkr.form.tab.period
```

Period

---

```
wcf.shrinkr.form.tab.additionalText
```

Additional Text

---

```
wcf.shrinkr.form.tab.css
```

Edit CSS

---

```
wcf.shrinkr.form.section.basic
```

Basic Settings

---

```
wcf.shrinkr.form.section.basic.description
```

Identifier, title, effect and status of the theme

---

```
wcf.shrinkr.form.section.basic.description.description
```

Title and description text

---

```
wcf.shrinkr.form.section.colors
```

Colors for Promo Badge

---

```
wcf.shrinkr.form.section.colors.description
```

Primary colors (left side) and secondary colors (right side) of the promo badge

---

```
wcf.shrinkr.form.section.settings
```

Settings

---

```
wcf.shrinkr.form.section.settings.description
```

Status and visibility

---

```
wcf.shrinkr.countdownStart
```

Countdown Start

---

```
wcf.shrinkr.countdownStart.description
```

Start time of the countdown promotion (date and time)

---

```
wcf.shrinkr.countdownEnd
```

Countdown

---

```
wcf.shrinkr.countdownEnd.description
```

End time of the countdown promotion (date and time)

---

```
wcf.shrinkr.countdown.expired
```

EXPIRED

---

```
wcf.shrinkr.countdown.textColor
```

Countdown text color

---

```
wcf.shrinkr.countdown.textColor.description
```

Text color for the countdown timer

---

```
wcf.shrinkr.countdown.backgroundColor
```

Countdown background color

---

```
wcf.shrinkr.countdown.backgroundColor.description
```

Background color for the countdown timer

---

```
wcf.shrinkr.badge.textColor
```

Badge text color

---

```
wcf.shrinkr.badge.textColor.description
```

Text color for the badge

---

```
wcf.shrinkr.badge.backgroundColor
```

Badge background color

---

```
wcf.shrinkr.badge.backgroundColor.description
```

Background color for the badge

---

```
wcf.shrinkr.url.urlTitle
```

Title of the destination URL

---

```
wcf.shrinkr.url.urlTitle.description
```

Title displayed on the redirect page

---

```
wcf.shrinkr.url.linkTitle.placeholder
```

Recommended Links

---

```
wcf.shrinkr.likeableUrl.notification
```

Someone reacted to your short URL

---

```
wcf.shrinkr.likeableUrl.notification.title
```

Reaction on short URL

---

```
wcf.shrinkr.copyCode
```

Copy discount code

---

```
wcf.shrinkr.copyCode.success
```

Discount code was successfully copied.

---

```
wcf.shrinkr.copyCode.error
```

An error occurred while copying the code.

---

```
wcf.shrinkr.description.title
```

Title

---

```
wcf.shrinkr.description.title.description
```

A short title for this description (visible in ACP only)

---

```
wcf.shrinkr.description.descriptionText
```

Description text

---

```
wcf.shrinkr.description.descriptionText.description
```

Description text for the redirect page (HTML & Smarty allowed).<br><br><strong>Variables (click to insert):</strong><br><button type="button" class="button small descriptionVariable" data-variable="{literal}{$url}{/literal}">{icon size=16 name='plus'} <span>Target URL</span></button> <button type="button" class="button small descriptionVariable" data-variable="{literal}{$extractedTitle}{/literal}">{icon size=16 name='plus'} <span>Page Title</span></button> <button type="button" class="button small descriptionVariable" data-variable="{literal}{$discount->discountValue}{/literal}">{icon size=16 name='plus'} <span>Discount Title</span></button><br><br><strong>Placeholder:</strong><br><button type="button" class="button small descriptionVariable" data-variable="[[FAV_URL_LINK]]">{icon size=16 name='plus'} <span>Link with Favicon</span></button>

---

```
wcf.shrinkr.description.isActive
```

Active

---

```
wcf.shrinkr.description.preview
```

Preview

---

```
wcf.shrinkr.description.isActive.description
```

Only active descriptions will be randomly displayed on the redirect page.

---

```
wcf.shrinkr.description.isActive.yes
```

Active

---

```
wcf.shrinkr.description.isActive.no
```

Inactive

---

```
wcf.shrinkr.description.status
```

Status

---

```
wcf.shrinkr.featuredLink.add
```

Add featured link

---

```
wcf.shrinkr.featuredLink.addAnother
```

Add another featured link

---

```
wcf.shrinkr.featuredLink.manage
```

Manage featured links

---

```
wcf.shrinkr.featuredLink.manage.description
```

Manage recommended links for this URL

---

```
wcf.shrinkr.featuredLink.noItems
```

No featured links found. Featured links can only be added via URL editing.

---

```
wcf.shrinkr.featuredLink.goToUrls
```

Go to short URLs

---

```
wcf.shrinkr.featuredLink.section
```

Featured Links

---

```
wcf.shrinkr.featuredLink.section.description
```

Recommended links displayed on the redirect page

---

```
wcf.shrinkr.featuredLink.noItemsInUrl
```

No featured links have been added for this URL yet.

---

```
wcf.shrinkr.featuredLink.saveFirst
```

Please save the URL first before you can manage featured links.

---

```
wcf.shrinkr.featuredLink.deleteConfirm
```

Do you really want to delete this featured link?

---

```
wcf.shrinkr.featuredLink.noLinks
```

No featured links available yet

---

```
wcf.shrinkr.featuredLink.url
```

URL

---

```
wcf.shrinkr.featuredLink.url.description
```

The full URL of the recommended link (e.g. https://amazon.com/product)

---

```
wcf.shrinkr.featuredLink.title.description
```

Title of the recommended link displayed on the redirect page

---

```
wcf.shrinkr.featuredLink.error.titleOrUrlRequired
```

Please enter a title or URL.

---

```
wcf.shrinkr.featuredLink.sortOrder
```

Sort order

---

```
wcf.shrinkr.featuredLink.sortOrder.description
```

Display order (lower values are displayed first)

---

```
wcf.shrinkr.featuredLink.urlInfo
```

Short URL

---

```
wcf.shrinkr.featuredLink.urlInfo.description
```

Click the short code (hash) to open the short URL in the frontend.

---

```
wcf.shrinkr.featuredLink.backToUrl
```

Back to short URL

---

```
wcf.shrinkr.featuredLink.forHash
```

Destination

---

```
wcf.shrinkr.featuredLink.editUrl
```

Edit short URL

---

```
shrinkr.acp.featuredLink.list.description
```

Overview of all featured links. They appear on the redirect page when you assign them to a short URL. Create and assign: Shr1nkr → Links → Edit short URL → "Featured Links" section. Here you manage the global entries.

---

```
shrinkr.acp.special.list.description
```

Overview of all specials (e.g. campaigns, discounts, seasonal events). Assign a special to a short URL; then the redirect page is shown in the chosen theme with the special text. Set themes under Shr1nkr → Themes.

---

```
shrinkr.acp.discount.list.description
```

Overview of all discounts. Set discount value, voucher code and validity here. Promo badges appear automatically on the redirect page (before the forward click) and inform visitors about current offers. Evaluation: Shr1nkr → Statistics.

---

```
shrinkr.acp.description.list.description
```

Short extra texts for the redirect page. One text is chosen at random from the list. Use them for campaigns, hints or trust copy without changing the destination page. Create here; assign to short URLs via Shr1nkr → Links.

---

```
shrinkr.acp.theme.list.description
```

Themes set colours and effects for the redirect page. Choose a theme when creating or editing a special (Shr1nkr → Specials). Without a special, no theme is applied; the default redirect page is shown.

---

```
wcf.shrinkr.customButton.targetUrl
```

Target URL

---

```
wcf.shrinkr.customButton.targetUrl.description
```

The URL the button redirects to

---

```
wcf.shrinkr.customButton.title
```

Title

---

```
wcf.shrinkr.customButton.title.description
```

Title of the button displayed on the redirect page

---

```
wcf.shrinkr.customButton.error.titleOrUrlRequired
```

Please enter a title or target URL.

---

```
wcf.shrinkr.customButton.sortOrder
```

Sort order

---

```
wcf.shrinkr.customButton.sortOrder.description
```

Display order (lower values are displayed first)

---

```
wcf.shrinkr.customButton.urlInfo
```

Short URL

---

```
wcf.shrinkr.customButton.urlInfo.description
```

Click the short code (hash) to open the short URL in the frontend.

---

```
wcf.shrinkr.customButton.backToUrl
```

Back to short URL

---

```
wcf.shrinkr.customButton.forHash
```

Destination

---

```
wcf.shrinkr.customButton.editUrl
```

Edit short URL

---

```
wcf.shrinkr.customButton.noItems
```

No custom buttons found.

---

```
wcf.shrinkr.customButton.noItemsInUrl
```

No custom buttons have been created for this short URL yet.

---

```
wcf.shrinkr.customButton.goToUrls
```

Go to short URL list

---

```
wcf.shrinkr.customButton.section
```

Custom Buttons

---

```
wcf.shrinkr.customButton.section.description
```

Manage custom buttons displayed directly under the forward button.

---

```
wcf.shrinkr.customButton.add
```

Add Custom Button

---

```
wcf.shrinkr.customButton.addAnother
```

Add Another Custom Button

---

```
shrinkr.acp.customButton.list.description
```

Overview of all custom buttons. They appear on the redirect page directly under the forward button when you assign them to a short URL. Create and assign: Shr1nkr → Links → Edit short URL → "Custom Buttons" section. Here you manage the global entries.

---

```
wcf.shrinkr.url.ogImage
```

Open Graph Image

---

```
wcf.shrinkr.url.ogImage.description
```

Image displayed when sharing the link on social media (Facebook, X, etc.). Recommended: At least 1200x630 pixels.

---

```
wcf.shrinkr.url.password
```

Password

---

```
wcf.shrinkr.url.password.description
```

Optional: Protects the short URL with a password. Visitors must enter it before being redirected to the destination URL.

---

```
wcf.shrinkr.url.passwordProtected
```

Password Protected

---

```
wcf.shrinkr.password.dialog.title
```

Password Required

---

```
wcf.shrinkr.password.label
```

Password

---

```
wcf.shrinkr.password.description
```

Please enter the password to access the short URL.

---

```
wcf.shrinkr.password.error.empty
```

Please enter a password.

---

```
wcf.shrinkr.password.error.wrong
```

The entered password is incorrect.

---

```
wcf.shrinkr.password.error.rateLimitExceeded
```

Too many failed attempts. Please try again later.

---

```
wcf.shrinkr.password.error.invalidLink
```

Invalid short URL.

---

```
wcf.shrinkr.password.error.notRequired
```

No password is required for this short URL.

---

```
wcf.shrinkr.password.success
```

Password correct. You will be redirected...

---

```
shrinkr.redirect.password.title
```

Password Required

---

```
shrinkr.redirect.password.label
```

Password

---

```
shrinkr.redirect.password.description
```

Please enter the password to access the short URL.

---

```
shrinkr.redirect.password.error.empty
```

Please enter a password.

---

```
shrinkr.redirect.password.error.invalid
```

The entered password is invalid.

---

```
shrinkr.redirect.password.error.general
```

An error occurred. Please try again.

---

```
wcf.shrinkr.geolite2.database_provider.default
```

Default (Default)

---

```
wcf.shrinkr.geolite2.database_provider.maxmind
```

MaxMind (Own Account)

---

```
wcf.shrinkr.geolite2.database_provider.local
```

Local Database

---

```
wcf.shrinkr.global.all
```

All

---

```
wcf.shrinkr.reaction.thankYou
```

Thank you for your feedback.

---

```
wcf.shrinkr.reaction.thankYou
```

Thank you for your feedback.

---

```
wcf.acp.menu.link.shrinkr.statistic
```

Statistics

---

```
shrinkr.acp.statistic.title
```

Statistics

---

```
shrinkr.acp.statistic.comingSoon.title
```

Coming Soon

---

```
shrinkr.acp.statistic.comingSoon.description
```

The statistics feature will be available in a future version.

---

```
shrinkr.acp.statistic.description
```

Overview of clicks, visitors, and interactions for your short URLs. You can filter by link (hash or ID); data refers to URLs created in the link list and to vouchers and one-time messages.

---

```
shrinkr.acp.statistic.description
```

Overview of clicks, visitors, and interactions for your short URLs. You can filter by link (hash or ID); data refers to URLs created in the link list and to vouchers and one-time messages.

---

```
shrinkr.acp.statistic.systemOverview
```

System Overview

---

```
shrinkr.acp.statistic.systemOverview.description
```

Inventory of all features in the system: How many links, featured links, custom buttons, specials, and reactions are available?

---

```
shrinkr.acp.statistic.totalLinks
```

Total Links

---

```
shrinkr.acp.statistic.activeLinks
```

Active Links

---

```
shrinkr.acp.statistic.totalFeaturedLinks
```

Total Featured Links

---

```
shrinkr.acp.statistic.totalCustomButtons
```

Total Custom Buttons

---

```
shrinkr.acp.statistic.totalSpecials
```

Total Specials/Themes

---

```
shrinkr.acp.statistic.linksWithSpecials
```

Links with Specials

---

```
shrinkr.acp.statistic.linksWithCustomButtons
```

Links with Custom Buttons

---

```
shrinkr.acp.statistic.linksWithFeaturedLinks
```

Links with Featured Links

---

```
shrinkr.acp.statistic.specialsByTheme
```

Specials by Theme

---

```
shrinkr.acp.statistic.reactionTypes
```

Reaction Types

---

```
shrinkr.acp.statistic.reactionTypes.description
```

The following reaction types were used in the last 30 days:

---

```
shrinkr.acp.statistic.count
```

Count

---

```
shrinkr.acp.statistic.hash
```

Hash

---

```
shrinkr.acp.statistic.overview
```

Overview

---

```
shrinkr.acp.statistic.overview.description
```

Key metrics at a glance: How many visitors have reached your links today, this week, and in total?

---

```
shrinkr.acp.statistic.today
```

Today

---

```
shrinkr.acp.statistic.today.description
```

Visits since midnight today.

---

```
shrinkr.acp.statistic.yesterday
```

Yesterday

---

```
shrinkr.acp.statistic.thisWeek
```

This Week

---

```
shrinkr.acp.statistic.thisWeek.description
```

Visits since Monday of this week.

---

```
shrinkr.acp.statistic.thisMonth
```

This Month

---

```
shrinkr.acp.statistic.total
```

Total

---

```
shrinkr.acp.statistic.total.description
```

All visits since tracking was enabled.

---

```
shrinkr.acp.statistic.interactionsToday
```

Interactions Today

---

```
shrinkr.acp.statistic.interactionsToday.description
```

Button clicks and reactions since midnight today.

---

```
shrinkr.acp.statistic.visitTrend
```

Visit Trend

---

```
shrinkr.acp.statistic.topLinks
```

Top Links

---

```
shrinkr.acp.statistic.visits
```

Visits

---

```
shrinkr.acp.statistic.visitors
```

Visitors

---

```
shrinkr.acp.statistic.visitors.description
```

Detailed information about your visitors: Which browsers and operating systems are used? From which countries do your visitors come? Which devices are used?

---

```
shrinkr.acp.statistic.hourlyDistribution
```

Hourly Distribution

---

```
shrinkr.acp.statistic.hourlyDistribution.description
```

Shows visitor distribution across 24 hours for the last 7 days.

---

```
shrinkr.acp.statistic.hourlyTooltipSuffix
```



---

```
shrinkr.acp.statistic.specialTrend
```

Special Trend

---

```
shrinkr.acp.statistic.specialTrend.description
```

Shows the development of special views over the selected period.

---

```
shrinkr.acp.statistic.specialDetails
```

Special Details

---

```
shrinkr.acp.statistic.specialDetails.description
```

Detailed list of all special events by link and special type.

---

```
shrinkr.acp.statistic.interactionTypes
```

Interaction Types

---

```
shrinkr.acp.statistic.filter
```

Filter

---

```
shrinkr.acp.statistic.filter.apply
```

Apply Filter

---

```
shrinkr.acp.statistic.period
```

Period

---

```
shrinkr.acp.statistic.uniqueVisitors
```

Unique Visitors

---

```
shrinkr.acp.statistic.uniqueVisitors.description
```

Different people who have visited your links. If the same person visits a link multiple times, they are only counted once.

---

```
shrinkr.acp.statistic.uniqueVisitorsToday
```

Unique Visitors (Today)

---

```
shrinkr.acp.statistic.uniqueVisitorsTotal
```

Unique Visitors (Total)

---

```
shrinkr.acp.statistic.avgClicksPerLink
```

Avg Clicks per Link

---

```
shrinkr.acp.statistic.avgClicksPerLink.description
```

Average number of button clicks on each of your links.

---

```
shrinkr.acp.statistic.conversionRate
```

Click Rate

---

```
shrinkr.acp.statistic.conversionRate.description
```

The percentage of visitors who clicked on a button. Example: 25% means every fourth visitor clicked a button.

---

```
shrinkr.acp.statistic.mostActiveHour
```

Most Active Hour

---

```
shrinkr.acp.statistic.mostActiveHour.description
```

The time of day when your links are visited most frequently.

---

```
shrinkr.acp.statistic.mostActiveWeekday
```

Most Active Weekday

---

```
shrinkr.acp.statistic.mostActiveWeekday.description
```

The day of the week when your links are visited most frequently.

---

```
shrinkr.acp.statistic.linkPerformance
```

Link Performance

---

```
shrinkr.acp.statistic.linkPerformance.description
```

Detailed statistics for all your short URLs

---

```
shrinkr.acp.statistic.linkName
```

Link Name

---

```
shrinkr.acp.statistic.lastActivity
```

Last Activity

---

```
shrinkr.acp.statistic.noLinks
```

No links available

---

```
shrinkr.acp.statistic.interactionDetails
```

Interaction Details

---

```
shrinkr.acp.statistic.interactionDetails.description
```

Detailed breakdown of all interaction types

---

```
shrinkr.acp.statistic.interactionType
```

Interaction Type

---

```
shrinkr.acp.statistic.total
```

Total

---

```
shrinkr.acp.statistic.unique
```

Unique

---

```
shrinkr.acp.statistic.avgPerDay
```

Avg per Day

---

```
shrinkr.acp.statistic.trend
```

Trend

---

```
shrinkr.acp.statistic.noInteractions
```

No interactions available

---

```
shrinkr.acp.statistic.timeAnalysis
```

Time Analysis

---

```
shrinkr.acp.statistic.weekdayDistribution
```

Weekday Distribution

---

```
shrinkr.acp.statistic.weekdayDistribution.description
```

Visitor distribution across weekdays for the last 30 days

---

```
shrinkr.acp.statistic.monthlyOverview
```

Monthly Overview

---

```
shrinkr.acp.statistic.monthlyOverview.description
```

Visitor development over the last 12 months

---

```
shrinkr.acp.statistic.peakTimes
```

Peak Times

---

```
shrinkr.acp.statistic.peakTimes.description
```

The 5 hours with the most visits

---

```
shrinkr.acp.statistic.hour
```

Hour

---

```
shrinkr.acp.statistic.trafficSources
```

Traffic Sources

---

```
shrinkr.acp.statistic.trafficSources.description
```

From which websites do your visitors come? Here you can see the most common referral sites (e.g. Google, Facebook, other websites).

---

```
shrinkr.acp.statistic.referer
```

Source

---

```
shrinkr.acp.statistic.referer.description
```

The website from which a visitor came to your link (e.g. Google, Facebook, a forum).

---

```
shrinkr.acp.statistic.directTraffic
```

Direct Visit

---

```
shrinkr.acp.statistic.directTraffic.description
```

The visitor entered the link directly or opened it from a bookmark.

---

```
shrinkr.acp.statistic.noReferers
```

No referral data available yet

---

```
shrinkr.acp.statistic.browserOS
```

Browser & Devices

---

```
shrinkr.acp.statistic.browserOS.description
```

Which browsers and operating systems do your visitors use?

---

```
shrinkr.acp.statistic.browser
```

Browser

---

```
shrinkr.acp.statistic.os
```

Operating System

---

```
shrinkr.acp.statistic.version
```

Version

---

```
shrinkr.acp.statistic.percentage
```

Share

---

```
shrinkr.acp.statistic.noBrowserData
```

No browser data available

---

```
shrinkr.acp.statistic.noOSData
```

No operating system data available

---

```
shrinkr.acp.statistic.countries
```

Country Distribution

---

```
shrinkr.acp.statistic.countries.description
```

From which countries do your visitors come?

---

```
shrinkr.acp.statistic.country
```

Country

---

```
shrinkr.acp.statistic.noCountryData
```

No country data available

---

```
shrinkr.acp.statistic.customButtons
```

Custom Button Performance

---

```
shrinkr.acp.statistic.customButtons.description
```

Which custom buttons are clicked most often?

---

```
shrinkr.acp.statistic.buttonText
```

Button Text

---

```
shrinkr.acp.statistic.clicks
```

Clicks

---

```
shrinkr.acp.statistic.uniqueClicks
```

Unique Clicks

---

```
shrinkr.acp.statistic.noCustomButtons
```

No custom buttons available

---

```
shrinkr.acp.statistic.featuredLinks
```

Featured Link Performance

---

```
shrinkr.acp.statistic.featuredLinks.description
```

Which featured links are clicked most often?

---

```
shrinkr.acp.statistic.noFeaturedLinks
```

No featured links available

---

```
shrinkr.acp.statistic.specials
```

Special Effects / Themes

---

```
shrinkr.acp.statistic.specials.description
```

Which seasonal effects and themes were displayed and how often?

---

```
shrinkr.acp.statistic.theme
```

Theme/Effect

---

```
shrinkr.acp.statistic.views
```

Views

---

```
shrinkr.acp.statistic.uniqueVisitors
```

Unique Visitors

---

```
shrinkr.acp.statistic.lastSeen
```

Last Seen

---

```
shrinkr.acp.statistic.noSpecials
```

No specials available

---

```
shrinkr.acp.statistic.reactions
```

Reaction Performance

---

```
shrinkr.acp.statistic.reactions.description
```

Which reactions are used most frequently?

---

```
shrinkr.acp.statistic.reactionType
```

Reaction Type

---

```
shrinkr.acp.statistic.usages
```

Usages

---

```
shrinkr.acp.statistic.uniqueUsers
```

Unique Users

---

```
shrinkr.acp.statistic.noReactions
```

No reactions available

---

```
shrinkr.acp.statistic.linkButtonInteractions
```

Button Clicks per Link

---

```
shrinkr.acp.statistic.linkButtonInteractions.description
```

Detailed overview: Which buttons were clicked on which links?

---

```
shrinkr.acp.statistic.noLinkButtonInteractions
```

No button interactions available

---

```
shrinkr.acp.statistic.buttonType
```

Button Type

---

```
shrinkr.acp.statistic.devices
```

Device Types

---

```
shrinkr.acp.statistic.devices.description
```

Which device types do your visitors use?

---

```
shrinkr.acp.statistic.mobile
```

Mobile

---

```
shrinkr.acp.statistic.desktop
```

Desktop

---

```
shrinkr.acp.statistic.tablet
```

Tablet

---

```
shrinkr.acp.statistic.deviceType
```

Device Type

---

```
shrinkr.acp.statistic.visitorTypes
```

Visitor Types

---

```
shrinkr.acp.statistic.visitorTypes.description
```

New vs. returning visitors

---

```
shrinkr.acp.statistic.newVisitors
```

New Visitors

---

```
shrinkr.acp.statistic.returningVisitors
```

Returning Visitors

---

```
shrinkr.acp.statistic.avgSessionDuration
```

Avg. Session Duration

---

```
shrinkr.acp.statistic.avgSessionDuration.description
```

How long do visitors stay on your redirect page on average before clicking the button?

---

```
shrinkr.acp.statistic.sessionDuration
```

Session Duration

---

```
shrinkr.acp.statistic.minutes
```

Minutes

---

```
shrinkr.acp.statistic.seconds
```

Seconds

---

```
shrinkr.acp.statistic.showingTop
```

Showing Top

---

```
shrinkr.acp.statistic.export
```

Export

---

```
shrinkr.acp.statistic.exportCSV
```

Export as CSV

---

```
shrinkr.acp.statistic.info.title
```

Statistics Information

---

```
shrinkr.acp.statistic.info.description
```

Explanations of statistics, metrics and their calculation

---

```
shrinkr.acp.statistic.info.general
```

General Information

---

```
shrinkr.acp.statistic.info.general.text
```

The Shr1nkr statistics provide you with a comprehensive overview of the usage of your short URLs. All data is collected in compliance with GDPR: IP addresses are hashed with a daily salt, raw data is automatically deleted after the configured retention period. Aggregated statistics are retained permanently.

---

```
shrinkr.acp.statistic.info.kpis
```

Key Performance Indicators (KPIs)

---

```
shrinkr.acp.statistic.info.today
```

Number of visits today (since midnight). Each short URL access is counted.

---

```
shrinkr.acp.statistic.info.uniqueVisitorsToday
```

Number of unique visitors today. Calculated based on hashed IP/User-Agent fingerprint.

---

```
shrinkr.acp.statistic.info.interactionsToday
```

Number of all interactions today (button clicks and reactions).

---

```
shrinkr.acp.statistic.info.conversionRate
```

Conversion Rate: (Interactions / Visits) × 100. Shows what percentage of visitors click buttons or give reactions.

---

```
shrinkr.acp.statistic.info.avgClicksPerLink
```

Average number of clicks/interactions per link.

---

```
shrinkr.acp.statistic.info.mostActiveHour
```

The hour of the day (0-23) with the most visits.

---

```
shrinkr.acp.statistic.info.avgSessionDuration
```

Average time visitors spend on the redirect pages.

---

```
shrinkr.acp.statistic.info.browserOS
```

Shows which browsers and operating systems your visitors use. Detection is done via User-Agent.

---

```
shrinkr.acp.statistic.info.devices
```

Distribution of visits by device type (Mobile, Desktop, Tablet). Detection based on User-Agent patterns.

---

```
shrinkr.acp.statistic.info.visitorTypes
```

New visitors (first interaction) vs. Returning visitors (previously recorded). Based on hashed user fingerprint.

---

```
shrinkr.acp.statistic.info.trafficSources
```

Shows which websites (referrers) visitors came from. "Direct Traffic" means no referrer is present (e.g., direct URL entry, bookmarks).

---

```
shrinkr.acp.statistic.info.button.forward
```

Clicks on the "Forward" button that leads to the actual target URL.

---

```
shrinkr.acp.statistic.info.button.custom
```

Clicks on custom buttons that you configured in the ACP settings.

---

```
shrinkr.acp.statistic.info.button.featured_link
```

Clicks on featured links (highlighted links), which can also be configured in the ACP.

---

```
shrinkr.acp.statistic.info.reactions
```

Number of reactions (e.g., likes, emojis) given by visitors.

---

```
shrinkr.acp.statistic.info.privacy
```

Privacy & GDPR

---

```
shrinkr.acp.statistic.info.privacy.text
```

The Shr1nkr statistics collect personal data (IP addresses, user agents) only in anonymized form:

---

```
shrinkr.acp.statistic.info.privacy.hashing
```

IP addresses are hashed using SHA-256 with a daily salt. Tracing back to the original IP is not possible.

---

```
shrinkr.acp.statistic.info.privacy.retention
```

Raw data (individual visits/interactions) is automatically deleted after the configured retention period.

---

```
shrinkr.acp.statistic.info.privacy.aggregation
```

Only aggregated statistics (daily/monthly summaries) are retained permanently.

---

```
shrinkr.acp.statistic.info.experimentalWarning.title
```

IMPORTANT NOTICE: Experimental Feature

---

```
shrinkr.acp.statistic.info.experimentalWarning.text
```

The statistics functions are experimental, can be changed or removed at any time, and have no claim to permanence from an experimental perspective.

---

```
shrinkr.acp.statistic.info.experimentalWarning.details
```

These statistics currently serve primarily for development and testing. We reserve the right to change, remove, or adjust data storage without prior notice.

---

```
shrinkr.acp.statistic.info.trackedData
```

What is tracked?

---

```
shrinkr.acp.statistic.info.trackedData.stored
```

Stored Data

---

```
shrinkr.acp.statistic.info.trackedData.stored.text
```

The following data is collected for each visit to a short URL:

---

```
shrinkr.acp.statistic.info.trackedData.linkID
```

Link ID

---

```
shrinkr.acp.statistic.info.trackedData.linkID.desc
```

Which link was visited

---

```
shrinkr.acp.statistic.info.trackedData.timestamp
```

Timestamp

---

```
shrinkr.acp.statistic.info.trackedData.timestamp.desc
```

When the link was visited

---

```
shrinkr.acp.statistic.info.trackedData.ipHash
```

Hashed IP Address

---

```
shrinkr.acp.statistic.info.trackedData.ipHash.desc
```

To distinguish visitors (SHA-256 hash, not traceable)

---

```
shrinkr.acp.statistic.info.trackedData.userID
```

User ID

---

```
shrinkr.acp.statistic.info.trackedData.userID.desc
```

If logged in (optional)

---

```
shrinkr.acp.statistic.info.trackedData.browserName
```

Browser Name

---

```
shrinkr.acp.statistic.info.trackedData.browserName.desc
```

Simplified (e.g. Chrome, Firefox), no version, no full user agent.

---

```
shrinkr.acp.statistic.info.trackedData.osName
```

Operating System Name

---

```
shrinkr.acp.statistic.info.trackedData.osName.desc
```

Simplified (e.g. Windows, Android), no version.

---

```
shrinkr.acp.statistic.info.trackedData.deviceType
```

Device Type

---

```
shrinkr.acp.statistic.info.trackedData.deviceType.desc
```

Mobile, Desktop, or Tablet (estimated)

---

```
shrinkr.acp.statistic.info.trackedData.refererHash
```

Hashed Referer URL

---

```
shrinkr.acp.statistic.info.trackedData.refererHash.desc
```

Which page the visitor came from (SHA-256 hash of domain)

---

```
shrinkr.acp.statistic.info.trackedData.interactions
```

Interactions

---

```
shrinkr.acp.statistic.info.trackedData.interactions.desc
```

Which buttons were clicked (Custom Buttons, Featured Links, Reactions)

---

```
shrinkr.acp.statistic.info.trackedData.notStored
```

What is NOT stored?

---

```
shrinkr.acp.statistic.info.trackedData.notStored.ip
```

Full IP addresses (hash only)

---

```
shrinkr.acp.statistic.info.trackedData.notStored.userAgent
```

Full user agent strings

---

```
shrinkr.acp.statistic.info.trackedData.notStored.browserVersion
```

Browser versions or OS versions in detail

---

```
shrinkr.acp.statistic.info.trackedData.notStored.country
```

Country information (geo-location)

---

```
shrinkr.acp.statistic.info.trackedData.notStored.personalData
```

Personal data (name, email, etc.)

---

```
shrinkr.acp.statistic.info.trackedData.notStored.refererUrl
```

Full referer URLs (domain hash only)

---

```
shrinkr.acp.statistic.info.availableStats
```

Available Statistics

---

```
shrinkr.acp.statistic.info.availableStats.overview
```

Overview

---

```
shrinkr.acp.statistic.info.availableStats.visits
```

Visits

---

```
shrinkr.acp.statistic.info.availableStats.visits.desc
```

Number of visits per day/week/total

---

```
shrinkr.acp.statistic.info.availableStats.uniqueVisitors
```

Unique Visitors

---

```
shrinkr.acp.statistic.info.availableStats.uniqueVisitors.desc
```

Estimated based on hashed IP addresses

---

```
shrinkr.acp.statistic.info.availableStats.interactions
```

Interactions

---

```
shrinkr.acp.statistic.info.availableStats.interactions.desc
```

Number of button clicks, reactions, etc.

---

```
shrinkr.acp.statistic.info.availableStats.conversionRate
```

Conversion Rate

---

```
shrinkr.acp.statistic.info.availableStats.conversionRate.desc
```

Percentage of visitors who interact

---

```
shrinkr.acp.statistic.info.availableStats.timeline
```

Timeline

---

```
shrinkr.acp.statistic.info.availableStats.timeline.desc
```

Chart with visits over time

---

```
shrinkr.acp.statistic.info.availableStats.linkPerformance
```

Link Performance

---

```
shrinkr.acp.statistic.info.availableStats.topLinks
```

Top Links

---

```
shrinkr.acp.statistic.info.availableStats.topLinks.desc
```

Which links are visited most frequently

---

```
shrinkr.acp.statistic.info.availableStats.interactionsPerLink
```

Interactions per Link

---

```
shrinkr.acp.statistic.info.availableStats.interactionsPerLink.desc
```

Which links generate the most button clicks

---

```
shrinkr.acp.statistic.info.availableStats.conversionRatePerLink
```

Conversion Rate per Link

---

```
shrinkr.acp.statistic.info.availableStats.conversionRatePerLink.desc
```

How successful each link is

---

```
shrinkr.acp.statistic.info.availableStats.marketing
```

Marketing Features

---

```
shrinkr.acp.statistic.info.availableStats.customButtons
```

Custom Buttons

---

```
shrinkr.acp.statistic.info.availableStats.customButtons.desc
```

Which custom buttons are clicked most frequently

---

```
shrinkr.acp.statistic.info.availableStats.featuredLinks
```

Featured Links

---

```
shrinkr.acp.statistic.info.availableStats.featuredLinks.desc
```

Which featured links work best

---

```
shrinkr.acp.statistic.info.availableStats.trafficSources
```

Traffic Sources

---

```
shrinkr.acp.statistic.info.availableStats.trafficSources.desc
```

Which domains most visitors come from

---

```
shrinkr.acp.statistic.info.availableStats.technical
```

Technical Statistics

---

```
shrinkr.acp.statistic.info.availableStats.hourlyDistribution
```

Hourly Distribution

---

```
shrinkr.acp.statistic.info.availableStats.hourlyDistribution.desc
```

What times of day have the most visits

---

```
shrinkr.acp.statistic.info.availableStats.deviceTypes
```

Device Types

---

```
shrinkr.acp.statistic.info.availableStats.deviceTypes.desc
```

Mobile vs Desktop vs Tablet

---

```
shrinkr.acp.statistic.info.privacy.anonymization
```

Anonymization

---

```
shrinkr.acp.statistic.info.privacy.ipAddresses
```

IP Addresses

---

```
shrinkr.acp.statistic.info.privacy.ipAddresses.desc
```

Are hashed immediately after collection with SHA-256 and cannot be traced back

---

```
shrinkr.acp.statistic.info.privacy.refererUrls
```

Referer URLs

---

```
shrinkr.acp.statistic.info.privacy.refererUrls.desc
```

Are hashed, only domain is used for statistics

---

```
shrinkr.acp.statistic.info.privacy.userAgent
```

User Agent

---

```
shrinkr.acp.statistic.info.privacy.userAgent.desc
```

Not stored, only browser/OS name extracted

---

```
shrinkr.acp.statistic.info.privacy.retention
```

Data Retention

---

```
shrinkr.acp.statistic.info.privacy.retention.current
```

Current: No automatic deletion (experimental)

---

```
shrinkr.acp.statistic.info.privacy.retention.planned
```

Planned: Automatic deletion after 90 days (when feature becomes final)

---

```
shrinkr.acp.statistic.info.privacy.optIn
```

Opt-In / Opt-Out

---

```
shrinkr.acp.statistic.info.privacy.optIn.current
```

Current: Statistics are automatically collected when tracking is enabled

---

```
shrinkr.acp.statistic.info.privacy.optIn.note
```

Note: Tracking can be disabled in plugin settings

---

```
shrinkr.acp.statistic.info.privacy.legal
```

Legal Notes

---

```
shrinkr.acp.statistic.info.privacy.legal.text
```

These statistics serve solely for function analysis and optimization of the plugin. No personal data within the meaning of GDPR is stored, as IP addresses are hashed and not traceable.

---

```
shrinkr.acp.statistic.info.privacy.legal.important
```

Important: When used in EU/EEA, you should mention the collection of statistics in your privacy policy, even if anonymized.

---

```
shrinkr.acp.statistic.info.limitations
```

Known Limitations

---

```
shrinkr.acp.statistic.info.limitations.uniqueVisitors
```

Unique Visitors

---

```
shrinkr.acp.statistic.info.limitations.uniqueVisitors.desc
```

Estimated based on IP hash, not 100% accurate (same IP = same visitor)

---

```
shrinkr.acp.statistic.info.limitations.deviceType
```

Device Type

---

```
shrinkr.acp.statistic.info.limitations.deviceType.desc
```

Estimated based on OS/browser, not always correct

---

```
shrinkr.acp.statistic.info.limitations.sessionDuration
```

Session Duration

---

```
shrinkr.acp.statistic.info.limitations.sessionDuration.desc
```

Not captured (irrelevant for redirect pages)

---

```
shrinkr.acp.statistic.info.limitations.returningVisitors
```

Returning Visitors

---

```
shrinkr.acp.statistic.info.limitations.returningVisitors.desc
```

Not reliably captured

---

```
shrinkr.acp.statistic.info.limitations.countryStats
```

Country Statistics

---

```
shrinkr.acp.statistic.info.limitations.countryStats.desc
```

Not captured (GDPR compliance)

---

```
shrinkr.acp.statistic.info.performance
```

Performance

---

```
shrinkr.acp.statistic.info.performance.caching
```

Caching

---

```
shrinkr.acp.statistic.info.performance.caching.desc
```

Statistics are cached to reduce database load

---

```
shrinkr.acp.statistic.info.performance.aggregation
```

Aggregation

---

```
shrinkr.acp.statistic.info.performance.aggregation.desc
```

Daily aggregation via cronjob for better performance

---

```
shrinkr.acp.statistic.info.performance.limitations
```

Limitations

---

```
shrinkr.acp.statistic.info.performance.limitations.desc
```

Lists are limited to top 10-20 entries to avoid overload

---

```
shrinkr.acp.statistic.info.changelog
```

Changelog

---

```
shrinkr.acp.statistic.info.changelog.text
```

Changes to statistics are documented in the changelog. Since the functions are experimental, metrics, calculations, or available statistics may change at any time.

---

```
shrinkr.acp.statistic.weekday.monday
```

Monday

---

```
shrinkr.acp.statistic.weekday.tuesday
```

Tuesday

---

```
shrinkr.acp.statistic.weekday.wednesday
```

Wednesday

---

```
shrinkr.acp.statistic.weekday.thursday
```

Thursday

---

```
shrinkr.acp.statistic.weekday.friday
```

Friday

---

```
shrinkr.acp.statistic.weekday.saturday
```

Saturday

---

```
shrinkr.acp.statistic.weekday.sunday
```

Sunday

---

```
shrinkr.acp.statistic.month.january
```

January

---

```
shrinkr.acp.statistic.month.february
```

February

---

```
shrinkr.acp.statistic.month.march
```

March

---

```
shrinkr.acp.statistic.month.april
```

April

---

```
shrinkr.acp.statistic.month.may
```

May

---

```
shrinkr.acp.statistic.month.june
```

June

---

```
shrinkr.acp.statistic.month.july
```

July

---

```
shrinkr.acp.statistic.month.august
```

August

---

```
shrinkr.acp.statistic.month.september
```

September

---

```
shrinkr.acp.statistic.month.october
```

October

---

```
shrinkr.acp.statistic.month.november
```

November

---

```
shrinkr.acp.statistic.month.december
```

December

---

```
shrinkr.acp.stat.noData
```

No data available

---

```
shrinkr.acp.stat.visits
```

Visits

---

```
shrinkr.acp.stat.interactions
```

Interactions

---

```
shrinkr.acp.stat.interactionType.button.forward
```

Forward

---

```
shrinkr.acp.stat.interactionType.button.custom
```

Custom Button

---

```
shrinkr.acp.stat.interactionType.button.featured_link
```

Featured Link

---

```
shrinkr.acp.stat.interactionType.reaction
```

Reaction

---

```
wcf.acp.option.shrinkr_tracking_enabled
```

Enable Tracking

---

```
wcf.acp.option.shrinkr_tracking_enabled.description
```

Enables tracking of visits and interactions for your short URLs. Disable this option to completely deactivate tracking.

---

```
wcf.acp.option.shrinkr_statistic_retention_days
```

Retention Period (Days)

---

```
wcf.acp.option.shrinkr_statistic_retention_days.description
```

Raw data (individual visits and interactions) will be automatically deleted after this number of days. Aggregated statistics remain permanently. GDPR compliant: IP addresses are hashed with daily salt.

---

```
wcf.acp.group.option.admin.shrinkr.canViewStatistics
```

Can view statistics

---

```
wcf.acp.group.option.admin.shrinkr.canViewStatistics.description
```

Allows viewing statistics in the ACP.

---

```
wcf.acp.group.option.admin.shrinkr.canManageStatistics
```

Can manage statistics

---

```
wcf.acp.group.option.admin.shrinkr.canManageStatistics.description
```

Allows deleting and managing statistic data (generate demo data, trigger cleanup, etc.).

---

```
shrinkr.acp.statistic.tab.overview
```

Overview

---

```
shrinkr.acp.statistic.tab.visitor
```

Visitors

---

```
shrinkr.acp.statistic.tab.click
```

Clicks & Buttons

---

```
shrinkr.acp.statistic.tab.reaction
```

Reactions

---

```
shrinkr.acp.statistic.tab.share
```

Shares

---

```
shrinkr.acp.statistic.tab.special
```

Specials

---

```
shrinkr.acp.statistic.tab.overview.description
```

Totals for the selected period and optionally filtered by link.

---

```
shrinkr.acp.statistic.tab.visitor.description
```

Sessions per link: guests vs. logged-in users and average time on page.

---

```
shrinkr.acp.statistic.tab.click.description
```

Clicks on main link, custom buttons, and featured links, how your visitors interact.

---

```
shrinkr.acp.statistic.tab.reaction.description
```

Reactions per link and reaction type (e.g. Like, Love).

---

```
shrinkr.acp.statistic.tab.share.description
```

Tracked share actions: dialog opened, HTML/link clicked, BBCode, social channels.

---

```
shrinkr.acp.statistic.tab.special.description
```

Specials displayed (page view) vs. active (user clicked the special area).

---

```
shrinkr.acp.statistic.tab.voucher.description
```

Views per voucher (permanent and one-time) in the selected period.

---

```
shrinkr.acp.statistic.tab.onetime.description
```

Views per one-time message (OTM) in the selected period.

---

```
shrinkr.acp.statistic.visitTrend.description
```

Views and clicks per day in the selected period.

---

```
shrinkr.acp.statistic.clickTrend
```

Clicks per day

---

```
shrinkr.acp.statistic.reactionDistribution
```

Distribution by reaction type

---

```
shrinkr.acp.statistic.reactionDistribution.description
```

Share of reactions per type in the selected period.

---

```
shrinkr.acp.statistic.topLinks.description
```

Links with the most views and clicks in the selected period.

---

```
shrinkr.acp.statistic.noTitle
```

No Title

---

```
shrinkr.acp.statistic.customButtonFallback
```

Button #%d

---

```
shrinkr.acp.statistic.featuredLinkFallback
```

Featured Link #%d

---

```
shrinkr.acp.statistic.unknownReaction
```

Unknown Reaction

---

```
shrinkr.acp.statistic.clickDetails
```

Show button and link details

---

```
shrinkr.acp.statistic.clickDetails.description
```

Click statistics per link with main link, custom buttons and featured links.

---

```
shrinkr.acp.statistic.reactionDetails
```

Reaction Details

---

```
shrinkr.acp.statistic.reactionDetails.description
```

Breakdown of reactions per link and reaction type.

---

```
shrinkr.acp.statistic.noData
```

No data available

---

```
shrinkr.acp.statistic.visitorDistribution
```

Visitor Distribution

---

```
shrinkr.acp.statistic.visitorDistribution.description
```

Distribution between guests and registered users.

---

```
shrinkr.acp.statistic.visitorDetails
```

Visitor Details

---

```
shrinkr.acp.statistic.visitorDetails.description
```

Detailed list of all visitor sessions.

---

```
shrinkr.acp.statistic.shareTrend
```

Shares per day

---

```
shrinkr.acp.statistic.shareTrend.description
```

Number of shares over the selected period.

---

```
shrinkr.acp.statistic.shareDetails
```

Share Details

---

```
shrinkr.acp.statistic.shareDetails.description
```

Detailed breakdown of share actions.

---

```
shrinkr.acp.statistic.views
```

Views

---

```
shrinkr.acp.statistic.voucherTrend
```

Voucher views per day

---

```
shrinkr.acp.statistic.voucherTrend.description
```

Number of voucher page views over the selected period.

---

```
shrinkr.acp.statistic.voucherDetails
```

Voucher Details

---

```
shrinkr.acp.statistic.voucherDetails.description
```

Views per voucher (permanent and one-time).

---

```
shrinkr.acp.statistic.voucherType
```

Type

---

```
shrinkr.acp.statistic.voucherType.permanent
```

Permanent

---

```
shrinkr.acp.statistic.voucherType.once
```

One-time

---

```
shrinkr.acp.statistic.onetimeTrend
```

OTM views per day

---

```
shrinkr.acp.statistic.onetimeTrend.description
```

Number of one-time message views over the selected period.

---

```
shrinkr.acp.statistic.onetimeDetails
```

One-Time Message Details

---

```
shrinkr.acp.statistic.onetimeDetails.description
```

Views per one-time message.

---

```
shrinkr.acp.statistic.onetimePreview
```

Message (excerpt)

---

```
shrinkr.acp.statistic.filter
```

Filter

---

```
shrinkr.acp.statistic.filter.apply
```

Apply Filter

---

```
shrinkr.acp.statistic.startDate
```

Start Date

---

```
shrinkr.acp.statistic.endDate
```

End Date

---

```
shrinkr.acp.statistic.linkFilter
```

Link Filter

---

```
shrinkr.acp.statistic.linkHashOrId
```

Link (Hash or ID)

---

```
shrinkr.acp.statistic.linkHashOrId.placeholder
```

e.g. DEMO-1 or 12345

---

```
shrinkr.acp.statistic.linkHashOrId.description
```

Optional: Only show statistics for one link. Enter hash (e.g. DEMO-1) or link ID. Empty = all links.

---

```
shrinkr.acp.statistic.linkHashOrId.description
```

Optional: Only show statistics for one link. Enter hash (e.g. DEMO-1) or link ID. Empty = all links.

---

```
shrinkr.acp.statistic.linkSearch.resultsCount
```

%d results

---

```
shrinkr.acp.statistic.startDate.description
```

Start of the displayed period.

---

```
shrinkr.acp.statistic.endDate.description
```

End of the displayed period.

---

```
shrinkr.acp.statistic.linkFilter.description
```

Optional: If you enter a short URL hash or ID, only statistics for that one short URL are shown. Suggestions from your links appear as you type. Leave empty for statistics across all short URLs.

---

```
shrinkr.acp.statistic.tabs
```

Statistics Sections

---

```
shrinkr.acp.statistic.metric
```

Metric

---

```
shrinkr.acp.statistic.value
```

Value

---

```
shrinkr.acp.statistic.totalViews
```

Total Views

---

```
shrinkr.acp.statistic.totalClicks
```

Total Clicks

---

```
shrinkr.acp.statistic.totalReactions
```

Total Reactions

---

```
shrinkr.acp.statistic.totalShares
```

Total Shares

---

```
shrinkr.acp.statistic.conversionRate
```

Click Rate

---

```
shrinkr.acp.statistic.topLinks
```

Top Links

---

```
shrinkr.acp.statistic.performance
```

Performance Overview

---

```
shrinkr.acp.statistic.performance.description
```

Average performance and best/worst links in the selected period.

---

```
shrinkr.acp.statistic.avgConversionRate
```

Average Click Rate

---

```
shrinkr.acp.statistic.totalLinks
```

Total Links

---

```
shrinkr.acp.statistic.bestPerformer
```

Best Performer

---

```
shrinkr.acp.statistic.linkID
```

Link ID

---

```
shrinkr.acp.statistic.duration.seconds
```

Sec

---

```
shrinkr.acp.statistic.duration.minutes
```

Min

---

```
shrinkr.acp.statistic.duration.hours
```

h

---

```
shrinkr.acp.statistic.guests
```

Guests

---

```
shrinkr.acp.statistic.users
```

Users

---

```
shrinkr.acp.statistic.total
```

Total

---

```
shrinkr.acp.statistic.avgTimeOnPage
```

Average Time on Page

---

```
shrinkr.acp.statistic.mainLinkClicks
```

Main Link Clicks

---

```
shrinkr.acp.statistic.customButtonClicks
```

Custom Button Clicks

---

```
shrinkr.acp.statistic.featuredLinkClicks
```

Featured Link Clicks

---

```
shrinkr.acp.statistic.reactionType
```

Reaction Type

---

```
shrinkr.acp.statistic.count
```

Count

---

```
shrinkr.acp.statistic.dialogOpened
```

Dialog Opened

---

```
shrinkr.acp.statistic.htmlClick
```

HTML Link

---

```
shrinkr.acp.statistic.directClick
```

Direct Link

---

```
shrinkr.acp.statistic.bbcodeClick
```

BB Code

---

```
shrinkr.acp.statistic.socialClicks
```

Social Share

---

```
shrinkr.acp.statistic.special
```

Special

---

```
shrinkr.acp.statistic.displayed
```

Displayed

---

```
shrinkr.acp.statistic.active
```

Active

---

```
shrinkr.acp.statistic.link
```

Link

---

```
shrinkr.acp.statistic.views
```

Views

---

```
shrinkr.acp.statistic.clicks
```

Clicks
